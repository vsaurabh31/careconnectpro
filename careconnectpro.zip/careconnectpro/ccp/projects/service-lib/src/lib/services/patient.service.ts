import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import {
  Patient,
  GenericIdValue,
  CompanyPatientMedicalHistory,
  GenericSearch
} from 'model-lib';

import { BaseMethod } from '../shared';

@Injectable({
  providedIn: 'root'
})
export class PatientService extends BaseMethod {
  private patient: Patient = {};
  private isInTakeMode: boolean = false;
  private isHeaderSearchTriggered: boolean = false;
  public isInTakeModeChanged$: Subject<boolean> = new Subject<boolean>();
  public isPatientRecordChanged$: Subject<boolean> = new Subject<boolean>();
  private patientSearch: GenericSearch = {};
  public executePatientSearch$: Subject<boolean> = new Subject<boolean>();
  public extraDetailsDropDown$: Subject<GenericIdValue[]> = new Subject<GenericIdValue[]>();
  private extraDetailsDropDown: GenericIdValue[] = [];
  public companyPatientMedicalHistory$: Subject<CompanyPatientMedicalHistory[]> = new Subject<CompanyPatientMedicalHistory[]>();
  private companyPatientMedicalHistory: CompanyPatientMedicalHistory[] = [];
  public serviceRequestedDropDown$: Subject<GenericIdValue[]> = new Subject<GenericIdValue[]>();
  private serviceRequestedDropDown: GenericIdValue[] = [];

  constructor() {
    super();
  }

  getInTakeMode(): boolean {
    return this.isInTakeMode;
  }

  updateInTakeMode(val: boolean) {
    this.isInTakeMode = val;
    this.isInTakeModeChanged$.next(val);
  }

  getTriggerHeaderSearch() {
    return this.isHeaderSearchTriggered
  }
  
  updateTriggerHeaderSearch(val: boolean) {
    this.isHeaderSearchTriggered = val;
  }
  getPatient() {
    return this.patient;
  }

  updatePatient(_patient: Patient) {
    this.patient = _patient;
    this.isPatientRecordChanged$.next(true);
  }
 
  getSearchKeyword() {
    return this.patientSearch;
  }

  setSearchKeyword(val: GenericSearch) {
    this.patientSearch = val;
    if (this.patientSearch.searchKeyword != '') {
      this.executePatientSearch$.next(true);
    } else {
      this.executePatientSearch$.next(false);
    }
  }

  updateExtraDetailsDropDown(val: GenericIdValue[]) {
    this.extraDetailsDropDown = val;
    this.extraDetailsDropDown$.next(val);
  }

  getExtraDetailsDropDown() {
    return this.extraDetailsDropDown;
  }
  updateCompanyPatientMedicalHistory(val: CompanyPatientMedicalHistory[]) {
    this.companyPatientMedicalHistory = val;
    this.companyPatientMedicalHistory$.next(val);
  }

  getCompanyPatientMedicalHistory() {
    return this.companyPatientMedicalHistory;
  }

  getExtraDetailTypeById(val: string) {
    const extraDetail = this.extraDetailsDropDown.find(item => item.id == val);
    if (!extraDetail) {
      return "";
    }
    return extraDetail.value;
  }

  updateServiceRequestedDropDown(val: GenericIdValue[]) {
    this.serviceRequestedDropDown = val;
    this.serviceRequestedDropDown$.next(val);
  }

  getServiceRequestedDropDown() {
    return this.serviceRequestedDropDown;
  }

  getServiceRequestedTypeById(val: string) {
    const serviceRequested = this.serviceRequestedDropDown.find(item => item.id == val);
    if (!serviceRequested) {
      return "";
    }
    return serviceRequested.value;
  }
}
