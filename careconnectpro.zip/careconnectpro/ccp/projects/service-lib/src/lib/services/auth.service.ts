import { Injectable } from '@angular/core';
import { Observable, of, Subject } from 'rxjs';
import { Response } from '@angular/http';
import { Router } from '@angular/router';
import { DataService } from './data.service';
import { AlertService } from './alert.service';
import 'rxjs/add/operator/map';
import {
  APIUrls,
  UserLogin,
  UserSession,
  AlertType,
  AppMessage,
  BaseApiResponse,
  ApiEndPoints
} from 'model-lib';
import 'rxjs/add/operator/finally';
import { CareConnectLocalStorage } from './localstorage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private activeLocationId: string;
  public activeLocationId$: Subject<string> = new Subject<string>();
  private userSession: UserSession;
  public userSession$: Subject<UserSession> = new Subject<UserSession>();

  constructor(
    public router: Router,
    private localStore: CareConnectLocalStorage,
    private dataService: DataService,
    private alertService: AlertService
  ) { }

  setUserLoggedIn(val: UserSession) {
    this.userSession = val;
    this.userSession$.next(val);
  }

  getIsUserLoggedIn(): boolean {
    if (!!this.userSession) {
      return true;
    }
    return false;
  }

  /**
   * Method - Update the current agency location id
   */
  changeActiveAgencyLocationId(locationId: string) {
    this.activeLocationId = locationId;
    this.activeLocationId$.next(locationId);
  }

  /**
   * Method - Retrieve stored agency location id
   */
  getActiveAgencyLocationId(): string {
    return this.activeLocationId;
  }

  getUserLoggedIn() {
    return this.userSession;
  }

  validateResetUserSession(): Observable<any> {
    const observable =
    new Observable(subscriber => {
      try {
        const authToken = this.localStore.getAuthToken();
        if (!authToken) {
          this.logout();
        }
        const _userSession = this.getUserLoggedIn();
        if (!!authToken && !!_userSession) {
          subscriber.next(null);
        }
        this.alertService.showSpinner(true);
        let request: UserSession;
        let dbResponse: UserSession = {};
        const response = this.dataService
          .getSingleData(request, "", APIUrls.GetUserSignedInInfo)
          .finally(() => {
            this.alertService.showSpinner(false);
            subscriber.next(dbResponse);
            subscriber.complete();
          })
          .subscribe(
            (data) => {
              dbResponse = data;
              if ((!!dbResponse) && (!!dbResponse.companyId)) {
                this.setUserLoggedIn(dbResponse);                
              } else {
                this.alertService.displayErrorMessage(AlertType.Dialog, AppMessage.SessionExpiredHeaderText, AppMessage.SessionExpiredHeaderText + ". " + AppMessage.SessionExpiredBodyText);
                this.logout();
              }
            },
            (error) => {
              this.logout();
              this.alertService.displayErrorMessage(
                AlertType.Dialog,
                '',
                error
              );
            }
          );
       
      } catch (err) {
        subscriber.error(err); // delivers an error if it caught one
      }
    });
    return observable;
  }

  VerifyPasswordResetToken(tokenId: string): BaseApiResponse {
    let response: BaseApiResponse = {};
    return this.dataService
      .getSingleData(String, tokenId, APIUrls.VerifyPasswordRequestToken)
      .finally(() => {
        return response;
      })
      .subscribe(
        (data: BaseApiResponse) => {
          response = data;
        },
        error => {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            'Session expired'
          );
          this.logout();
        }
      );
  }

  ChangeUserPassword(user: UserLogin): Observable<any> {
    let response: BaseApiResponse = {};
    return this.dataService.postData(user, APIUrls.ChangeUserPassword);
  }

  logout(): void {
    let tmpUserLogin: UserLogin = {};
    const _userSession: UserSession = {};
    this.userSession$.next(_userSession);
    this.localStore.storeAuthToken('');
    this.redirectLoginPage();
  }

  handleError(error: Response) {
    console.error(error);
    return Observable.throw(error);
  }

  /**
   * Method - Validate base url protocol and redirect to https
   */
  validateBaseUrl() {
    const baseUrl = ApiEndPoints.BaseUrl;
    const urlArray = baseUrl.split('://');
    if (
      urlArray[0].toLowerCase() === 'http' &&
      baseUrl.indexOf('localhost') < 0
    ) {
      const urlRedirect = 'https://' + urlArray[1];
      window.location.href = urlRedirect;
    }
  }

  /**
   * Method - Redirect to login if user session is not active
   */
  redirectLoginPage() {
    this.router.navigate(['/']);
  }

  validateUserSession() {
    const _session = this.getUserLoggedIn();
    if (!_session.isAuthenticated) {
      this.redirectLoginPage();
    }
  }
}
