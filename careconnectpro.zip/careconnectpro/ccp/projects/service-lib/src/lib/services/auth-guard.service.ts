import { Injectable } from '@angular/core';
import { CanActivate, CanActivateChild } from '@angular/router';
import { AuthService } from './auth.service';
import { UserSession } from 'model-lib';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild {
  public userSession: UserSession;
  public redirectUrl: string = '';

  constructor(private authService: AuthService) {}

  canActivate() {
    this.authService.validateBaseUrl();
    if (!this.authService.getIsUserLoggedIn()) {
      this.authService.redirectLoginPage();
    } else {
      return true;
    }
  }

  canActivateChild() {
    return this.canActivate();
  }
}
