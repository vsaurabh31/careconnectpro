import { Injectable } from '@angular/core';
import { HubConnection, HubConnectionBuilder } from '@aspnet/signalr';
import { Observable, Observer } from 'rxjs';
import { AppChatHeader, APIUrls, SystemBroadcastDetail} from 'model-lib';

@Injectable({
  providedIn: 'root'
})
export class SignalrhubService {
  private chatHubConnection: HubConnection;
  private sysBroadcastHubConnection: HubConnection;
  private chatHubConnBuilder: HubConnectionBuilder = new HubConnectionBuilder();
  private sysBroadcastHubConnBuilder: HubConnectionBuilder = new HubConnectionBuilder();
  private connMaxRetry: number = 3;
  private retryNum: number = 0;

  constructor() {
    
  }

  connectChatHub(): void {
    this.chatHubConnBuilder.withUrl(APIUrls.ChatHub);
    this.chatHubConnection = this.chatHubConnBuilder.build();
    this.chatHubConnection
      .start()
      .then(() => console.log('Connection started - listening to chat messages!'))
      .catch(err => {
        console.log(
          `Error while establishing connection to chat server - attempting another retry number ${
            this.retryNum
          }`
        );
        setTimeout(this.connectChatHub, 5000);
      });
  }

  connectSysBroadcastHub(): void {
    this.sysBroadcastHubConnBuilder.withUrl(APIUrls.SystemBroadcastHub);
    this.sysBroadcastHubConnection = this.sysBroadcastHubConnBuilder.build();
    this.sysBroadcastHubConnection
      .start()
      .then(() => console.log('Connection started - Listening to system broadcast messages!'))
      .catch(err => {
        console.log(
          `Error while establishing connection to broadcast server - attempting another retry number ${
            this.retryNum
          }`
        );
        setTimeout(this.connectSysBroadcastHub, 5000);
      });
     }

  listenChatMessages(userId: string): Observable<AppChatHeader> {
    const chatHub$ = new Observable<AppChatHeader>(Observer => {
      this.chatHubConnection.on(
        'ReceiveChatMessage',
        (receivedChat: AppChatHeader) => {
          if (receivedChat.chatUsers.includes(userId)) {
            Observer.next(receivedChat);
          }
        }
      );
    });
    return chatHub$;
  }

  listenSystemBroadcastMessages(): Observable<SystemBroadcastDetail> {
    const broadcastMsgHub$ = new Observable<SystemBroadcastDetail>(Observer => {
      this.sysBroadcastHubConnection.on(
        'ReceiveSystemBroadcastMessage',
        (receivedMessage: SystemBroadcastDetail) => {
            Observer.next(receivedMessage);
        }
      );
    });
    return broadcastMsgHub$;
  }

  sendChat(chatHeader: AppChatHeader) {
    this.chatHubConnection.invoke('SendMessage', chatHeader).catch(err => {
      console.error(err);
      if (this.retryNum < this.connMaxRetry) {
        console.log(
          `Error while establishing connection to chat server - attempting another retry number ${
            this.retryNum
          }`
        );
        this.retryNum++;
        this.connectChatHub();
      }
    });
  }
  sendBroadcastMsg(broadcastMsg: SystemBroadcastDetail) {
    this.sysBroadcastHubConnection.invoke('SendMessage', broadcastMsg).catch(err => {
      console.error(err);
      if (this.retryNum < this.connMaxRetry) {
        console.log(
          `Error while establishing connection to broadcast server - attempting another retry number ${
            this.retryNum
          }`
        );
        this.retryNum++;
        this.connectSysBroadcastHub();
      }
    });
  }
}
