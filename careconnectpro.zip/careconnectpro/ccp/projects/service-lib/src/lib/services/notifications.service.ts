import { Injectable } from '@angular/core';
import { AppChatDetail, AppMessageDetail, SystemBroadcastDetail } from 'model-lib';
import { Subject } from 'rxjs/Subject';

type Severities = 'success' | 'info' | 'warn' | 'error';

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {

  public systemBroadcastMessages$: Subject<SystemBroadcastDetail[]> = new Subject<SystemBroadcastDetail[]>();
  public chatMessages$: Subject<AppChatDetail[]> = new Subject<AppMessageDetail[]>();
  public inboxMessages$: Subject<AppMessageDetail[]> = new Subject<AppMessageDetail[]>();
  private systemBroadcastMessages: SystemBroadcastDetail[] = [];
  private chatMessages: AppChatDetail[] = [];
  private inboxMessages: AppMessageDetail[] = [];
  public isVendorRecordChanged$: Subject<boolean> = new Subject<boolean>();
  public isPhysicianRecordChanged$: Subject<boolean> = new Subject<boolean>();
  public isMedicalProviderRecordChanged$: Subject<boolean> = new Subject<boolean>();
  public isInsuranceProviderRecordChanged$: Subject<boolean> = new Subject<boolean>();

  notificationChange: Subject<Object> = new Subject<Object>();
  
  notify(severity: Severities, summary: string, detail: string) {
    this.notificationChange.next({ severity, summary, detail });
  }

  markReadSystemBroadcastMessage(systemBroadcastMsg: SystemBroadcastDetail) {
    const idx = this.systemBroadcastMessages.findIndex(x => x.id == systemBroadcastMsg.id);
    if (idx > -1 ) {
      this.systemBroadcastMessages.splice(idx, 1);
      localStorage.setItem("ccp-notify-broadcast-msgs", JSON.stringify(this.systemBroadcastMessages));
      this.systemBroadcastMessages$.next(this.systemBroadcastMessages);
    }
  }

  markReadChatMessage(chatMessage: AppChatDetail) {
    const idx = this.chatMessages.findIndex(x => x.id == chatMessage.id);
    if (idx > -1 ) {
      this.chatMessages.splice(idx, 1);
      localStorage.setItem("ccp-notify-chat-msgs", JSON.stringify(this.chatMessages));
      this.chatMessages$.next(this.chatMessages);
    }
  }

  markReadInboxMessages(inboxMessage: AppMessageDetail) {
    const idx = this.inboxMessages.findIndex(x => x.id == inboxMessage.id);
    if (idx > -1 ) {
      this.inboxMessages.splice(idx, 1);
      localStorage.setItem("ccp-notify-inbox-msgs", JSON.stringify(this.inboxMessages));
      this.inboxMessages$.next(this.inboxMessages);
    }
  }

  addBroadcastMessage(broadcastMsg: SystemBroadcastDetail) {
    const idx = this.systemBroadcastMessages.findIndex(x => x.id == broadcastMsg.id);
    if (idx < 0 ) {
      this.systemBroadcastMessages.push(broadcastMsg);
      localStorage.setItem("ccp-notify-broadcast-msgs", JSON.stringify(this.systemBroadcastMessages));
      this.systemBroadcastMessages$.next(this.systemBroadcastMessages);
    }
  }
  addChatMessage(chatMsg: AppChatDetail) {
    const idx = this.chatMessages.findIndex(x => x.id == chatMsg.id);
    if (idx < 0 ) {
      this.chatMessages.push(chatMsg);
      localStorage.setItem("ccp-notify-chat-msgs", JSON.stringify(this.chatMessages));
      this.chatMessages$.next(this.chatMessages);
    }
  }
  addInboxMessage(inboxMsg: AppMessageDetail) {
    const idx = this.inboxMessages.findIndex(x => x.id == inboxMsg.id);
    if (idx < 0 ) {
      this.inboxMessages.push(inboxMsg);
      localStorage.setItem("ccp-notify-inbox-msgs", JSON.stringify(this.inboxMessages));
      this.inboxMessages$.next(this.inboxMessages);
    }
  }
  getBroadcastMsgs() {
    if (this.systemBroadcastMessages.length > 0 ) {
      return this.systemBroadcastMessages;
    }
    let storedMsgsJson = localStorage.getItem("ccp-notify-broadcast-msgs");
    const _broadcastMsgs: SystemBroadcastDetail[] = JSON.parse(storedMsgsJson);
    if ((!!_broadcastMsgs) && _broadcastMsgs.length > 0 ) {
      this.systemBroadcastMessages = [..._broadcastMsgs];      
    }
    return this.systemBroadcastMessages;
  }
  getChatMsgs() {
    if (this.chatMessages.length > 0 ) {
      return this.chatMessages;
    }
    let storedMsgsJson = localStorage.getItem("ccp-notify-chat-msgs");
    const _chatMsgs: AppChatDetail[] = JSON.parse(storedMsgsJson);
    if ((!!_chatMsgs) && _chatMsgs.length > 0 ) {
      this.chatMessages = [..._chatMsgs];      
    }
    return this.chatMessages;
  }
  getInboxMsgs() {
    if (this.inboxMessages.length > 0 ) {
      return this.inboxMessages;
    }
    let storedMsgsJson = localStorage.getItem("ccp-notify-inbox-msgs");
    const _inboxMsgs: AppMessageDetail[] = JSON.parse(storedMsgsJson);
    if ((!!_inboxMsgs) && _inboxMsgs.length > 0 ) {
      this.inboxMessages = [..._inboxMsgs];      
    }
    return this.inboxMessages;
  }
  clearNotificationLocalStorage() {
    localStorage.removeItem("ccp-notify-inbox-msgs");
    localStorage.removeItem("ccp-notify-chat-msgs");
    localStorage.removeItem("ccp-notify-broadcast-msgs");
  }

  refreshVendorRecord() {
    this.isVendorRecordChanged$.next(true);    
  }
  refreshPhysicianRecord() {
    this.isPhysicianRecordChanged$.next(true);
  }
  refreshMedicalProviderRecord() {
    this.isMedicalProviderRecordChanged$.next(true);
  }
  refreshInsuranceProviderRecord() {
    this.isInsuranceProviderRecordChanged$.next(true);
  }
}
