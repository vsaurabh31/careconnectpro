import { Injectable, EventEmitter } from '@angular/core';
import {
  Company,
  CompanySubscription,
} from 'model-lib';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CompanyBusinessService {
  private companyLogo: string;
  private companySubscriptions: CompanySubscription[] = [];
  private activeSubscription: CompanySubscription = {};
  private company: Company = {};
  public isRecordChanged$: Subject<boolean> = new Subject<boolean>();

  isCompanyRecordChanged: EventEmitter<boolean> = new EventEmitter();

  constructor() {}

  refreshView() {
this.isRecordChanged$.next(true);
  }

  getCompanySubscriptions() {
    return this.company.subscriptions;
  }

  updateCompanySubscriptions(val: CompanySubscription[]) {
    this.companySubscriptions = val;
  }

  getActiveSubscription() {
    return this.activeSubscription;
  }

  updateActiveSubscription(val: CompanySubscription) {
    this.activeSubscription = val;
  }

  updateCompany(val: Company) {
    this.company = val;
  }

  getCompany(): Company {
    return this.company;
  }

  getCompanyLogo() {
    return this.companyLogo;
  }

  updateCompanyLogo(logo: string) {
    this.companyLogo = logo;
  }
  
}
