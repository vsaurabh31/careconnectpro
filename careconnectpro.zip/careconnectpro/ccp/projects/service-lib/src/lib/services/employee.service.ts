import { Injectable } from '@angular/core';
import {
  Employee,
  EmployeeSummary,
  EmployeeName,
  Department,
  AppRole,
  EmployeeProfile,
  IdentityAppUser
} from 'model-lib';
import { Subject } from 'rxjs';
import { CareConnectLocalStorage } from './localstorage.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private departments: Department[] = [];
  private appRoles: AppRole[] = [];
  private allEmployees: EmployeeSummary[] = [];
  private employeeNames: EmployeeName[];
  private isNewEmployee: boolean = false;
  private employee: Employee = {};
  public isRecordChanged$: Subject<boolean> = new Subject<boolean>();

  constructor(private localstore: CareConnectLocalStorage) {}

  initData() {
    this.employee = {};
  }

  /**
   * Method - return cached employee names from service
   */
  getEmployeeNames(): EmployeeName[] {
    return this.employeeNames;
  }

  getIsNewEmployee(): boolean {
    return this.isNewEmployee;
  }

  updateIsNewEmployee(val: boolean): void {
    this.isNewEmployee = val;
  }

  refreshView() {
    this.isRecordChanged$.next(true);
      }

  /**
   * Method - Get employee object from service
   */
  getEmployee() {
    return this.employee;
  }

  /**
   * Method - Update patient data
   * @param _patient
   */
  updateEmployee(_employee: Employee) {
    this.employee = _employee;
    this.isRecordChanged$.next(true);
  }

   updateAllEmployeeSummary(val: EmployeeSummary[]): void {
    this.allEmployees = val;
  }

  getAllEmployeeSummary(): EmployeeSummary[] {
    return this.allEmployees;
  }

  getSecurityRoles(): AppRole[] {
    return this.appRoles;
  }

  updateSecurityRoles(val: AppRole[]): void {
    this.appRoles = val;
  }

  getDepartments(): Department[] {
    return this.departments;
  }

  updateDepartments(val: Department[]): void {
    this.departments = val;
  }

  getDepartmentNameById(id: string) {
    let ret: string = '';
    if (this.departments) {
      let x: any = this.departments.find(x => x.id === id);
      if (x != null && x != undefined && x != '') {
        ret = x.name;
      }
    }
    return ret;
  }

  getRoleNameById(id: string) {
    let ret: string = '';
    if (this.appRoles) {
      let x: any = this.appRoles.find(x => x.id === id);
      if (x != null && x != undefined && x != '') {
        ret = x.name;
      }
    }
    return ret;
  }

  getEmployeeNameById(id: string) {
    let ret: string = '';
    if (this.appRoles) {
      let x: any = this.allEmployees.find(x => x.employeeId === id);
      if (x != null && x != undefined && x != '') {
        ret = x.firstName + ' ' + x.lastName;
      }
    }
    return ret;
  }

  updateEmployeeProfile(val: EmployeeProfile) {
    this.employee.profile = val;
  }

  updateEmployeeLoginInfo(val: IdentityAppUser) {
    this.employee.loginInfo = val;
  }
}
