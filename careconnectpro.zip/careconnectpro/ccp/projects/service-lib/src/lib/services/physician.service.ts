import { Injectable } from '@angular/core';
import {
  Physician,
  PhysicianPracticeArea,
} from 'model-lib';
import { map, catchError } from 'rxjs/operators';
import { SelectItem } from 'primeng/api';
import { BaseMethod } from '../shared';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PhysicianService extends BaseMethod {
  private allPhysicians: Physician[] = [];
  private physician: Physician = {};
  private isNewPhysician: boolean;
  private isNewPractice: boolean;
  private physicianPracticesSelect: SelectItem[] = [];
  public isPhysicanRecordChanged$: Subject<boolean> = new Subject<boolean>();

  private _physician: Physician = {};
  private _physicianPracticeArea: PhysicianPracticeArea = {};

  constructor() {
    super();
  }

  updateIsNewPractice(val: boolean) {
    this.isNewPractice = val;
  }

  getIsNewPractice() {
    return this.isNewPractice;
  }

  updatePhysicianPracticeSelect(val: SelectItem[]) {
    this.physicianPracticesSelect = val;
  }

  getPhysicianPracticeSelect(): SelectItem[] {
    return this.physicianPracticesSelect;
  }
  updateIsNewPhysician(val: boolean) {
    this.isNewPhysician = val;
  }

  getPhysician(): Physician {
    return this.physician;
  }

  getIsNewPhysician() {
    return this.isNewPhysician;
  }

  updateAllPhysicians(val: Physician[]): void {
    this.allPhysicians = val;
  }

  updatePhysician(val: Physician) {
    this.physician = val;
    this.isPhysicanRecordChanged$.next(true);
  } 
}
