import { EventEmitter, Injectable } from '@angular/core';
import { Event, NavigationEnd, Router } from '@angular/router';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class NavService {
  public appDrawer: any = {};
  private inTakeStep: number = 1;
  public inTakeStep$: Subject<number> = new Subject<number>();

  public currentUrl = new BehaviorSubject<string>(undefined);

  private changeStep = new BehaviorSubject('1');
  currentStep = this.changeStep.asObservable();

  constructor(private router: Router) {
    this.router.events.subscribe((event: Event) => {
      if (event instanceof NavigationEnd) {
        this.currentUrl.next(event.urlAfterRedirects);
      }
    });
  }

  public closeNav() {
    if (!!this.appDrawer && !!this.appDrawer.close) {
      this.appDrawer.close();
    }
  }

  public openNav() {
    if (!!this.appDrawer) {
      this.appDrawer.open();
    }
  }
  changeStatus(id) {
    this.changeStep.next(id);
  }
  
  nextInTakeStep() {
    if (this.inTakeStep < 7) {
      this.inTakeStep += 1;
      this.inTakeStep$.next(this.inTakeStep);
    }
  }

  prevInTakeStep() {
    if (this.inTakeStep > 1) {
      this.inTakeStep -= 1;
      this.inTakeStep$.next(this.inTakeStep);
    }
  }

  getInTakeStep() {
    return this.inTakeStep;
  }
  
  setInTakeStep(_step: number) {
    this.inTakeStep = _step;
    this.inTakeStep$.next(this.inTakeStep);
  }
}
