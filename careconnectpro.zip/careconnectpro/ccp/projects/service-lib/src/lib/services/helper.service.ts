import { Injectable } from '@angular/core';
import { ContactType, Contact, Identification, IdType, Address, PeoplePlacesCodes, AppConstants, IdTypeEntity, IdTypeConstants } from 'model-lib';


@Injectable({
  providedIn: 'root'
})
export class HelperService {

  constructor() { }

  getContactByType(contactType: string, contacts: Contact[]): Contact {
    let tmpVal: Contact = {};
    if (!!contacts) {
      const tmpValArray = contacts.filter(
        item => item.contactTypeId.toLowerCase() === contactType.toLowerCase()
      );
      if (tmpValArray.length > 0) {
        tmpVal = tmpValArray[0];
      }
    }
    return tmpVal;
  }

  /**
   * Get Person - employee, patient, vendor combined name - For example Mr. John Smith Sr.
   * @param T is the
   */
  getPersonCombinedFullName<T>(T) {
    let fullName = "";
    if (!!T.lastName) {
      if (!!T.prefix) {
        fullName += T.prefix + " ";
      }
      if (!!T.firstName) {
        fullName += T.firstName + " ";
      }
      if (!!T.middleName) {
        fullName += T.middleName + " ";
      }
      if (!!T.lastName) {
        fullName += T.lastName
      }
      if (!!T.suffix) {
        fullName += " " + T.suffix;
      }
    }
    return fullName;
  }
  
  getContactValueByContactId(contactId: string) {
    const contactTypes = PeoplePlacesCodes.ContactTypes;
    const val = contactTypes.find(item => item.id == contactId);
    if (!!val) {
      return val.value;
    } else {
      return null;
    }
  }

  /**
   * Method - Return contact type object based on the string id value
   * @param contactId 
   */
  getContactTypeByStringId(contactId: string): ContactType {
    let contactType: ContactType;
    switch (contactId.toLowerCase()) {
      case 'homephone':
        contactType = ContactType.homePhone;
        break;
      case 'workphone':
        contactType = ContactType.workPhone;
        break;
      case 'cellphone':
          contactType = ContactType.cellPhone;
          break;
      case 'email':
          contactType = ContactType.email;
          break;
      case 'fax':
          contactType = ContactType.fax;
          break;
      case 'url':
          contactType = ContactType.url;
          break;
    }
    return contactType;
  }

/**
 * Method - Return value of contact 
 * @param contactTypeVal 
 * @param contacts 
 */
  getContactById(contactTypeVal: string, contacts: Contact[]): string {
     const contact = this.getContactByType(contactTypeVal, contacts);
    return contact.value;
  }

  getIdentificationById(idType: IdType, idents: Identification[]): string {
    let tmpVal: Identification = {};
    if (!!idents) {
      const tmpValArray = idents.filter(
        item => item.idTypeId === idType
      );
      if (tmpValArray.length > 0) {
        tmpVal = tmpValArray[0];
      }
    }
    return tmpVal.value;
  }

  getIdentificationIdByTypeId(idType: IdType): string {
    let idName: string = "";
    switch(idType) {
      case IdType.driversLicense:
        idName = IdTypeConstants.DriversLicense;
        break;
      case IdType.ssn:
        idName = IdTypeConstants.Ssn;
        break;
      case IdType.hrn:
        idName = IdTypeConstants.Hrn;
        break;
      case IdType.evvid:
        idName = IdTypeConstants.EvvId;
        break;
      case IdType.medicalLicenseId:
        idName = IdTypeConstants.MedicalLicenseId; 
        break;   
      case IdType.npi:
        idName = IdTypeConstants.Npi;  
        break;
      case IdType.ssn:
        idName = IdTypeConstants.Ssn;  
        break;
      case IdType.hicn:
        idName = IdTypeConstants.Hicn; 
        break; 
      case IdType.medicareId:
        idName = IdTypeConstants.MedicareId;
        break;   
      case IdType.medicaidId:
        idName = IdTypeConstants.MedicaidId;
        break;
      case IdType.sandataAccountId:
        idName = IdTypeConstants.SandataAccountId; 
        break; 
      case IdType.fedTaxId:
        idName = IdTypeConstants.FedTaxId; 
        break;
      case IdType.stateAccountId:
        idName = IdTypeConstants.StateAssignedId; 
        break;
      }
       return idName;
  }
  

  getIdentificationValueByTypeId(idType: IdType, idEntity: IdTypeEntity): string {
    let idName: string = "";
    let idTypeName: string;
    switch(idType) {
      case IdType.driversLicense:
        idName = IdTypeConstants.DriversLicense;
        break;
      case IdType.ssn:
        idName = IdTypeConstants.Ssn;
        break;
      case IdType.hrn:
        idName = IdTypeConstants.Hrn;
        break;
      case IdType.evvid:
        idName = IdTypeConstants.EvvId;
        break;
      case IdType.medicalLicenseId:
        idName = IdTypeConstants.MedicalLicenseId; 
        break;   
      case IdType.npi:
        idName = IdTypeConstants.Npi;  
        break;
      case IdType.ssn:
        idName = IdTypeConstants.Ssn;  
        break;
      case IdType.hicn:
        idName = IdTypeConstants.Hicn; 
        break; 
      case IdType.medicareId:
        idName = IdTypeConstants.MedicareId;
        break;   
      case IdType.medicaidId:
        idName = IdTypeConstants.MedicaidId;
        break;
      case IdType.sandataAccountId:
        idName = IdTypeConstants.SandataAccountId; 
        break; 
      case IdType.fedTaxId:
        idName = IdTypeConstants.FedTaxId;
        break;
      case IdType.stateAccountId:
        idName = IdTypeConstants.StateAssignedId; 
        break;
      }

      switch (idEntity) {
        case IdTypeEntity.agency:
          const agencyId = PeoplePlacesCodes.AgencyIdentificationTypes.find(x => x.id==idName);
          if (!!agencyId) {
            idTypeName = agencyId.value;
          }
          break;     
        case IdTypeEntity.employee:
          const employeeId = PeoplePlacesCodes.EmployeeIdentificationTypes.find(x => x.id == idName);
          if (!!employeeId) {
            idTypeName = employeeId.value;
          }
          break;   
        case IdTypeEntity.patient:
          const patientId = PeoplePlacesCodes.PatientIdentificationTypes.find(x => x.id == idName);
          if (!!patientId) {
            idTypeName = patientId.value;
          }
          break;       
      }      
      return idTypeName;
  }
  
  getIdentificationTypeByStringType(idType: string): IdType {
    switch(idType) {
      case IdTypeConstants.DriversLicense:
        return IdType.driversLicense;
      case IdTypeConstants.Ssn:
        return IdType.ssn;
      case IdTypeConstants.Hrn:
        return IdType.hrn;
      case IdTypeConstants.EvvId:
        return IdType.evvid;
      case IdTypeConstants.MedicalLicenseId:
        return IdType.medicalLicenseId;       
      case IdTypeConstants.Npi:
        return IdType.npi;
      case IdTypeConstants.FedTaxId:
        return IdType.fedTaxId;
      case IdTypeConstants.Hicn:
        return IdType.hicn;
      case IdTypeConstants.MedicareId:
        return IdType.medicareId;   
      case IdTypeConstants.MedicaidId:
        return IdType.medicaidId; 
      case IdTypeConstants.SandataAccountId:
        return IdType.sandataAccountId;   
      case IdTypeConstants.StateAssignedId:
        return IdType.stateAccountId;   
      }
    }

  getIdentificationByType(idType: IdType, obj: any): Identification {
    let tmpVal: Identification = {};
    if (!!obj.identifications) {
      const tmpValArray = obj.identifications.filter(
        item => item.idTypeId === idType
      );
      if (tmpValArray.length > 0) {
        tmpVal = tmpValArray[0];
      }
    }
    return tmpVal;
  }

/**
 *  Method - Add or update object contacts 
 * @param _contactType 
 * @param val 
 */
  addUpdateContactByVal(_id: string, _contactType: string, val: string, obj: any): any {
    if (!obj.contacts) {
      obj.contacts = [];
    }
    const isExistIdx = obj.contacts.findIndex(
      item => item.contactTypeId.toLowerCase() === _contactType.toLowerCase()
    );
    if (isExistIdx > -1) {
      obj.contacts[isExistIdx].value = val;
    } else {
      obj.contacts.push({
        id: _id,
        contactTypeId: _contactType,
        value: val,
        dateCreated: obj.dateCreated,
        lastUpdatedDate: obj.lastUpdatedDate,
        lastUpdatedUserId: obj.lastUpdatedUserId,
      });
    }
    return obj;
  } 
  

  getSupportedImageFilesList(): string {
    const supportedFilesCount = AppConstants.ValidImageFiles.length;
    let supportedFiles: string = "";
    let startSeq = 1;
    AppConstants.ValidImageFiles.forEach(item => {
      supportedFiles += "*." + item;
      if (startSeq != supportedFilesCount) {
        supportedFiles += ",";
      }
      startSeq++;
    })
    return supportedFiles;
  }

  getSupportedImageFilesInputFileAccept(): string {
    const supportedFilesCount = AppConstants.ValidImageFiles.length;
    let supportedFiles: string = "";
    let startSeq = 1;
    AppConstants.ValidImageFiles.forEach(item => {
      supportedFiles +="image/" + item;
      if (startSeq != supportedFilesCount) {
        supportedFiles +=",";
      }
      startSeq++;
    })
    return supportedFiles;
  }
  
   /**
   * Method - Add or update object identifications
   * @param contactType
   * @param val
   */
  addUpdateIdentificationByVal(_id: string, _idType: IdType, val: string, obj: any): any {
    if (!obj.identifications) {
      obj.identifications = [];
    }
    const isExistIdx = obj.identifications.findIndex(
      item => item.idTypeId === _idType
    );
    if (isExistIdx > -1) {
      obj.identifications[isExistIdx].value = val;
    } else {
      obj.identifications.push({
        id: _id,
        idTypeId: _idType,
        value: val,
        issueAuthority: '',
        issueDate: new Date(),
        memo: '',
        dateCreated: obj.dateCreated,
        lastUpdatedDate: obj.lastUpdatedDate,
        lastUpdatedUserId: obj.lastUpdatedUserId
      });
    }
    return obj;
  }

    /**
   * Method - Get contact information - returns contact object
   *
   */
  getContact(contactType: string, obj: any): Contact {
    let tmpVal: Contact = {};
    if (!!obj.contacts) {
      const tmpValArray = obj.contacts.filter(
        item => item.contactTypeId.toLowerCase() === contactType.toLowerCase()
      );
      if (tmpValArray.length > 0) {
        tmpVal = tmpValArray[0];
      }
    }
    return tmpVal;
  }

  getIdentification(idType: IdType, obj: any): Identification {
    let tmpVal: Identification = {};
    if (!!obj.identifications) {
      const tmpValArray = obj.identifications.filter(
        item => item.idTypeId === idType
      );
      if (tmpValArray.length > 0) {
        tmpVal = tmpValArray[0];
      }
    }
    return tmpVal;
  }

    /**
   * Method - Add or Update address in object
   * @param addr
   */
  addUpdateAddress(addr: Address, obj: any): any {
    if (obj.addresses === undefined) {
      obj.addresses = [];
    }
    if (!!addr.id) {
      const idx = obj.addresses.findIndex(
        item => item.id === addr.id
      );
      if (idx > -1) {
        obj.addresses[idx] = addr;
      } else {
        obj.addresses.push(addr);
      }
    } else {
      obj.addresses.push(addr);
    }
    return obj;
  }

    /**
   * Method - Retrieve the primary address from obj
   */
  getPrimaryAddress(obj: any): Address {
    let tmpAddr: Address = {};
    if (!!obj.addresses) {
      const tmpAddrArray = obj.addresses.filter(
        item => item.isPrimary === true
      );
      if (!!tmpAddrArray && tmpAddrArray.length > 0) {
        tmpAddr = tmpAddrArray[0];
      }
    }
    return tmpAddr;
  }

/**
 * Method - Returned combined address detail for a generic object
 * @param obj 
 */
  getCombinedAddress(obj: any): string {
    const address = this.getPrimaryAddress(obj);
    return this.getCombinedAddressByAddress(address);
  }

  /**
   * Method - Return combined address for an address object. 
   * @param obj 
   */
  getCombinedAddressByAddress(address: Address): string {
    let _fullAddress = "";
    if (!!address.address1) {
      _fullAddress += address.address1;      
    }
    if (!!address.address2) {
      _fullAddress += ", " + address.address2;      
    }
    if (!!address.city) {
      _fullAddress += ", " + address.city;      
    }
    if (!!address.state) {
      _fullAddress += " " + address.state;      
    }
    if (!!address.zipCode) {
      _fullAddress += " " + address.zipCode;      
    }
    return _fullAddress;
  }

}

