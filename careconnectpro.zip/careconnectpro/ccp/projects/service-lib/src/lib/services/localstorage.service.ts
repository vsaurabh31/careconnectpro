import { Injectable } from '@angular/core';
import { CompanySystemSettings, UserLogin } from 'model-lib';

@Injectable({
  providedIn: 'root'
})
export class CareConnectLocalStorage {
  currentData: any;
  currentUser: UserLogin;
  currFullName: string = 'Anonymous User';

  constructor() {}


  storeAuthToken(val: string) {
    localStorage.setItem('ccpAuthToken', val);
  }
  getAuthToken() {
    const x: string = localStorage.getItem('ccpAuthToken');
    return x;
  }

}
