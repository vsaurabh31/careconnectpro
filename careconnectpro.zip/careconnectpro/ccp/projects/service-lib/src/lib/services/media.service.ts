import { Injectable } from '@angular/core';
import { Observable, Observer } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { APIUrls, MediaFile } from 'model-lib';
import { BaseMethod } from '../shared';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MediaService extends BaseMethod {
  public readonly defaultUserImage: string = '../../assets/images/avatar.png';
  public readonly defaultCompanyImage: string =
    '../../assets/images/defaultcompanylogo.png';

  constructor(private http: HttpClient) {
    super();
  }

  getDefaultUserImage(): Observable<string> {
    return new Observable(Observer => {
      Observer.next(this.defaultUserImage);
      Observer.complete();
    });
  }

  getDefaultCompanyImage(): Observable<string> {
    return new Observable(Observer => {
      Observer.next(this.defaultCompanyImage);
      Observer.complete();
    });
  }

  // mediaImagesCompanyGetAll(companyid: string): Observable<MediaFile> {
  //   var _Url = APIUrls.MediaImagesCompanyGetAll;
  //   return this.http.get(_Url + '/' + companyid).pipe(
  //     map((response: Response) => {
  //       console.log(response.json());
  //       var files = <MediaFile>response.json();
  //       return files;
  //     }),
  //     catchError(this.handleHttpResponseError$)
  //   );
  // }

  mediaImagesEmployeeGetAll(employeeid: string): Observable<MediaFile> {
    var _Url = APIUrls.MediaImagesEmployeeGetAll;
    return this.http.get(_Url + '/' + employeeid).pipe(
      map((response: Response) => {
        console.log(response.json());
        var files = <MediaFile>response.json();
        return files;
      }),
      catchError(this.handleHttpResponseError$)
    );
  }

  mediaImagesCompanyDelete(file: MediaFile): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: ''
      })
    };
    var params = JSON.stringify(file);
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    var _Url = APIUrls.MediaImagesCompanyDelete;
    return this.http.post(_Url, JSON.stringify(file), httpOptions).pipe(
      map((response: Response) => <string>response.statusText),
      catchError(this.handleHttpResponseError$)
    );
  }

  mediaImagesEmployeeDelete(file: MediaFile): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: ''
      })
    };
    var params = JSON.stringify(file);
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    var _Url = APIUrls.MediaImagesEmployeeDelete;
    return this.http.post(_Url, JSON.stringify(file), httpOptions).pipe(
      map((response: Response) => <string>response.statusText),
      catchError(this.handleHttpResponseError$)
    );
  }

  // mediaImagesCompanySave(file: MediaFile): Observable<string> {
  //   const httpOptions = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json',
  //       Authorization: ''
  //     })
  //   };
  //   var params = JSON.stringify(file);
  //   var headers = new HttpHeaders();
  //   headers.append('Content-Type', 'application/json');
  //   var _Url = APIUrls.MediaImagesCompanySave;
  //   return this.http.post(_Url, JSON.stringify(file), httpOptions).pipe(
  //     map((response: Response) => <string>response.statusText),
  //     catchError(this.handleHttpResponseError$)
  //   );
  // }

  mediaImagesEmployeeSave(file: MediaFile): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: ''
      })
    };
    var params = JSON.stringify(file);
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    var _Url = APIUrls.MediaImagesEmployeeSave;
    return this.http.post(_Url, JSON.stringify(file), httpOptions).pipe(
      map((response: Response) => <string>response.statusText),
      catchError(this.handleHttpResponseError$)
    );
  }

  mediaAttachmentSave(
    companyId: string,
    fileIds: string[]
  ): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: ''
      })
    };
    var params = JSON.stringify(fileIds);
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    var _Url = APIUrls.MediaAttachmentSave + '/' + companyId;
    return this.http.post(_Url, JSON.stringify(fileIds), httpOptions).pipe(
      map((response: Response) => <string>response.statusText),
      catchError(this.handleHttpResponseError$)
    );
  }

  mediaImagesPhysicianSave(file: MediaFile): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: ''
      })
    };
    var params = JSON.stringify(file);
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    var _Url = APIUrls.MediaImagesPhysicianSave;
    return this.http.post(_Url, JSON.stringify(file), httpOptions).pipe(
      map((response: Response) => <string>response.statusText),
      catchError(this.handleHttpResponseError$)
    );
  }

  mediaImagesPhysicianDelete(file: MediaFile): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: ''
      })
    };
    var params = JSON.stringify(file);
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    var _Url = APIUrls.MediaImagesPhysicianDelete;
    return this.http.post(_Url, JSON.stringify(file), httpOptions).pipe(
      map((response: Response) => <string>response.statusText),
      catchError(this.handleHttpResponseError$)
    );
  }

  mediaImagesPhysicianGetAll(physicianid: string): Observable<MediaFile> {
    var _Url = APIUrls.MediaImagesPhysicianGetAll;
    return this.http.get(_Url + '/' + physicianid).pipe(
      map((response: Response) => {
        console.log(response.json());
        var files = <MediaFile>response.json();
        return files;
      }),
      catchError(this.handleHttpResponseError$)
    );
  }

  mediaImagesVendorSave(file: MediaFile): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: ''
      })
    };
    var params = JSON.stringify(file);
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    var _Url = APIUrls.MediaImagesVendorSave;
    return this.http.post(_Url, JSON.stringify(file), httpOptions).pipe(
      map((response: Response) => <string>response.statusText),
      catchError(this.handleHttpResponseError$)
    );
  }

  mediaImagesVendorDelete(file: MediaFile): Observable<string> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: ''
      })
    };
    var params = JSON.stringify(file);
    var headers = new HttpHeaders();
    headers.append('Content-Type', 'application/json');
    var _Url = APIUrls.MediaImagesVendorDelete;
    return this.http.post(_Url, JSON.stringify(file), httpOptions).pipe(
      map((response: Response) => <string>response.statusText),
      catchError(this.handleHttpResponseError$)
    );
  }

  mediaImagesVendorGetAll(vendorid: string): Observable<MediaFile> {
    var _Url = APIUrls.MediaImagesVendorGetAll;
    return this.http.get(_Url + '/' + vendorid).pipe(
      map((response: Response) => {
        console.log(response.json());
        var files = <MediaFile>response.json();
        return files;
      }),
      catchError(this.handleHttpResponseError$)
    );
  }
}
