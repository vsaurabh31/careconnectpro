import { Injectable } from '@angular/core';
import {
  UserPaymentInfo,
} from 'model-lib';

@Injectable({
  providedIn: 'root'
})
export class BillingService {
  processPayment(responsePay: UserPaymentInfo) {
    responsePay.approvalCode = 'A649960002';
    responsePay.paymentStatus = 'Approved';
    return responsePay;
  }
}
