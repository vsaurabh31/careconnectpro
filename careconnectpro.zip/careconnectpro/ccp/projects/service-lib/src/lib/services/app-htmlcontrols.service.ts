import { Injectable } from '@angular/core';
import { MatTooltip } from '@angular/material/tooltip';
import { ConnectedPositionStrategy } from '@angular/cdk/overlay';

@Injectable({
  providedIn: 'root'
})
export class AppHtmlControlService {
  constructor(
  ) {}

  offSetToolTipLoc(msg: string, _toolTip: MatTooltip) {
    _toolTip.message=msg;
    _toolTip.show();
    let overlayConfig = _toolTip._overlayRef?.getConfig();
    let strategy = overlayConfig?.positionStrategy as ConnectedPositionStrategy;
    _toolTip._overlayRef?.updatePositionStrategy(strategy.withPositions([{
      originX: "center",
      originY: "bottom",
      overlayX: "center",
      overlayY: "top",
       offsetY: -0
    }
    ]));
    _toolTip._overlayRef?.updatePosition();
  }

  formatCcNumber(val: string): string {
    if (!val) {
      val = '';
    }
    switch (val.length) {
      case 4:
        val += '-';
        break;
      case 9:
        val += '-';
        break;
      case 14:
        val += '-';
        break;
    }
    return val;
  }

  formatMmYyyy(val: string): string {
    if (!val) {
      val = '';
    }
    if (val.length == 2) {
      val += '/';
    }
    return val;
  }

  formatPhoneNumber(val: string): string {
    if (!val) {
      val = '';
    }
    switch (val.length) {
      case 0:
        val += '(';
        break;
      case 4:
        val += ') ';
        break;
      case 9:
        val += '-';
        break;
    }
    return val;
  }

  
}
