import { HostListener, Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import {
  AppNotificationMessage,
  AlertSeverityType,
  AlertType,
  WindowSize
} from 'model-lib';

@Injectable({
  providedIn: 'root'
})
export class AlertService {
  private isDisplayExceptionAlertMsg: boolean;

  public appToastMessage$: Subject<AppNotificationMessage> = new Subject<
    AppNotificationMessage
  >();
  public appSystemMessage$: Subject<AppNotificationMessage> = new Subject<
    AppNotificationMessage
  >();
  public appDialogMessage$: Subject<AppNotificationMessage> = new Subject<
    AppNotificationMessage
  >();
  public showSpinner$: Subject<boolean> = new Subject<boolean>();
  private appMessage: AppNotificationMessage = {};
  public windowSize$: Subject<WindowSize> = new Subject<WindowSize>();
  private windowSize: WindowSize = {};

  updateWindowSize(val: WindowSize){
    this.windowSize = val;
    this.windowSize$.next(val);
  }

  getWindowSize(){
  return this.windowSize;
  }

  displayInfoMessage(
    messageType: AlertType,
    msgSummary: String,
    msgDetail: String
  ) {
    let _msg: AppNotificationMessage = {
      messageType: AlertSeverityType.Info,
      detail: msgDetail,
      summary: msgSummary
    };
    this.postAlert(messageType, _msg);
  }
  displaySuccessMessage(
    messageType: AlertType,
    msgSummary: String,
    msgDetail: String
  ) {
    let _msg: AppNotificationMessage = {
      messageType: AlertSeverityType.Success,
      detail: msgDetail,
      summary: msgSummary
    };
    this.postAlert(messageType, _msg);
  }
  displayWarningMessage(
    messageType: AlertType,
    msgSummary: String,
    msgDetail: String
  ) {
    let _msg: AppNotificationMessage = {
      messageType: AlertSeverityType.Warning,
      detail: msgDetail,
      summary: msgSummary
    };
    this.postAlert(messageType, _msg);
  }
  displayErrorMessage(
    messageType: AlertType,
    msgSummary: String,
    msgDetail: String
  ) {
    let _msg: AppNotificationMessage = {
      messageType: AlertSeverityType.Error,
      detail: msgDetail,
      summary: msgSummary
    };
    this.postAlert(messageType, _msg);
  }

  showSpinner(val: boolean): void {
    this.showSpinner$.next(val);
  }

  private postAlert(messageType: AlertType, msg: AppNotificationMessage) {
    this.appMessage = msg;
    switch (messageType) {
      case AlertType.Toast:
        this.appToastMessage$.next(msg);
        break;
      case AlertType.Dialog:
        this.appDialogMessage$.next(msg);
        break;
      case AlertType.Message:
        this.appSystemMessage$.next(msg);
        break;
    }
  }

  public getMessageNotification(): AppNotificationMessage {
    return this.appMessage;
  }

  setDisplayExceptionAlertMsg(val: boolean) {
    this.isDisplayExceptionAlertMsg = val;
  }

  getDisplayExceptionAlertMsg() {
    return this.isDisplayExceptionAlertMsg;
  }

}
