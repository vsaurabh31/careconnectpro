import { Injectable, EventEmitter } from '@angular/core';
import {
  APIUrls,
  AppUserType,
  IdentityAppUser,
  AppAsset,
  AppRole,
  AppRolePermission
} from 'model-lib';
import { map, catchError } from 'rxjs/operators';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Http, Headers } from '@angular/http';
import { CareConnectLocalStorage } from './localstorage.service';
import { HttpHeaders } from '@angular/common/http';
import { BaseMethod } from '../shared';
import { DataService } from './data.service';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SecurityService {
  public isAppRoleUpdated$: Subject<boolean> = new Subject<boolean>();

  constructor() { }

  refreshView() {
    this.isAppRoleUpdated$.next(true);
  }

  
}
