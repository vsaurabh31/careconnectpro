import { Injectable } from '@angular/core';
import { Episode, GenericIdValue, GenericSearch } from 'model-lib';
import { Subject } from 'rxjs/Subject';

@Injectable({
  providedIn: 'root'
})
export class EpisodeService {

  public episodeChanged$: Subject<Episode> = new Subject<Episode>();
  private episode: Episode = {};
  public serviceRequestedDropDown$: Subject<GenericIdValue[]> = new Subject<GenericIdValue[]>();
  private serviceRequestedDropDown: GenericIdValue[] = [];
  private employeesDropDown: GenericIdValue[] = [];
  public employeesDropDown$: Subject<GenericIdValue[]> = new Subject<GenericIdValue[]>();
  private episodeSearch: GenericSearch = {};
  private isHeaderSearchTriggered: boolean = false;
  public executeEpisodeSearch$: Subject<boolean> = new Subject<boolean>();

  constructor() { }

  updateEpisode(episode: Episode) {
    this.episode = { ...episode };
    this.episodeChanged$.next(this.episode);
  }

  getEpisode() {
    return this.episode;
  }

  updateServiceRequestedDropDown(val: GenericIdValue[]) {
    this.serviceRequestedDropDown = val;
    this.serviceRequestedDropDown$.next(val);
  }

  getServiceRequestedDropDown() {
    return this.serviceRequestedDropDown;
  }

  getServiceRequestedTypeById(val: string) {
    const serviceRequested = this.serviceRequestedDropDown.find(item => item.id == val);
    if (!serviceRequested) {
      return "";
    }
    return serviceRequested.value;
  }
  updateEmployeesDropDown(val: GenericIdValue[]) {
    this.employeesDropDown = val;
    this.employeesDropDown$.next(val);
  }

  getEmployeesDropDown() {
    return this.employeesDropDown;
  }

  getEmployeeById(val: string) {
    const _employee = this.employeesDropDown.find(item => item.id == val);
    if (!_employee) {
      return "";
    }
    return _employee.value;
  }

  getTriggerHeaderSearch() {
    return this.isHeaderSearchTriggered
  }

  updateTriggerHeaderSearch(val: boolean) {
    this.isHeaderSearchTriggered = val;
  }

  getSearchKeyword() {
    return this.episodeSearch;
  }

  setSearchKeyword(val: GenericSearch) {
    this.episodeSearch = val;
    if (this.episodeSearch.searchKeyword != '') {
      this.executeEpisodeSearch$.next(true);
    } else {
      this.executeEpisodeSearch$.next(false);
    }
  }

}
