import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { DocumentType } from 'model-lib';

@Injectable({
  providedIn: 'root'
})
export class TaskManagementService {

  activePatientId: string = "";
  activeEpisodeId: string = "";
  activeWorkflowDocument: string = "";
  documentTypes: DocumentType[] = [];
  documentTypesChanged$: Subject<DocumentType[]> = new Subject<DocumentType[]>();
  patientChanged$: Subject<string> = new Subject<string>();
  episodeChanged$: Subject<string> = new Subject<string>();
  workflowDocumentChanged$: Subject<string> = new Subject<string>();
  documentSectionChanged$: Subject<string> = new Subject<string>();
  documentSection: string = "";
  isSaveDraft$: Subject<boolean> = new Subject<boolean>();
  isCompleteDocument$: Subject<boolean> = new Subject<boolean>();

    constructor() { }

    updateActivePatient(id: string) {
      this.activePatientId = id;
      this.patientChanged$.next(id);
    }

    getActivePatient() {
      return this.activePatientId;
    }

    updateActiveEpisode(id: string) {
      this.activeEpisodeId = id;
      this.episodeChanged$.next(id);
    }
    getActiveEpisode() {
      return this.activeEpisodeId;
    }
    updateActiveWorkflowDocument(id: string) {
      this.activeWorkflowDocument = id;
      this.workflowDocumentChanged$.next(id);
    }

    getActiveWorkflowDocument() {
      return this.activeWorkflowDocument;
    }

    getDocumentTypes() {
      return this.documentTypes;
    }
    updateDocumentTypes(docTypes: DocumentType[]) {
      this.documentTypes = [...docTypes];
      this.documentTypesChanged$.next(this.documentTypes);
    }

    updateDocumentSection(docSection: string) {
      this.documentSection = docSection;
      this.documentSectionChanged$.next(this.documentSection);
    }

    saveDocumentDraft(){
      this.isSaveDraft$.next(true);
    }
    CompleteDocument() {
      this.isCompleteDocument$.next(true);
    }
}
