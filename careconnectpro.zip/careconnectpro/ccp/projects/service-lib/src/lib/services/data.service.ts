import { Injectable } from '@angular/core';
import { map, catchError } from 'rxjs/operators';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { BaseMethod } from '../shared';
import { CareConnectLocalStorage } from './localstorage.service';

@Injectable({
  providedIn: 'root'
})
export class DataService extends BaseMethod {
  /**
   * Method - Constructor
   */
  constructor(
    private http: HttpClient,
    private localStore: CareConnectLocalStorage
  ) {
    super();
  }

   /**
   *  Method - Http client Get call to retrieve from data service using URL Query Params
   * @param obj 
   * @param endPoint 
   * @param queryParams 
   */
  getDataListUsingUrlParams<T>(obj: T, endPoint: string, queryParams?: any) {
    const _httpParams = new HttpParams({
      fromObject: queryParams
    });

    let authToken = this.localStore.getAuthToken();
    if (!authToken) {
      authToken = '';
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: authToken
      }),
      params: _httpParams      
    };

    return this.http.get(endPoint, httpOptions).pipe(
      map((ret: any) => {
        const val: T[] = ret;
        return val;
      }),
      catchError(this.handleHttpResponseError$)
    );
  }

  /**
   *  Method - Http client Get call to retrieve from data service using URL Query Params
   * @param obj - Return object
   * @param endPoint 
   * @param queryParams 
   */
  getSingleDataUsingUrlParams<T>(obj: T, endPoint: string, queryParams?: any) {
    const _httpParams = new HttpParams({
      fromObject: queryParams
    });

    let authToken = this.localStore.getAuthToken();
    if (!authToken) {
      authToken = '';
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: authToken
      }),
      params: _httpParams      
    };

    return this.http.get(endPoint, httpOptions).pipe(
      map((ret: any) => {
        const val: T = ret;
        return val;
      }),
      catchError(this.handleHttpResponseError$)
    );
  }

  /**
   * Method - Http client call to retrieve array of data from data service
   * @param obj
   * @param id
   * @param endPoint
   */
  getAllData<T>(obj: T, id: string, endPoint: string): any {


    let authToken = this.localStore.getAuthToken();
    if (!authToken) {
      authToken = '';
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: authToken
      })    
    };

    return this.http.get(endPoint + '/' + id, httpOptions).pipe(
      map((ret: any) => {
        const val: T[] = ret;
        return val;
      }),
      catchError(this.handleHttpResponseError$)
    );
  }

  /**
   * Method - Http client call to retrieve single data from data service
   * @param obj
   * @param id
   * @param endPoint
   */
  getSingleData<T>(obj: T, id: string, endPoint: string): any {
    let authToken = this.localStore.getAuthToken();
    if (!authToken) {
      authToken = '';
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: authToken
      })
    };
    return this.http.get(endPoint + '/' + id, httpOptions).pipe(
      map((ret: any) => {
        const val: T = ret;
        return val;
      }),
      catchError(this.handleHttpResponseError$)
    );
  }

  /**
   * Method - Http post to call web api
   * @param obj
   * @param endPoint
   */
  postData<T>(obj: T, endPoint: string, sendRaw?: boolean): any {
    let authToken = this.localStore.getAuthToken();
    if (!authToken) {
      authToken = '';
    }
    let httpOptions: any = {};
    if (sendRaw) {
      httpOptions = {
        headers: new HttpHeaders({
          Authorization: authToken
        })
      };
    } else {
      httpOptions = {
        headers: new HttpHeaders({
          'Content-Type': 'application/json',
          Authorization: authToken
        })
      };
    }

    var params = JSON.stringify(obj);
    return this.http
      .post(endPoint, sendRaw? obj: params, httpOptions)
      .pipe(catchError(this.handleHttpResponseError$));
  }


  /**
   * Method - Http put to call web api
   * @param obj
   * @param endPoint
   */
  updateData<T>(obj: T, endPoint: string): any {
    var params = JSON.stringify(obj);
    let authToken = this.localStore.getAuthToken();
    if (!authToken) {
      authToken = '';
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: authToken
      })
    };
    return this.http
      .put(endPoint, params, httpOptions)
      .pipe(catchError(this.handleHttpResponseError$));
  }

  /**
   * Method - Http delete
   * @param id
   * @param endPoint
   */
  deleteData(id: string, endPoint: string): any {
    let authToken = this.localStore.getAuthToken();
    if (!authToken) {
      authToken = '';
    }
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        Authorization: authToken
      })
    };
    return this.http
      .delete(endPoint + '/' + id, httpOptions)
      .pipe(catchError(this.handleHttpResponseError$));
  }
}
