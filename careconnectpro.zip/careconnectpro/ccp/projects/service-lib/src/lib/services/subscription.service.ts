import { Injectable } from '@angular/core';
import {
  SubscriptionPackage,
  UserSignup,
  CompanySubscription,
  UserBillingInfo,
  UserPaymentInfo,
  SignupWorkflow
} from 'model-lib';
import { Observable, Subject } from 'rxjs';
import { GovernmentMedicalInsurance } from 'model-lib';

@Injectable({
  providedIn: 'root'
})
export class SubscriptionService {
  private activeTab: string = 'register';
  public activeTab$: Subject<string> = new Subject<string>();
  public companySubscription$: Subject<CompanySubscription> = new Subject<
    CompanySubscription
  >();
  public companyRegistration$: Subject<UserSignup> = new Subject<UserSignup>();
  public billingInfo$: Subject<UserBillingInfo> = new Subject<
    UserBillingInfo
  >();
  public paymentInfo$: Subject<UserPaymentInfo> = new Subject<
    UserPaymentInfo
  >();
  public signupWorkflow$: Subject<SignupWorkflow> = new Subject<
    SignupWorkflow
  >();

  private companySubscription: CompanySubscription = {};
  private companyRegistration: UserSignup = {};
  private billingInfo: UserBillingInfo = {};
  private paymentInfo: UserPaymentInfo = {};
  private signupWorkFlow: SignupWorkflow = {};
  public openBillingGovAid$: Subject<GovernmentMedicalInsurance> = new Subject<
    GovernmentMedicalInsurance
  >();

  private subscriptionPackages: SubscriptionPackage[] = [
    { id: '1001', packageType: 'Trial', packageName: 'Trial', amount: 0 },
    { id: '1002', packageType: 'Monthly', packageName: 'Basic', amount: 499 },
    { id: '1003', packageType: 'Monthly', packageName: 'Pro', amount: 1499 }
  ];

  openBillingGovInsurance(govInsurance: GovernmentMedicalInsurance): void {
    this.openBillingGovAid$.next(govInsurance);
  }

  getSubscriptionPackages(): SubscriptionPackage[] {
    return this.subscriptionPackages;
  }

  getActiveTab(): string {
    return this.activeTab;
  }

  setSignupWorkflow(val: SignupWorkflow): void {
    this.signupWorkFlow = val;
    this.signupWorkflow$.next(val);
  }

  getSignupWorkflow(): SignupWorkflow {
    return this.signupWorkFlow;
  }

  getCompanySubscription(): CompanySubscription {
    return this.companySubscription;
  }

  getCompanyRegistration(): UserSignup {
    return this.companyRegistration;
  }

  getBillingInfo(): UserBillingInfo {
    return this.billingInfo;
  }

  getPaymentInfo(): UserPaymentInfo {
    return this.paymentInfo;
  }

  setCompanySubscription(val: CompanySubscription): void {
    this.companySubscription = val;
    this.companySubscription$.next(val);
  }

  setActiveTab(val: string): void {
    this.activeTab = val;
    this.activeTab$.next(val);
  }

  setBillingInfo(val: UserBillingInfo): void {
    this.billingInfo = val;
    this.billingInfo$.next(val);
  }

  setPaymentInfo(val: UserPaymentInfo): void {
    this.paymentInfo = val;
    this.paymentInfo$.next(val);
  }

  setCompanyRegistration(val: UserSignup): void {
    this.companyRegistration = val;
    this.companyRegistration$.next(val);
  }

  getSubscriptionPackagePrice(pkgName: string) {
    if (!pkgName) {
      return 0;
    }
    let _package = this.subscriptionPackages.filter(
      x => x.packageName.toLowerCase() == pkgName.toLowerCase()
    );
    if (_package.length > 0) {
      return _package[0].amount;
    }
    return 0;
  }
}
