import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-service-lib',
  template: `
    <p>
      service-lib works!
    </p>
  `,
  styles: []
})
export class ServiceLibComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
