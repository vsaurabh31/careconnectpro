import { Observable, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { AppMessage } from 'model-lib';

export class BaseMethod {
  handleHttpResponseError$ = (error: HttpErrorResponse) => {
    let errorMessage: string = AppMessage.GenericApiError;
    switch (error.status) {
      case 400:
        errorMessage = error.error.ResponseMessage;
        break;
      case 401:
        errorMessage = AppMessage.ApiAccessDenied;
        break;
      case 0:
      case 500:
      default:
        errorMessage = AppMessage.GenericApiError;
        break;
    }

    if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', errorMessage);
    } else {
      console.error(
        `CareConnectPro Api return status code: ${error.status}, ` + ` Response message: ${errorMessage}`
      );
    }

    return throwError(errorMessage);
  };

  logConsoleText = (error: any) => {
    console.log(error);
  };
}
