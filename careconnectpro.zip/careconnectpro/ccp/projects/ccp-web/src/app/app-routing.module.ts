import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminLayoutComponent } from './layout/admin-layout/admin-layout.component';
import { AuthLayoutComponent } from './layout/auth-layout/auth-layout.component';
import { ResetPasswordComponent } from '../app/pages/login/reset-password.component';

const routes: Routes = [
  { path: '', redirectTo: 'landing', pathMatch: 'full' },

  {
    path: 'landing',
    component: AuthLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/landing/landing.module').then((m) => m.LandingModule),
      },
    ],
  },
  {
    path: 'resetpassword/:token',
    component: ResetPasswordComponent,
  },
  {
    path: 'profile',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/profile/profile.module').then((m) => m.ProfileModule),
      },
    ],
  },
  {
    path: 'home', redirectTo: 'dashboard'
  },
  {
    path: 'dashboard',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/dashboard/dashboard.module').then((m) => m.DashboardModule),
      },
    ],
  },
  {
    path: 'patient',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/patient/patient.module').then((m) => m.PatientModule),
      },
    ],
  },
  {
    path: 'options',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/options/options.module').then((m) => m.OptionsModule),
      },
    ],
  },
  {
    path: 'calendar',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/calendar-event/calendar-event.module').then((m) => m.CalendarEventModule),
      },
    ],
  },
  {
    path: 'message',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/messaging/app-messaging.module').then((m) => m.AppMessagingModule),
      },
    ],
  },
  {
    path: 'episode',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/episode/episode-management.module').then((m) => m.EpisodeManagementModule),
      },
    ],
  },
  {
    path: 'task',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/task/task-management.module').then((m) => m.TaskManagementModule),
      },
    ],
  },
  {
    path: 'case',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/case/case-management.module').then((m) => m.CaseManagementModule),
      },
    ],
  },
  {
    path: 'billing',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/billing/billing.module').then((m) => m.BillingModule),
      },
    ],
  },
  {
    path: 'reports',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/reports/reports.module').then((m) => m.ReportsModule),
      },
    ],
  },
  {
    path: 'thirdparty',
    component: AdminLayoutComponent,
    children: [
      {
        path: '',
        loadChildren: () =>
          import('./pages/thirdparty/thirdparty.module').then((m) => m.ThirdpartyModule),
      },
    ],
  },
  { path: '**', redirectTo: 'landing' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}