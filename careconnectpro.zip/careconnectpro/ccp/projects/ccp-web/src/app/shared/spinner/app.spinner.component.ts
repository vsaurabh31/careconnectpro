import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-spinner',
  templateUrl: './app.spinner.component.html'
})
export class AppSpinnerComponent implements OnInit {
  ngOnInit() {}
}
