import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { NavbarModule } from './navbar/navbar.module';
import { SidebarModule } from './sidebar/sidebar.module';
import { FormsModule } from '@angular/forms';

//Angular material modules
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatTabsModule } from '@angular/material/tabs';
import { MatDatepickerModule } from '@angular/material/datepicker';
import {MatNativeDateModule} from '@angular/material/core';
import { MatMomentDateModule } from "@angular/material-moment-adapter";
import { MatIconModule } from "@angular/material/icon";
import { MatTooltipModule } from "@angular/material/tooltip";
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { MatChipsModule }  from "@angular/material/chips";
import { MatExpansionModule } from '@angular/material/expansion';
import {MatMenuModule} from '@angular/material/menu';
import {
  NgxMatDatetimePickerModule,
  NgxMatNativeDateModule,
  NgxMatTimepickerModule
} from '@angular-material-components/datetime-picker';

//PrimeNg modules
import { ToastModule } from 'primeng/toast';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { DialogModule } from 'primeng/dialog';

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { WatchDemoComponent } from './modal/watch-demo/watch-demo.component';
import { ForgotComponent } from './modal/forgot/forgot.component';
import { EmailRegisterConfirmComponent } from './modal/email-register-confirm/email-register-confirm.component';
import { PaymentConfirmComponent } from './modal/payment-confirm/payment-confirm.component';

import { PhysicianComponent } from './modal/physician/physician.component';
import { ConfirmDeleteComponent } from './modal/confirm-delete/confirm-delete.component';

import { GenericMessageComponent } from './modal/generic-message/generic-message.component';
import { MedicalProviderComponent } from './modal/medical-provider/medical-provider.component';
import { MedicationsComponent } from './modal/medications/medications.component';
import { AllergiesComponent } from './modal/allergies/allergies.component';
import { DiagnosisComponent } from './modal/diagnosis/diagnosis.component';
import { ServiceRequestedComponent } from './modal/service-requested/service-requested.component';
import { ConditionHistoryComponent } from './modal/condition-history/condition-history.component';
import { SocialHistoryComponent } from './modal/social-history/social-history.component';
import { FamilyHistoryComponent } from './modal/family-history/family-history.component';
import { PatientComponent } from './modal/patient/patient.component';
import { PatientAddressComponent } from './modal/address/patient/patient-address.component';
import { PatientContactComponent } from './modal/contact/patient/patient-contact.component';
import { PatientExtraDetailComponent } from './modal/extradetail/patient/patient-extradetail.component';
import { PatientGuarantorComponent } from './modal/patient-guarantor/patient-guarantor.component';
import { PrivateInsuranceComponent } from './modal/private-insurance/private-insurance.component';
import { PatientPaymentProfileComponent } from './modal/payment/patient-payment-profile.component';
import { GovernmentInsuranceComponent } from './modal/government-insurance/government-insurance.component';
import { BroadcastMessageComponent } from './modal/broadcast-message/broadcast-message.component';
import { BroadcastComposeComponent } from './modal/broadcast-compose/broadcast-compose.component';
import { SecurityRoleComponent } from './modal/security-role/security-role.component';
import { SecurityUserComponent } from './modal/security-user/security-user.component';
import { SecurityPermissionComponent } from './modal/security-permission/security-permission.component';
import { EditLoginComponent } from './modal/edit-login/edit-login.component';
import { EditWorkComponent } from './modal/edit-work/edit-work.component';
import { EditPersonalComponent } from './modal/edit-personal/edit-personal.component';
import { EditAboutMeComponent } from './modal/edit-about-me/edit-about-me.component';
import { EditAgencyComponent } from './modal/edit-agency/edit-agency.component';
import { LocationComponent } from './modal/location/location.component';
import { DepartmentComponent } from './modal/department/department.component';
import { CompanyLogoComponent } from './modal/company/company-logo.component';
import { AdvancedComponent } from './modal/advanced/advanced.component';
import { PhysicianSearchComponent } from './modal/physician/physician-search.component';
import { MedicalProviderSearchComponent } from './modal/medical-provider/medical-provider-search.component';
import { CcpDataTableComponent } from './ccp-data-table/ccp-data-table.component';
import { IcdSearchComponent } from './modal/icd-search/icd-search.component';
import { MedicalInsuranceProviderComponent } from './modal/medical-insurance-provider/medical-insurance-provider.component';
import { MedicalInsuranceProviderSearchComponent } from './modal/medical-insurance-provider/medical-insurance-provider-search.component';
import { AgencyIntakeExtradetailComponent } from './modal/options/extradetails/agency-intake-extradetail.component';
import { AgencyServiceComponent } from './modal/options/agencyservice/agency-service.component';
import { MedicalHistoryAddupdateComponent } from './modal/options/medicalhistory/medical-history-addupdate.component';

import { AngularEditorModule } from "@kolkov/angular-editor";
import { AgencyContactComponent } from './modal/contact/agency/agency-contact.component';
import { AgencyIdentificationComponent } from './identification/agency/agency-identification.component';
import { LinkedPatientsComponent } from './modal/linked-patients/linked-patients.component';
import { GenericIdentificationComponent } from './modal/identification/generic-identification.component';
import { GenericAddressComponent } from './modal/address/generic-address.component';
import { GenericContactComponent } from './modal/contact/generic-contact.component';
import { ModalPatientSearchComponent } from './modal/patient-search/patient-search.component';

@NgModule({
  declarations: [
    WatchDemoComponent,
    ForgotComponent,
    EmailRegisterConfirmComponent,
    PaymentConfirmComponent,
    PhysicianComponent,
    ConfirmDeleteComponent,
    MedicalProviderComponent,
    MedicationsComponent,
    AllergiesComponent,
    DiagnosisComponent,
    ServiceRequestedComponent,
    ConditionHistoryComponent,
    SocialHistoryComponent,
    FamilyHistoryComponent,
    PatientComponent,
    PatientAddressComponent,
    PatientContactComponent,
    PatientExtraDetailComponent,
    PatientGuarantorComponent,
    PrivateInsuranceComponent,
    PatientPaymentProfileComponent,
    GovernmentInsuranceComponent,
    BroadcastMessageComponent,
    BroadcastComposeComponent,
    SecurityRoleComponent,
    SecurityUserComponent,
    SecurityPermissionComponent,
    EditLoginComponent,
    EditWorkComponent,
    EditPersonalComponent,
    EditAboutMeComponent,
    EditAgencyComponent,
    LocationComponent,
    DepartmentComponent,
    CompanyLogoComponent,
    AdvancedComponent,
    PhysicianSearchComponent,
    MedicalProviderSearchComponent,
    CcpDataTableComponent,
    IcdSearchComponent,
    MedicalInsuranceProviderComponent,
    MedicalInsuranceProviderSearchComponent,
    AgencyIntakeExtradetailComponent,
    AgencyServiceComponent,
    MedicalHistoryAddupdateComponent,
    AgencyContactComponent,
    AgencyIdentificationComponent,
    LinkedPatientsComponent,
    GenericIdentificationComponent,
    GenericAddressComponent,
    GenericContactComponent,
    ModalPatientSearchComponent
  ],
  imports: [
    RouterModule,
    CommonModule,
    FormsModule,
    MatExpansionModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatCardModule,
    MatToolbarModule,
    MatSidenavModule,
    MatDialogModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMomentDateModule,
    MatChipsModule,
    MatMenuModule,
    ToastModule,
    MessageModule,
    MessagesModule,
    DialogModule,
    MatTabsModule,
    MatTooltipModule,
    MatIconModule,
    MatProgressSpinnerModule,
    NgbModule,
    AngularEditorModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule
  ],
  exports: [
    FormsModule,
    MatExpansionModule,
    MatButtonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatCardModule,
    MatToolbarModule,
    MatSidenavModule,
    MatDialogModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatMenuModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMomentDateModule,
    MatTooltipModule,
    MatIconModule,
    MatChipsModule,
    ToastModule,
    MessageModule,
    MessagesModule,
    DialogModule,
    MatTabsModule,
    MatProgressSpinnerModule,
    NgbModule,
    AngularEditorModule,
    NgxMatDatetimePickerModule,
    NgxMatTimepickerModule,
    NgxMatNativeDateModule
  ],
  providers: []
})
export class SharedModule {}
