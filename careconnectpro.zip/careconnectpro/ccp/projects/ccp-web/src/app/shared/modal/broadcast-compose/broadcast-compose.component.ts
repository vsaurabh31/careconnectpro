import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { AngularEditorConfig } from "@kolkov/angular-editor";
import { AlertType, APIUrls, SystemBroadcastDetail, UserSession } from 'model-lib';
import { AlertService, AuthService, DataService, AppMessageService, SignalrhubService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';



@Component({
  selector: 'app-broadcast-compose',
  templateUrl: './broadcast-compose.component.html',
  styleUrls: ['./broadcast-compose.component.scss'],
})
export class BroadcastComposeComponent extends BaseComponent implements OnInit {
  messageDetail: SystemBroadcastDetail = {};
  isProcessing: boolean = false;
  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: "20rem",
    minHeight: "5rem",
    placeholder: "Enter text here...",
    translate: "no",
    uploadUrl: "v1/images"
  };
  constructor(
    private alertService: AlertService,
    private dataService: DataService,
    private authService: AuthService,
    private appMessageService: AppMessageService,
    private hubService: SignalrhubService,
    public dialogRef: MatDialogRef<BroadcastComposeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit() {
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data: UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
  }


  closeDialog() {
    this.dialogRef.close();
  }

  submitForm() {
    this.dbAddBroadcast();
  }

  dbAddBroadcast() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.messageDetail.fileAttachments = [];
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.messageDetail, APIUrls.SystemBroadcast)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (data) {
            this.alertService.displaySuccessMessage(AlertType.Toast, "", "Broadcast message sent successfully");
            this.appMessageService.reloadBroadcastMessages();
            this.hubService.sendBroadcastMsg(data);
            this.closeDialog();
          } 
                    
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
