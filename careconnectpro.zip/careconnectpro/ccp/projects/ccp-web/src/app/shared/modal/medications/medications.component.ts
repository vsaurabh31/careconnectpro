import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { PatientMedication, UserSession, Patient, AlertType, AppMessage, APIUrls } from 'model-lib';
import { Guid } from 'guid-typescript';
import { AuthService, PatientService, AlertService, DataService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-medications',
  templateUrl: './medications.component.html',
  styleUrls: ['./medications.component.scss']
})
export class MedicationsComponent extends BaseComponent implements OnInit {
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  medication: PatientMedication = {};
  patient: Patient = {};
  isInTakeMode: boolean = false;

  constructor(
    private authService: AuthService,
    private patientService: PatientService,
    private alertService: AlertService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<MedicationsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit() {
    this.initData();
    this.isEditMode = this.data.editMode;
    if (!this.isEditMode) {
      this.medication.id = Guid.create().toString();
    } else {
      this.medication = { ...this.data.value };
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
      this.isInTakeMode = this.patientService.getInTakeMode();
      this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
        .subscribe(val => {
          this.isInTakeMode = val;
        });
        this.isInTakeMode = this.patientService.getInTakeMode();
        this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
          .subscribe(val => {
            this.isInTakeMode = val;
          });
  }

  initData() {
    this.patient = this.patientService.getPatient();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {
    this.patient = this.patientService.getPatient();
    this.medication.patientId = this.patient.id;
    if (!this.patient.medications) {
      this.patient.medications = [];
    }
    
    if (this.isInTakeMode) {
      this.updateView();
    } else {
      if (this.isEditMode) {
        this.dbUpdateHistory();
      } else {
        this.dbAddHistory();
      }
    }  
  }

  dbAddHistory() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.medication, APIUrls.PatientMedication)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.medication.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateHistory() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.medication, APIUrls.PatientMedication)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView() {
    let _isSuccess = false;
    let alertMsg: string = "";
    if (!this.isEditMode) {
      if (this.patient.medications.findIndex(item => item.id == this.medication.id) < 0) {
        this.patient.medications.push(this.medication);
        _isSuccess = true;
        alertMsg = 'Medication record added!';
      } else {
        this.alertService.displayErrorMessage(AlertType.Toast, '',
          "Medication record already exist in patient record.");
      }
    } else {
      let _index = this.patient.medications.findIndex(item => item.id == this.medication.id);
      if (_index > - 1) {
        this.patient.medications[_index] = this.medication;
        _isSuccess = true;
        alertMsg = 'Medication record updated!';
      } else {
        this.alertService.displayErrorMessage(AlertType.Toast, '',
          "Medication record doesn't exist in patient record.");
      }
    }
    this.patientService.updatePatient(this.patient);
    if (_isSuccess) {
      this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    }
    this.closeDialog();
  }


}
