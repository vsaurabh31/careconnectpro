import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Guid } from 'guid-typescript';
import { AlertType, APIUrls, Company, CompanyPatientMedicalHistory, MedicalHistoryConstants, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService } from 'service-lib';
import { BaseComponent } from '../../../core/base.component';

@Component({
  selector: 'app-medical-history-addupdate',
  templateUrl: './medical-history-addupdate.component.html',
  styleUrls: ['./medical-history-addupdate.component.scss']
})
export class MedicalHistoryAddupdateComponent extends BaseComponent implements OnInit {
  agencyMedHistory: CompanyPatientMedicalHistory = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  agency: Company = {};
  recordExist: boolean = false;
  isSocialHistory: boolean = false;

  constructor(
    private agencyService: CompanyBusinessService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<MedicalHistoryAddupdateComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.agencyMedHistory = { ...this.data.value };
    } else {
      this.agencyMedHistory.id = Guid.create().toString();
      this.agencyMedHistory.historyType = MedicalHistoryConstants.FAMILY_HISTORY;
    }
    this.agency = this.agencyService.getCompany();
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {

    if (this.isEditMode) {
      this.dbUpdateHistory();
    } else {
      if (!this.validateExistingRecord()){
        this.dbAddHistory();
      }
    }
}

clearRecordExistError() {
  this.recordExist = false;
}

validateExistingRecord(): boolean {
  const agency = this.agencyService.getCompany();
  if (!agency.patientMedicalHistory) {
    return false;
  }
  if (agency.patientMedicalHistory.findIndex(item => item.value == this.agencyMedHistory.value && item.historyType == this.agencyMedHistory.historyType) > -1) {
    this.recordExist = true;
    return true;
  }
  return false;
}

dbAddHistory() {
  this.alertService.setDisplayExceptionAlertMsg(true);
  this.isProcessing = true;
  this.agencyMedHistory.companyId = this.agency.id;
  let ret = this.dataService
    .postData(this.agencyMedHistory, APIUrls.CompanyPatientMedicalHistory)
    .finally(() => {
      this.isProcessing = false;
    })
    .subscribe(
      data => {
        if (!!data) {
          this.agencyMedHistory.id = data;
        }
        this.updateView();
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
}

dbUpdateHistory() {
  this.alertService.setDisplayExceptionAlertMsg(true);
  this.isProcessing = true;
  let ret = this.dataService
    .updateData(this.agencyMedHistory, APIUrls.CompanyPatientMedicalHistory)
    .finally(() => {
      this.isProcessing = false;
    })
    .subscribe(
      data => {
        this.updateView();
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
}


updateView() {
  let alertMsg: string = "";
  if (this.isEditMode) {
    alertMsg = 'Medical history field updated!';
  } else {
    alertMsg = 'Medical history field added!';
  }
  this.agencyService.refreshView();
  this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
  this.closeDialog();
}
}
