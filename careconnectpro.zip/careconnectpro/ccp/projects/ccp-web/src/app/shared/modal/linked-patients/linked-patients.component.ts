import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AlertType, APIUrls, GenericSearch } from 'model-lib';
import { PatientSearchResult, UserSession } from 'projects/model-lib/src/lib/models';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';


@Component({
  selector: 'app-linked-patients',
  templateUrl: './linked-patients.component.html',
  styleUrls: ['./linked-patients.component.scss']
})
export class LinkedPatientsComponent extends BaseComponent implements OnInit {
  patients: PatientSearchResult[] = [];
  patientSearch: GenericSearch = {};
  isProcessing: boolean = false;
  constructor(
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    private router: Router,
    public dialogRef: MatDialogRef<LinkedPatientsComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit() {
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });

    if (!!this.data.value) {
      this.patientSearch = { ...this.data.value };
      this.getDbPatients();
    } else {
      this.closeDialog();
    }    
  }

  openPatientEdit(id: string) {
    this.router.navigateByUrl(`patient/detail/${id}`);
    this.closeDialog();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  getDbPatients() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const _patientSearch: PatientSearchResult = {};
    let ret = this.dataService
      .postData(this.patientSearch, APIUrls.SearchLinkedPatients)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.patients = data;
          this.patients.sort((a,b) => {return a.name.localeCompare(b.name)});
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

}
