import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import {AlertService, DataService, HelperService, AuthService } from 'service-lib';
import { StateUS, Address, AddressCodes, AlertType, APIUrls, 
  AppMessage, UserSession, PeoplePlacesCodes, MedicalInsuranceProvider } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-medical-insurance-provider',
  templateUrl: './medical-insurance-provider.component.html',
  styleUrls: ['./medical-insurance-provider.component.scss']
})
export class MedicalInsuranceProviderComponent extends BaseComponent implements OnInit {

  provider: MedicalInsuranceProvider = {};
  providerPhone: string;
  providerFax: string = "";
  providerAddress: Address = {};
  isPrimary: boolean = true;
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  usStates: StateUS[] = [];
  isAdminMode: boolean = false;
  
  constructor(
    private alertService: AlertService,
    private dataService: DataService,
    private helperService: HelperService,
    private authService: AuthService,
    private router: Router,
    public dialogRef: MatDialogRef<MedicalInsuranceProviderComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super()
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.isAdminMode) {
      this.isAdminMode = this.data.isAdminMode;
    }

    if (!!this.data.value) {
      this.isEditMode = true;
      this.provider = { ...this.data.value };
      this.providerAddress = this.helperService.getPrimaryAddress(this.provider);
      const phone =  this.helperService.getContactByType(PeoplePlacesCodes.ContactWorkPhone, this.provider.contacts);
      const fax = this.helperService.getContactByType(PeoplePlacesCodes.ContactFax, this.provider.contacts);
       if (!!phone) {
        this.providerPhone = phone.value;
      }
      if (!!fax) {
        this.providerFax = fax.value;
      }
      this.getStateForEdit();
    }

    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data:UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
  }

  getStateForEdit() {
    if (this.usStates.findIndex(item => item.id == this.providerAddress.state) < 0) {
      const alternateState = this.usStates.find(item => item.value == this.providerAddress.state);
      if (!!alternateState) {
        this.providerAddress.state = alternateState.id;
      }
    }
  }

  initData() {
    this.usStates = AddressCodes.USStates.map((item) => { return item });
    this.providerAddress.state = this.usStates[0].id;
  }

  closeDialog(refreshView?: boolean, returnThirdParty?: boolean): void {
    if ( this.isAdminMode && returnThirdParty) {
      this.router.navigateByUrl(`thirdparty/insuranceprovider/detail/${this.provider.id}`);
      this.dialogRef.close(refreshView);   
    } else {
      this.dialogRef.close(refreshView); 
    }    
  }

  submitForm() {
    if (!!this.data.returnData) {
      this.addProviderDatabase();
      return
    }
    if (this.isEditMode) {
      this.updateProviderDatabase();
    } else {
      this.addProviderDatabase();
    }
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId){
      this.closeDialog();
    }
  }

  getProviderContactIdent() {
    const currentUser = this.authService.getUserLoggedIn(); 
    this.provider.companyId = currentUser.companyId;
    this.provider.longName = this.provider.name;
    this.provider.lastUpdatedUserId = currentUser.employeeId;
    this.providerAddress.isPrimary = true;
    this.providerAddress.country = "US";
    this.providerAddress.lastUpdatedUserId = currentUser.employeeId;
    this.provider = this.helperService.addUpdateAddress(this.providerAddress, this.provider);
    this.provider = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactWorkPhone, this.providerPhone, this.provider);
    this.provider = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactFax, this.providerFax, this.provider);
  }

  addProviderDatabase(){  
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.getProviderContactIdent();
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.provider, APIUrls.InsuranceProvider)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.provider.id = data;
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              '',
              'Medical insurance record added!'
            );  
            if (!this.isAdminMode) {
              this.closeDialog(true);
            } else {
              this.closeDialog(true, true);             
            } 
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.ErrorUpdateDatabaseRecordFailed
            );
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }



  updateProviderDatabase() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.getProviderContactIdent();
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.provider, APIUrls.InsuranceProvider)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              '',
              'Insurance provider record updated successfully!!'
            );
            this.closeDialog(true);
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.ErrorUpdateDatabaseRecordFailed
            );
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

}
