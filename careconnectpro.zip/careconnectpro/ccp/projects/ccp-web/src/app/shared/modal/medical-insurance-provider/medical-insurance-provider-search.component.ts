import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { MedicalInsuranceProviderComponent } from './medical-insurance-provider.component';
import { BaseComponent } from '../../core/base.component';
import { Address, Patient, AlertType, APIUrls, AppMessage, Contact, UserSession, MedicalInsuranceProvider, MedicalInsuranceProviderSearchResult } from 'model-lib';
import { AlertService, DataService, HelperService, PatientService, AuthService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';
import { GenericSearch } from 'model-lib';

@Component({
  selector: 'app-medical-insurance-provider-search',
  templateUrl: './medical-insurance-provider-search.component.html',
  styleUrls: ['./medical-insurance-provider-search.component.scss']
})
export class MedicalInsuranceProviderSearchComponent extends BaseComponent implements OnInit {
  provider: MedicalInsuranceProviderSearchResult = {};
  providerPhone: string;
  providerFax: string = "";
  providerAddress: Address = {};
  isPrimary: boolean;
  providerSearch: GenericSearch = { searchFilter: "name" };
  providers: MedicalInsuranceProviderSearchResult[] = [];
  showNoRecordFound: boolean = false;
  patient: Patient = {};
  isProcessing: boolean = false;
  recordExistInPatient: boolean = false;

 constructor(private dialog: MatDialog,
    private authService: AuthService,
    private patientService: PatientService,
    private alertService: AlertService,
    private dataService: DataService,
    private helperService: HelperService,
    public dialogRef: MatDialogRef<MedicalInsuranceProviderSearchComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { 
      super();
    }


  ngOnInit(): void {
    this.validateUserSession();
    this.refreshPatientData();
    this.patientService.isPatientRecordChanged$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        if (val) {
          this.refreshPatientData();
        }
      });
      this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data:UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId){
      this.closeDialog();
    }
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  refreshPatientData() {
    this.patient = this.patientService.getPatient();
    if (!this.patient.companyId) {
      const _userSession = this.authService.getUserLoggedIn();
      this.providerSearch.companyId = _userSession.companyId;
      this.patient.companyId = _userSession.companyId;
    }
    this.providerSearch.companyId = this.patient.companyId;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  getAddressData(_provider:MedicalInsuranceProvider, fieldName: string) {
    const primaryAddress = this.helperService.getPrimaryAddress(_provider);
    return primaryAddress[fieldName];
  }

  openAddProviderDialog(): void {
    const dialogRef = this.dialog.open(MedicalInsuranceProviderComponent, {
      data: { name: 'Add Medical Insurance Provider', returnData: true },
    });
    dialogRef.afterClosed().subscribe((result) => { 
      this.dialogRef.close(result);
    });
  }

  searchProvider() {
    this.showNoRecordFound = false;
    let x = this.providerSearch;
    if ((this.providerSearch.searchKeyword != null) && (this.providerSearch.searchKeyword != "")) {
      this.dbSearch();
    }
  }

  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  selectProvider(provider:MedicalInsuranceProvider) {
    if (!!this.data.returnData) {
      this.dialogRef.close(provider);
      return
    }
    this.closeDialog();
  }

  getDbProviderRecord(id: string) {
    const _provider: MedicalInsuranceProvider = {};
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .getSingleData(_provider,id, APIUrls.InsuranceProvider)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          const response: MedicalInsuranceProvider = data;
            this.selectProvider(response);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  } 

  dbSearch() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.providerSearch, APIUrls.SearchInsuranceProviders)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: MedicalInsuranceProviderSearchResult[] = data;
          this.providers = response;
          if (this.providers.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


}
