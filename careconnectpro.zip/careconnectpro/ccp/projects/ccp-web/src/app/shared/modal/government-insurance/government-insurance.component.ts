import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { PatientGovernmentInsurance, StateUS, UserSession, AlertType, PatientConstants, Physician, APIUrls, AppMessage, Patient } from 'model-lib';
import { PatientService, AlertService, HelperService, AuthService, DataService } from 'service-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';
import { PhysicianSearchComponent } from '../physician/physician-search.component';

@Component({
  selector: 'app-governmentinsurance',
  templateUrl: './government-insurance.component.html',
  styleUrls: ['./government-insurance.component.scss']
})
export class GovernmentInsuranceComponent extends BaseComponent implements OnInit {
  governmentInsurance: PatientGovernmentInsurance = {};
  isMedicare: boolean = true;
  pcpName: string = "";
  pcpPhone: string = "";
  disablePrimary: boolean = false;
  isPrimary: boolean = true;
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  recordExistInPatient: boolean = false;
  isInTakeMode: boolean = false;

  constructor(
    private dataService: DataService,
    private patientService: PatientService,
    private alertService: AlertService,
    private helperService: HelperService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<GovernmentInsuranceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.governmentInsurance = { ...this.data.value };
      this.getInsuranceType();
      if (!!this.governmentInsurance.physicianId) {
        this.getPCPDetail(this.governmentInsurance.physicianId);
      }
    } else {
      this.governmentInsurance.id = Guid.create().toString();
    }

    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
  }

  initData() {
    this.governmentInsurance.partA = false;
    this.governmentInsurance.partB = false;
    this.governmentInsurance.partC = false;
    this.governmentInsurance.partD = false;
    this.isMedicare = true;
  }


  closeDialog(): void {
    this.dialogRef.close();
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  lookupPcp() {
  }

  submitForm() {
    let patient = this.patientService.getPatient();
    if (!patient.governmentInsurance) {
      patient.governmentInsurance = [];
    }
    this.governmentInsurance.patientId = patient.id;
    this.setInsuranceType();
    this.preProcessSubmit();
    if (this.isInTakeMode) {
      this.updateView(patient);
    } else {
      if (this.isEditMode) {
        this.dbUpdateInsurance(patient);
      } else {
        this.dbAddInsurance(patient);
      }
    }

  }


  dbAddInsurance(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.governmentInsurance, APIUrls.PatientGovernmentInsurance)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.governmentInsurance.id = data;
          }
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateInsurance(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.governmentInsurance, APIUrls.PatientGovernmentInsurance)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView(patient: Patient) {
    let displayInfoAlert: boolean = true;
    let alertMsg: string = "";

    if (this.isEditMode) {
      alertMsg = 'Government insurance data record updated!';
      let idx = patient.governmentInsurance.findIndex(item => item.id == this.governmentInsurance.id);
      patient.governmentInsurance[idx] = this.governmentInsurance;
    } else {
      if (patient.governmentInsurance.findIndex(item => item.insuranceTypeId == this.governmentInsurance.insuranceTypeId) < 0) {
        patient.governmentInsurance.push(this.governmentInsurance);
        alertMsg = 'Government insurance data record added!';
      } else {
        this.recordExistInPatient = true;
        return
      }
    }
    this.patientService.updatePatient(patient);
    if (displayInfoAlert) {
      this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    } else {
      this.alertService.displayWarningMessage(AlertType.Toast, '', alertMsg);
    }
    this.closeDialog();
  }


  preProcessSubmit() {
    if (this.isMedicare) {
      this.governmentInsurance.groupNumber = "";
      this.governmentInsurance.physicianId = "";
    } else {
      this.governmentInsurance.partA = null;
      this.governmentInsurance.partB = null;
      this.governmentInsurance.partC = null;
      this.governmentInsurance.partD = null;
    }
  }


  getInsuranceType() {
    if (this.governmentInsurance.insuranceTypeId == PatientConstants.MedicareInsuranceType) {
      this.isMedicare = true;
    } else {
      this.isMedicare = false;
    }
  }

  setInsuranceType() {
    if (this.isMedicare) {
      this.governmentInsurance.insuranceTypeId = PatientConstants.MedicareInsuranceType;
    } else {
      this.governmentInsurance.insuranceTypeId = PatientConstants.MedicaidInsuranceType;
    }
  }

  openSearchPhysicianDialog(): void {
    const dialogRef = this.dialog.open(PhysicianSearchComponent, {
      data: { name: 'Lookup Physician', returnData: true },
    });
    dialogRef.afterClosed().subscribe((result: Physician) => {
      if (!!result) {
        const middleName = result.middleName? result.middleName: '';
        this.pcpName = `${result.prefix} ${result.firstName} ${middleName} ${result.lastName}`;
        this.pcpPhone = this.helperService.getContactByType("WorkPhone", result.contacts).value;
        this.governmentInsurance.physicianId = result.id;
      }
    });
  }

  getPCPDetail(physicanId: string) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const _physician: Physician = {};
    let ret = this.dataService
      .getSingleData(_physician, physicanId, APIUrls.Physician)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: Physician = data;
          if (!!response) {
            const middleName = response.middleName? response.middleName: '';
            this.pcpName = `${response.prefix} ${response.firstName} ${middleName} ${response.lastName}`;
            this.pcpPhone = this.helperService.getContactByType("WorkPhone", response.contacts).value;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

}
