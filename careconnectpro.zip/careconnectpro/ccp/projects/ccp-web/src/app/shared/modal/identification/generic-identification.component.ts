import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Guid } from 'guid-typescript';
import { AlertType, GenericIdValue, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService, HelperService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';


@Component({
  selector: 'app-generic-identification',
  templateUrl: './generic-identification.component.html',
  styleUrls: ['./generic-identification.component.scss']
})
export class GenericIdentificationComponent extends BaseComponent implements OnInit {
  identificationTypes: GenericIdValue[] = [];
  identifications: any[] = [];
  genericIdentification: any = {};
  selectedIdentificationType: string = "";
  entity: any = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  recordExistInEntity: boolean = false;
  apiAddUrl: string = "";
  apiUpdateUrl: string = "";
  updateDatabase: boolean = true;
  entityName: string = "Record";


  constructor(
    private alertService: AlertService,
    private helperService: HelperService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<GenericIdentificationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();

    if (!!this.data.identifications) {
      this.identifications = this.data.identifications;
    }

    this.apiAddUrl = this.data.apiAddUrl;
    this.apiUpdateUrl = this.data.apiUpdateUrl;
    this.updateDatabase = this.data.updateDatabase;
    this.genericIdentification = { ...this.data.value };
    this.identificationTypes = [...this.data.idTypes ];
    
    if (!!this.data.entityName) {
      this.entityName = this.data.entityName;
    }

    if (!!this.genericIdentification.id) {
      this.isEditMode = true;
       this.getIdentificationForEdit();
    } else {
      this.genericIdentification.id = Guid.create().toString();
      if (this.identificationTypes.length > 0) {
        this.selectedIdentificationType = this.identificationTypes[0].id;
      }
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  clearRecordExistError() {
    this.recordExistInEntity = false;
  }

  getIdentificationForEdit() {
    this.selectedIdentificationType = this.helperService.getIdentificationIdByTypeId(this.genericIdentification.idTypeId);
  }

  closeDialog(): void {
    this.dialogRef.close(this.genericIdentification);
  }

  initData() { }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  submitForm() {
    this.genericIdentification.idTypeId = this.helperService.getIdentificationTypeByStringType(this.selectedIdentificationType);
    if (!this.updateDatabase) {
      this.closeDialog();
    } else {
      if (this.isEditMode) {
        this.dbUpdateIdentification();
      } else {
        if (!this.validateExistingRecord()) {
          this.dbAddIdentification();
        }        
      }
    }
  }

  validateExistingRecord(): boolean {
    const _selectedId = this.helperService.getIdentificationTypeByStringType(this.selectedIdentificationType);
    if (this.identifications.findIndex(item => item.idTypeId == _selectedId) > -1) {
      this.recordExistInEntity = true;
      return true;
    }
    return false;
  }


  dbAddIdentification() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.genericIdentification, this.apiAddUrl)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.genericIdentification.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateIdentification() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.genericIdentification, this.apiUpdateUrl)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView() {
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = `${this.entityName} identification updated!`;
    } else {
      alertMsg = `${this.entityName} identification added!`;
    }
    this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    this.closeDialog();
  }

}

