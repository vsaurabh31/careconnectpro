import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhysicianSearchComponent } from './physician-search.component';

describe('PhysicianSearchComponent', () => {
  let component: PhysicianSearchComponent;
  let fixture: ComponentFixture<PhysicianSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhysicianSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhysicianSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
