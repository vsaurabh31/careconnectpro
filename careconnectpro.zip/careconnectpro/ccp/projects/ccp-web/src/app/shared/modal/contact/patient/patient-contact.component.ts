import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../../core/base.component';
import { GenericIdValue, PatientContact, Patient, PeoplePlacesCodes, AlertType, UserSession, APIUrls } from 'model-lib';
import { PatientService, AlertService, HelperService, AuthService, DataService } from 'service-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';
import { AppMessage } from 'model-lib';

@Component({
  selector: 'app-patient-contact',
  templateUrl: './patient-contact.component.html',
  styleUrls: ['./patient-contact.component.scss']
})
export class PatientContactComponent extends BaseComponent implements OnInit {
  contactTypes: GenericIdValue[] = PeoplePlacesCodes.ContactTypes;
  patientContact: PatientContact = {};
  selectedContactType: string = "";
  patient: Patient = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  recordExistInPatient: boolean = false;
  isInTakeMode: boolean = false;

  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private helperService: HelperService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<PatientContactComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.patientContact = { ...this.data.value };
      this.getContactForEdit();
    } else {
      this.patientContact.id = Guid.create().toString();
      if (this.contactTypes.length > 0) {
        this.selectedContactType = this.contactTypes[0].id;
      }
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  getContactForEdit() {
    this.selectedContactType = this.patientContact.contactTypeId.toString();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  initData() {
    this.patient = this.patientService.getPatient();
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  submitForm() {
    this.patient = this.patientService.getPatient();
    this.patientContact.patientId = this.patient.id;
    this.patientContact.contactTypeId = this.selectedContactType;
    if (!this.patient.contacts) {
      this.patient.contacts = [];
    }

    if (this.isInTakeMode) {
      this.updateView();
    } else {
      if (this.isEditMode) {
        this.dbUpdateContact();
      } else {
        if (!this.validateExistingRecord()) {
          this.dbAddContact();
        }        
      }
    }
  }

  validateExistingRecord(): boolean {
    if (this.patient.contacts.findIndex(item => item.contactTypeId == this.selectedContactType) > -1) {
      this.recordExistInPatient = true;
      return true;
    }
    return false;
  }

  updateView() {
    let displayInfoAlert: boolean = true;
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = 'Patient contact record updated!';
      let idx = this.patient.contacts.findIndex(item => item.id == this.patientContact.id);
      this.patient.contacts[idx] = this.patientContact;
    }
    if ((!this.isEditMode) && (!this.validateExistingRecord())) {
      if (this.patient.contacts.findIndex(item => item.contactTypeId == this.selectedContactType) < 0) {
        this.patient = this.helperService.addUpdateContactByVal(this.patientContact.id, this.selectedContactType, this.patientContact.value, this.patient);
        alertMsg = 'Patient contact added!';
      } 
    }

    this.patientService.updatePatient(this.patient);
    if (displayInfoAlert) {
      this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    } else {
      this.alertService.displayWarningMessage(AlertType.Toast, '', alertMsg);
    }

    this.closeDialog();
  }

  dbAddContact() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.patientContact, APIUrls.PatientContact)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.patientContact.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateContact() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.patientContact, APIUrls.PatientContact)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
