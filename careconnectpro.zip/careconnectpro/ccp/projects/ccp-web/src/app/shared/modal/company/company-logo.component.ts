import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AlertType, APIUrls, AppConstants, Company, CompanySystemSettings, MediaFile, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService, HelperService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';
@Component({
  selector: 'app-company',
  templateUrl: './company-logo.component.html',
  styleUrls: ['./company-logo.component.scss'],
})
export class CompanyLogoComponent extends BaseComponent implements OnInit {
  companySetting: CompanySystemSettings = {};
  companyLogo: string = "";
  supportedFiles: string = "";
  htmlValidImageFiles: string = "";
  isProcessing: boolean = false;
  tempMediaFile: MediaFile = {};

  constructor(
    private alertService: AlertService,
    private helperService: HelperService,
    private dataService: DataService,
    private agencyService: CompanyBusinessService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<CompanyLogoComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.supportedFiles = this.helperService.getSupportedImageFilesList();
    this.htmlValidImageFiles = this.helperService.getSupportedImageFilesInputFileAccept();

    if (!!this.data.value) {
      this.companySetting = { ...this.data.value };
      if (!!this.companySetting.logoName) {
        this.companyLogo = APIUrls.GetImageCompany + "/" + this.companySetting.logoName;         
      } else {
        this.companyLogo = AppConstants.DefaultCompanyLogo;   
      }
    } else {
      this.alertService.displayErrorMessage(
        AlertType.Dialog,
        '',
        "Company logo setting is unavailable."
      );
      this.closeDialog();
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data: UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  logoInputChange(imgFile: any) {
      if (!!imgFile.target.files && imgFile.target.files.length > 0) {
        const file: File = imgFile.target.files[0];
        const validImage = this.validateImage(file);
        if (this.validateImage(file)) {
          this.dbSaveTempImage(file);
        }
      }
  }

  dbSaveTempImage(file: File) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    const uploadData = new FormData();
    uploadData.append('image', file);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(uploadData, APIUrls.MediaImagesCompanyPreview + "/" + this.companySetting.companyId, true)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.getUploadedFile();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  getUploadedFile() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const mediaFile: MediaFile = {};
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .getSingleData(mediaFile, this.companySetting.companyId, APIUrls.MediaImagesCompanyGetAll)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (files: any) => {
          if (files != null) {
            this.tempMediaFile = files[0];
            this.companyLogo =
              APIUrls.GetImageCompanyTemp + "/" + files[0].fileName;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  newDbSettings() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.companySetting.logoName = this.tempMediaFile.fileName;
    const company: Company = this.agencyService.getCompany();
    this.companySetting.companyId = company.id;
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.companySetting, APIUrls.CompanySettingsApi)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(AlertType.Toast, "", "Company Logo Updated");
            this.agencyService.refreshView();
            this.closeDialog();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateSettingsDb() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.companySetting.logoName = this.tempMediaFile.fileName;
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .updateData(this.companySetting, APIUrls.CompanySettingsApi)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(AlertType.Toast, "", "Company Logo Updated");
            this.agencyService.refreshView();
            this.closeDialog();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  saveImageDb() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    if (!this.tempMediaFile.fileName) {
      return
    }
    this.tempMediaFile.companyFile = this.tempMediaFile.fileName;
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.tempMediaFile, APIUrls.MediaImagesCompanySave)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            if (!!this.companySetting.id) {
              this.updateSettingsDb();
            } else {
              this.newDbSettings();
            }
            
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  validateImage(file: File): boolean {
    let validStatus: boolean = true;
    if (file.size > AppConstants.MaxImageFileSize) {
      this.alertService.displayErrorMessage(
        AlertType.Dialog,
        '',
        `The image file size must be less than ${AppConstants.MaxImageFileSize} bytes`
      );
      validStatus = false;
    }
    const fileExts = file.name.split('.');
    let invalidExt: boolean = false;
    if (fileExts.length < 2) {
      invalidExt = true;
    } else {
      if (AppConstants.ValidImageFiles.findIndex(item => item.toLowerCase() == fileExts[fileExts.length - 1]) < 0) {
        invalidExt = true;
      }
    }

    if (invalidExt) {
      this.alertService.displayErrorMessage(
        AlertType.Dialog,
        '',
        `The image file is not supported. The supported image files are: ${this.supportedFiles}`
      );
      validStatus = false;
    }
      return validStatus;
  }
}
