import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivateInsuranceComponent } from './private-insurance.component';

describe('PrivateInsuranceComponent', () => {
  let component: PrivateInsuranceComponent;
  let fixture: ComponentFixture<PrivateInsuranceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PrivateInsuranceComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivateInsuranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
