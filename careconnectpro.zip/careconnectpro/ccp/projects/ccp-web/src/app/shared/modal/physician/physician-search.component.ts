import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { Physician, Address, PatientReferralPhysician, UserSession, Identification, IdType } from 'model-lib';
import { PhysicianComponent } from './physician.component';
import { AlertService, DataService, PatientService, AuthService } from 'service-lib';
import { APIUrls, PhysicianSearchResult } from 'model-lib';
import { AlertType } from 'model-lib';
import { AppMessage } from 'model-lib';
import { Patient } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { HelperService } from 'projects/service-lib/src/public-api';
import { Contact } from 'model-lib';
import { GenericSearch } from 'model-lib';

@Component({
  selector: 'app-physician-search',
  templateUrl: './physician-search.component.html',
  styleUrls: ['./physician-search.component.scss']
})
export class PhysicianSearchComponent extends BaseComponent implements OnInit {
  physician: Physician = {};
  physicianPhone: string;
  physicianFax: string = "";
  physicianAddress: Address = {};
  isPrimary: boolean;
  physicianSearch: GenericSearch = { searchFilter: "name" };
  physicians: PhysicianSearchResult[] = [];
  showNoRecordFound: boolean = false;
  patient: Patient = {};
  isProcessing: boolean = false;
  recordExistInPatient: boolean = false;
  isInTakeMode: boolean = false;


  constructor(
    private dialog: MatDialog,
    private authService: AuthService,
    private patientService: PatientService,
    private alertService: AlertService,
    private dataService: DataService,
    private helperService: HelperService,
    public dialogRef: MatDialogRef<PhysicianSearchComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.refreshPatientData();

    this.patientService.isPatientRecordChanged$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        if (val) {
          this.refreshPatientData();
        }
      });
      this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data:UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
      this.isInTakeMode = this.patientService.getInTakeMode();
      this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
        .subscribe(val => {
          this.isInTakeMode = val;
        });
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  refreshPatientData() {
    this.patient = this.patientService.getPatient();
    if (!this.patient.companyId) {
      const _userSession = this.authService.getUserLoggedIn();
      this.physicianSearch.companyId = _userSession.companyId;
      this.patient.companyId = _userSession.companyId;
    }
    this.physicianSearch.companyId = this.patient.companyId;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId){
      this.closeDialog();
    }
  }

  getAddressData(_physician:Physician, fieldName: string) {
    const primaryAddress = this.helperService.getPrimaryAddress(_physician);
    return primaryAddress[fieldName];
  }

  openAddPhysicianDialog(): void {
    const dialogRef = this.dialog.open(PhysicianComponent, {
      data: { name: 'Add Physician', returnData: true },
    });
    dialogRef.afterClosed().subscribe((result:Physician) => { 
      this.dialogRef.close(result);
    });
  }

  getNpiIdentById(idents: Identification[]): string {
    return this.helperService.getIdentificationById(IdType.npi, idents);
  }
  
  searchPhysician() {
    this.showNoRecordFound = false;
    let x = this.physicianSearch;
    if ((this.physicianSearch.searchKeyword != null) && (this.physicianSearch.searchKeyword != "")) {
      this.dbSearch();
    }
  }

  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  selectPhysician(physician:Physician) {
    if (!!this.data.returnData) {
      this.dialogRef.close(physician);
      return
    }
    this.continuePatientIntake(physician);
  }

  getDbPhysicianRecord(id: string) {
    const _physician: Physician = {};
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .getSingleData(_physician,id, APIUrls.Physician)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          const response: Physician = data;
            this.selectPhysician(response);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  } 

  continuePatientIntake(physician:Physician) {
    let patient = this.patientService.getPatient();
    if(!patient.referralPhysicians) {
      patient.referralPhysicians = [];
    }
    if (patient.referralPhysicians.findIndex(item => item.physicianId == physician.id) < 0) {
      let refPhysician: PatientReferralPhysician = {physicianId: physician.id, isPrimary: false}; 
      refPhysician.patientId = patient.id;
      if (this.isInTakeMode) {
        this.updateView(patient, refPhysician);
      } else {
        this.dbAddPhysician(patient, refPhysician);
      }
      
    } else {
        this.recordExistInPatient = true;
        return
    }
  }

  updateView(patient: Patient, refPhysician: PatientReferralPhysician) {
    patient.referralPhysicians.push(refPhysician);      
    this.patientService.updatePatient(patient);
    this.alertService.displaySuccessMessage(
      AlertType.Toast,
      '',
      'Physician added to patient record!'
    );
    this.closeDialog();
  }

  dbAddPhysician(patient: Patient, refPhysician: PatientReferralPhysician) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(refPhysician, APIUrls.PatientReferralPhysician)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            refPhysician.id = data;
          }
          this.updateView(patient, refPhysician);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  dbSearch() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.physicianSearch, APIUrls.SearchPhysicians)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: PhysicianSearchResult[] = data;
          this.physicians = response;
          if (this.physicians.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  getContactById(contactTypeVal: string, contacts: Contact[]): string {
    return this.helperService.getContactById(contactTypeVal, contacts);
  }

  getCombinedAddress(_physician: Physician) {
    return this.helperService.getCombinedAddress(_physician);
  }

}
