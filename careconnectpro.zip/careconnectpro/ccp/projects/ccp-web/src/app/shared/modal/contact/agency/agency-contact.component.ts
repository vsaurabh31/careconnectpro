import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Guid } from 'guid-typescript';
import { AlertType, APIUrls, Company, CompanyContact, GenericIdValue, PeoplePlacesCodes, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService } from 'service-lib';
import { BaseComponent } from '../../../core/base.component';

@Component({
  selector: 'app-agency-contact',
  templateUrl: './agency-contact.component.html',
  styleUrls: ['./agency-contact.component.scss']
})
export class AgencyContactComponent extends BaseComponent implements OnInit {
  contactTypes: GenericIdValue[] = PeoplePlacesCodes.ContactTypes;
  agencyContact: CompanyContact = {};
  selectedContactType: string = "";
  agency: Company = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  recordExistInPatient: boolean = false;

  constructor(
    private agencyService: CompanyBusinessService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<AgencyContactComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.agencyContact = { ...this.data.value };
      this.getContactForEdit();
    } else {
      this.agencyContact.id = Guid.create().toString();
      if (this.contactTypes.length > 0) {
        this.selectedContactType = this.contactTypes[0].id;
      }
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  getContactForEdit() {
    this.selectedContactType = this.agencyContact.contactTypeId.toString();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  initData() { }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  submitForm() {
    const _session = this.authService.getUserLoggedIn();
    this.agencyContact.contactTypeId = this.selectedContactType;
    if (this.isEditMode) {
        this.dbUpdateContact();
      } else {
        this.agencyContact.companyId = _session.companyId;
        if (!this.validateExistingRecord()) {
          this.dbAddContact();
        }        
      }
  }

  validateExistingRecord(): boolean {
    const agency = this.agencyService.getCompany();
    if (agency.contacts.findIndex(item => item.contactTypeId == this.selectedContactType) > -1) {
      this.recordExistInPatient = true;
      return true;
    }
    return false;
  }


  dbAddContact() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.agencyContact, APIUrls.CompanyContact)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.agencyContact.id = data;
          }
          this.agencyService.refreshView();
          this.closeDialog();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateContact() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.agencyContact, APIUrls.CompanyContact)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.agencyService.refreshView();
          this.closeDialog();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

}
