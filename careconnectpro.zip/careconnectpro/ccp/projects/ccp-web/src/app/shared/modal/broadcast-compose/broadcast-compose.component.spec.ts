import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BroadcastComposeComponent } from './broadcast-compose.component';

describe('BroadcastComposeComponent', () => {
  let component: BroadcastComposeComponent;
  let fixture: ComponentFixture<BroadcastComposeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BroadcastComposeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BroadcastComposeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
