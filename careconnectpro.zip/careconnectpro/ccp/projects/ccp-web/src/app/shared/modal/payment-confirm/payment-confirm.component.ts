import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import {
  UserSignup,
  APIUrls,
  AlertType,
  AppMessage,
  UserSession,
  UserLogin,
  BaseApiResponse
} from 'model-lib';
import 'rxjs/add/operator/finally';
import { takeUntil } from 'rxjs/operators';
import { BaseComponent } from '../../../shared/core/base.component';
import {
  DataService,
  AlertService,
  AuthService,
  SubscriptionService,
  CareConnectLocalStorage
} from 'service-lib';

@Component({
  selector: 'app-payment-confirm',
  templateUrl: './payment-confirm.component.html',
  styleUrls: ['./payment-confirm.component.scss']
})
export class PaymentConfirmComponent extends BaseComponent implements OnInit {
  companyRegistration: UserSignup = {};
  isProcessing: boolean = false;
  userLogin: UserLogin = {};

  constructor(
    private router: Router,
    public dialogRef: MatDialogRef<PaymentConfirmComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dataService: DataService,
    private alertService: AlertService,
    private authService: AuthService,
    private subscriptionService: SubscriptionService,
    private localStore: CareConnectLocalStorage
  ) {
    super();
  }
  ngOnInit(): void {
    this.companyRegistration = this.subscriptionService.getCompanyRegistration();
    this.userLogin.userName = this.companyRegistration.userName;
    this.userLogin.password = this.companyRegistration.password;
  }

  enterApp() {
    this.dialogRef.close();
    let userLoggedIn = this.authService.getUserLoggedIn();
    this.alertService.displayInfoMessage(
      AlertType.Toast,
      '',
      'Welcome ' + userLoggedIn.fullName
    );
    this.router.navigateByUrl('home');
  }


  getLoggedInUserInfo() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let request: UserSession;
    let ret = this.dataService
      .getSingleData(request, "", APIUrls.GetUserSignedInInfo)
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          const response: UserSession = data;
          if (!!response) {
              this.authService.setUserLoggedIn(response);
            this.enterApp();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
