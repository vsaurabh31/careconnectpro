import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { Guid } from 'guid-typescript';
import { AddressCodes, AlertType, APIUrls, Company, CompanyAddress, CompanyService, StateUS, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService } from 'service-lib';
import { BaseComponent } from '../../core';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss'],
})
export class LocationComponent extends BaseComponent implements OnInit {
  agencyAddress: CompanyAddress = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  usStates: StateUS[] = AddressCodes.USStates;
  disablePrimary: boolean = false;
  agency: Company = {};
  
  constructor(
    private agencyService: CompanyBusinessService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<LocationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.agencyAddress = { ...this.data.value };
      this.getStateForEdit();
    } else {
      this.agencyAddress.id = Guid.create().toString();
      this.agencyAddress.isPrimary = true;
    }
    this.agency = this.agencyService.getCompany();
    this.validateIsPrimaryEnable();
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  validateIsPrimaryEnable() {
    const _agency: Company = this.agencyService.getCompany();
    if (!_agency.addresses) {
      _agency.addresses = [];
      this.agency.addresses = [];
    }
    const idx = _agency.addresses.findIndex(item => item.isPrimary == true);
    if ((idx > -1) && (_agency.addresses[idx].id != this.agencyAddress.id)) {
      if (!this.isEditMode) {
        this.agencyAddress.isPrimary = false;
      }
      this.disablePrimary = true;
      this.alertService.displayWarningMessage(AlertType.Toast, '',
        "Another address is set as the Corporate location for this agency. The corporate location field can't be changed.");
    } else {
      this.disablePrimary = false;
    }
  }

  getStateForEdit() {
    if (this.usStates.findIndex(item => item.id.toLowerCase() == this.agencyAddress.state.toLowerCase()) < 0) {
      const alternateState = this.usStates.find(item => item.value.toLowerCase() == this.agencyAddress.state.toLowerCase());
      if (!!alternateState) {
        this.agencyAddress.state = alternateState.id;
      }
    }
  }

  initData() {
    this.agencyAddress.state = this.usStates[0].id;
  }


  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {
      if (this.isEditMode) {
        this.dbUpdateAddress();
      } else {
        this.dbAddAddress();
      }
  }

  dbAddAddress() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.agencyAddress.companyId = this.agency.id;
    let ret = this.dataService
      .postData(this.agencyAddress, APIUrls.CompanyAddressApi)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.agencyAddress.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateAddress() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.agencyAddress, APIUrls.CompanyAddressApi)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  updateView() {
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = 'Address record updated!';
    } else {
      alertMsg = 'Address record added!';
    }
    this.agencyService.refreshView();
    this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    this.closeDialog();
  }
}
