import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalProviderComponent } from './medical-provider.component';

describe('MedicalProviderComponent', () => {
  let component: MedicalProviderComponent;
  let fixture: ComponentFixture<MedicalProviderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MedicalProviderComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalProviderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
