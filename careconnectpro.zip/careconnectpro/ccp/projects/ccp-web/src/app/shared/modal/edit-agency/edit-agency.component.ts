import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AlertType, APIUrls, Company, UserSession} from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService, HelperService } from 'service-lib';
import { BaseComponent } from '../../../shared/core/base.component';

@Component({
  selector: 'app-edit-agency',
  templateUrl: './edit-agency.component.html',
  styleUrls: ['./edit-agency.component.scss'],
})
export class EditAgencyComponent extends BaseComponent implements OnInit {
  agencyPhone: string = "";
  agencyWebsite: string = "";
  isProcessing: boolean = false;
  dbUpdatePass: boolean = false;
  agency: Company = {};

  constructor(
    public dialogRef: MatDialogRef<EditAgencyComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private helperService: HelperService,
    private alertService: AlertService,
    private dataService: DataService,
    private authService: AuthService,
    private companyBusinessService: CompanyBusinessService
  ) {
    super();
  }

  ngOnInit() {
    if (!!this.data) {
      this.agency = { ...this.data };
      const _urlContact = this.helperService.getContactByType("Url", this.agency.contacts);
      const _phoneContact = this.helperService.getContactByType("WorkPhone", this.agency.contacts);
      if (!! _urlContact) {
        this.agencyWebsite = _urlContact.value;
      }
      if (!! _phoneContact) {
        this.agencyPhone =_phoneContact.value;
      }
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data: UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
  }
  
  closeDialog(): void {
    if (this.dbUpdatePass) {
      this.companyBusinessService.refreshView();
    }
    this.dialogRef.close();
  }

  submitForm() {
    this.agency = this.helperService.addUpdateContactByVal("","WorkPhone",this.agencyPhone,this.agency);
    this.agency = this.helperService.addUpdateContactByVal("","Url",this.agencyWebsite,this.agency);
    this.addCompanyIdContact();
    this.dbUpdateCompanyPhone();
  }

  addCompanyIdContact(){
    this.agency.contacts.forEach(x => {
      if (!x.companyId) {
        const idx = this.agency.contacts.findIndex(y => y == x);
        this.agency.contacts[idx].companyId = this.agency.id;
      }
    })
  }

  dbUpdateCompanyPhone() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.dbUpdatePass = false;
    const _contact = this.helperService.getContactByType("WorkPhone", this.agency.contacts);
    let ret = this.dataService
      .updateData(_contact, APIUrls.CompanyContact)
      .finally(() => {
        this.isProcessing = false;
        this.dbUpdateCompanyWebsite();
      })
      .subscribe(
        data => {
          if (data) {
            this.dbUpdatePass = true;
          } 
                    
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateCompanyWebsite() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.dbUpdatePass = false;
    const _contact = this.helperService.getContactByType("Url", this.agency.contacts);
    let ret = this.dataService
      .updateData(_contact, APIUrls.CompanyContact)
      .finally(() => {
        this.isProcessing = false;
        if (this.dbUpdatePass) {
          this.alertService.displaySuccessMessage(AlertType.Toast, "", "Agency information updated successfully");
        }
        this.closeDialog();
      })
      .subscribe(
        data => {
          if (data) {
            this.dbUpdatePass = true;
          }           
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
