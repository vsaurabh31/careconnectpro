import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { Guid } from 'guid-typescript';
import { AlertType, APIUrls, AppRole, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, SecurityService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-security-role',
  templateUrl: './security-role.component.html',
  styleUrls: ['./security-role.component.scss'],
})
export class SecurityRoleComponent extends BaseComponent implements OnInit {
  appRole: AppRole = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  roleRecordExist: boolean = false;
  constructor(
    private dataService: DataService,
    private alertService: AlertService,
    private securityService: SecurityService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<SecurityRoleComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { 
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.appRole = { ...this.data.value };
    } else {
      this.appRole.id = Guid.create().toString();
      const userSession = this.authService.getUserLoggedIn();
      this.appRole.companyId = userSession.companyId;
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data: UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
  }

  clearRecordExistError() {
    this.roleRecordExist = false;
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  submitForm() {
    if (this.isEditMode) {
      this.updateDbRole();
    } else {
      this.addDbRole();
    }
  }

  updateDbRole() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .updateData(this.appRole, APIUrls.CompanyRole)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          this.alertService.displaySuccessMessage(AlertType.Toast, "", "Role Updated");
          this.securityService.refreshView();
          this.closeDialog();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  addDbRole() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.appRole, APIUrls.CompanyRole)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          this.alertService.displaySuccessMessage(AlertType.Toast, "", "Role Added");
          this.securityService.refreshView();
          this.closeDialog();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  closeDialog(): void {
    this.dialogRef.close();
  }
}
