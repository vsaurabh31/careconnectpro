import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AddressCodes, AlertType, APIUrls, Employee, EmployeeAddress, PeoplePlacesCodes, StateUS, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, EmployeeService, HelperService, MediaService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-edit-personal',
  templateUrl: './edit-personal.component.html',
  styleUrls: ['./edit-personal.component.scss'],
})
export class EditPersonalComponent extends BaseComponent implements OnInit {
  employeeAddress: EmployeeAddress = {};
  employeePhone: string = "";
  employeeEmail: string = "";
  usStates: StateUS[] = AddressCodes.USStates;
  employee: Employee = {};
  isProcessing: boolean = false;

  constructor(
    private authService: AuthService,
    private employeeService: EmployeeService,
    private alertService: AlertService,
    private helperService: HelperService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<EditPersonalComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  getStateForEdit() {
    if (this.usStates.findIndex(item => item.id == this.employeeAddress.state) < 0) {
      const alternateState = this.usStates.find(item => item.value == this.employeeAddress.state);
      if (!!alternateState) {
        this.employeeAddress.state = alternateState.id;
      } else {
        this.employeeAddress.state = this.usStates[0].id;
      }
    }
  }


  ngOnInit(): void {
    if (!!this.data.value) {
      this.employee = { ...this.data.value };
      this.employeeAddress = this.helperService.getPrimaryAddress(this.employee);
      if(!this.employeeAddress.employeeId){
        this.employeeAddress.employeeId = this.employee.id;
      }
      this.employeePhone = this.helperService.getContactByType(PeoplePlacesCodes.ContactWorkPhone, this.employee.contacts)?.value;
      this.employeeEmail = this.helperService.getContactByType(PeoplePlacesCodes.ContactEmail, this.employee.contacts)?.value;
      this.getStateForEdit();
      this.authService.userSession$.pipe(takeUntil(this.destroy$))
        .subscribe((data: UserSession) => {
          if (!data.companyId) {
            this.closeDialog();
          }
        });
    }
  }


  submitForm() {
    this.employee = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactWorkPhone, this.employeePhone, this.employee);
    this.employee = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactEmail, this.employeeEmail, this.employee);
    this.addEmployeeIdContact();
    this.updateDbAddress();
  }

  addEmployeeIdContact(){
    this.employee.contacts.forEach(x => {
      if (!x.employeeId) {
        const idx = this.employee.contacts.findIndex(y => y == x);
        this.employee.contacts[idx].employeeId = this.employee.id;
      }
    })
  }

  updateDbAddress() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    const isPrimaryExist = this.employee.addresses.findIndex(x => x.isPrimary == true);
    if (isPrimaryExist < 0) {
      this.employeeAddress.isPrimary = true;
    }
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.employeeAddress, APIUrls.EmployeeAddress)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.dbUpdateEmployeePhone();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  
  dbUpdateEmployeePhone() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const _contact = this.helperService.getContactByType(PeoplePlacesCodes.ContactWorkPhone, this.employee.contacts);
    let ret = this.dataService
      .updateData(_contact, APIUrls.EmployeeContact)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.dbUpdateEmployeeEmail();
          } 
                    
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateEmployeeEmail() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const _contact = this.helperService.getContactByType(PeoplePlacesCodes.ContactEmail, this.employee.contacts);
    let ret = this.dataService
      .updateData(_contact, APIUrls.EmployeeContact)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(AlertType.Toast, "", "Employee contact updated");
            this.employeeService.refreshView();
            this.closeDialog();
          }                     
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
 
}

