import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AlertType, APIUrls, IdentityAppUser, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, EmployeeService, HelperService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-edit-login',
  templateUrl: './edit-login.component.html',
  styleUrls: ['./edit-login.component.scss'],
})
export class EditLoginComponent extends BaseComponent implements OnInit {
  loginInfo: IdentityAppUser = {};
  password2: string = "";
  isProcessing: boolean = false;
  constructor(
    private authService: AuthService,
    private employeeService: EmployeeService,
    private alertService: AlertService,
    private helperService: HelperService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<EditLoginComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }


  ngOnInit(): void {
    if (!!this.data.value) {
      this.loginInfo = { ...this.data.value };
      this.loginInfo.passwordHash = "***********";
      this.authService.userSession$.pipe(takeUntil(this.destroy$))
        .subscribe((data: UserSession) => {
          if (!data.companyId) {
            this.closeDialog();
          }
        });
    }
  }

  submitForm() {
    if (this.password2 == this.loginInfo.passwordHash)
    {
      this.dbUpdatePassword();
    } 
  }

  dbUpdatePassword() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.loginInfo, APIUrls.EmployeeLogin)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(AlertType.Toast, "", "Password updated successfully");
            this.employeeService.refreshView();
            this.closeDialog();
          }                     
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
