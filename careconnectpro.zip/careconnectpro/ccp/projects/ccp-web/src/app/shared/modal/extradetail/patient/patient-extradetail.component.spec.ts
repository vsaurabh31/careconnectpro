import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientExtraDetailComponent } from './patient-extradetail.component';

describe('PatientExtraDetailComponent', () => {
  let component: PatientExtraDetailComponent;
  let fixture: ComponentFixture<PatientExtraDetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PatientExtraDetailComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientExtraDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
