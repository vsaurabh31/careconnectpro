import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyIntakeExtradetailComponent } from './agency-intake-extradetail.component';

describe('AgencyIntakeExtradetailComponent', () => {
  let component: AgencyIntakeExtradetailComponent;
  let fixture: ComponentFixture<AgencyIntakeExtradetailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgencyIntakeExtradetailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyIntakeExtradetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
