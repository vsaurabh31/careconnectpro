import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AuthService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';
@Component({
  selector: 'app-confirm',
  templateUrl: './confirm-delete.component.html',
  styleUrls: ['./confirm-delete.component.scss']
})
export class ConfirmDeleteComponent extends BaseComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<ConfirmDeleteComponent>,
    private authService: AuthService,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit() {
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data:UserSession) => {
      if (!data.companyId) {
        this.dialogRef.close();
      }
    });
  }

  delete(sel: boolean): void {
        this.dialogRef.close({response: sel});
  }
}
