import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AlertType, APIUrls, AppMessage, Employee, SystemBroadcastDetail, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, HelperService, MediaService, NotificationsService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-broadcast-message',
  templateUrl: './broadcast-message.component.html',
  styleUrls: ['./broadcast-message.component.scss'],
})
export class BroadcastMessageComponent extends BaseComponent implements OnInit {
  senderInfo: Employee = {};
  senderFullName: string = "";
  constructor(
    private mediaSvc: MediaService,
    private authService: AuthService,
    private alertService: AlertService,
    private helperService: HelperService,
    private dataService: DataService,
    private notifyService: NotificationsService,
    public dialogRef: MatDialogRef<BroadcastMessageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: SystemBroadcastDetail
  ) {
    super();
  }

  ngOnInit()
  {
    if (!!this.data) {
      this.dbGetSenderInfo();
      this.notifyService.markReadSystemBroadcastMessage(this.data);
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data:UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
  }


  closeDialog() {
    this.dialogRef.close();
  }

  getEmployeeImg(imgName: any): any {
    let imgUrl: any;
    if (imgName != undefined && imgName != "") {
      imgUrl = APIUrls.GetImageEmployee + "/" + imgName;
    } else {
      imgUrl = this.mediaSvc.defaultUserImage;
    }
    return imgUrl;
  }

  dbGetSenderInfo() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: Employee;
    let ret = this.dataService
      .getSingleData(
        response,
        this.data.senderId,
        APIUrls.Employee
      )
      .finally(() => {
       this.alertService.showSpinner(false);
      })
      .subscribe(
        (data: Employee) => {
          if (!!data.id) {
            this.senderInfo = data;   
            this.senderFullName = this.helperService.getPersonCombinedFullName(this.senderInfo);         
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              "System unable to retrieve message detail");
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
