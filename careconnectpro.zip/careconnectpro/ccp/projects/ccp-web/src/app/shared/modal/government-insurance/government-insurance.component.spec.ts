import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GovernmentInsuranceComponent } from './government-insurance.component';

describe('MedicareComponent', () => {
  let component: GovernmentInsuranceComponent;
  let fixture: ComponentFixture<GovernmentInsuranceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GovernmentInsuranceComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GovernmentInsuranceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
