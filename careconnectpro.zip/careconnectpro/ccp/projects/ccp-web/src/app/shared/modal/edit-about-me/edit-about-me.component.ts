import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AlertType, APIUrls, AppConstants, Employee, EmployeeProfile, MediaFile, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, EmployeeService, HelperService, MediaService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-edit-about-me',
  templateUrl: './edit-about-me.component.html',
  styleUrls: ['./edit-about-me.component.scss'],
})
export class EditAboutMeComponent extends BaseComponent implements OnInit {
  employee: Employee = {};
  supportedFiles: string = "";
  htmlValidImageFiles: string = "";
  isProcessing: boolean = false;
  tempMediaFile: MediaFile = {};
  employeeImage: string = "";
  employeeProfile: EmployeeProfile = {};
  isDataChanged: boolean = false;

  constructor(
    private authService: AuthService,
    private employeeService: EmployeeService,
    private mediaSvc: MediaService,
    private alertService: AlertService,
    private helperService: HelperService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<EditAboutMeComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  getEmployeeImg(imgName: any): any {
    let imgUrl: any;

    if (imgName != undefined && imgName != "") {
      imgUrl = APIUrls.GetImageEmployee + "/" + imgName;
    } else {
      imgUrl = this.mediaSvc.defaultUserImage;
    }
    return imgUrl;
  }

  formDataChanged(evt: any) {
    this.isDataChanged = true;
  }

  ngOnInit(): void {
    this.supportedFiles = this.helperService.getSupportedImageFilesList();
    this.htmlValidImageFiles = this.helperService.getSupportedImageFilesInputFileAccept();

    if (!!this.data.value) {
      this.employee = { ...this.data.value };
      this.employeeProfile = { ...this.employee.profile };
      if (this.employeeProfile.photoName != undefined && this.employeeProfile.photoName != "") {
        this.employeeImage = APIUrls.GetImageEmployee + "/" + this.employeeProfile.photoName;
      } else {
        this.employeeImage = this.mediaSvc.defaultUserImage;
      }
    } else {
      this.alertService.displayErrorMessage(
        AlertType.Dialog,
        '',
        "Employee profile information is unavailable."
      );
      this.closeDialog();
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  logoInputChange(imgFile: any) {
    if (!!imgFile.target.files && imgFile.target.files.length > 0) {
      const file: File = imgFile.target.files[0];
      const validImage = this.validateImage(file);
      if (this.validateImage(file)) {
        this.dbSaveTempImage(file);
      }
    }
  }

  dbSaveTempImage(file: File) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    const uploadData = new FormData();
    uploadData.append('image', file);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(uploadData, APIUrls.MediaImagesEmployeePreview + "/" + this.employee.id, true)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.getUploadedFile();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  getUploadedFile() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const mediaFile: MediaFile = {};
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .getSingleData(mediaFile, this.employee.id, APIUrls.MediaImagesEmployeeGetAll)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (files: any) => {
          if (files != null) {
            this.tempMediaFile = files[0];
            this.employeeImage =
              APIUrls.GetImageEmployeeTemp + "/" + files[0].fileName;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  updateEmployeeProfile() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.employeeProfile, APIUrls.EmployeeProfile)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(AlertType.Toast, "", "Employee profile updated");
            this.employeeService.refreshView();
            this.closeDialog();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  submitData() {
    if (!this.tempMediaFile.fileName && !this.isDataChanged) {
      return;
    }
    if (!this.tempMediaFile.fileName && this.isDataChanged) {
      this.updateEmployeeProfile();
    } else {
      this.saveImageDb();
    }
    
  }


  saveImageDb() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    if (!this.tempMediaFile.fileName) {
      return
    }
    this.tempMediaFile.employeeFile = this.tempMediaFile.fileName;
    this.employeeProfile.photoName = this.tempMediaFile.fileName;
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.tempMediaFile, APIUrls.MediaImagesEmployeeSave)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.updateEmployeeProfile();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  validateImage(file: File): boolean {
    let validStatus: boolean = true;
    if (file.size > AppConstants.MaxImageFileSize) {
      this.alertService.displayErrorMessage(
        AlertType.Dialog,
        '',
        `The image file size must be less than ${AppConstants.MaxImageFileSize} bytes`
      );
      validStatus = false;
    }
    const fileExts = file.name.split('.');
    let invalidExt: boolean = false;
    if (fileExts.length < 2) {
      invalidExt = true;
    } else {
      if (AppConstants.ValidImageFiles.findIndex(item => item.toLowerCase() == fileExts[fileExts.length - 1]) < 0) {
        invalidExt = true;
      }
    }

    if (invalidExt) {
      this.alertService.displayErrorMessage(
        AlertType.Dialog,
        '',
        `The image file is not supported. The supported image files are: ${this.supportedFiles}`
      );
      validStatus = false;
    }
    return validStatus;
  }
}
