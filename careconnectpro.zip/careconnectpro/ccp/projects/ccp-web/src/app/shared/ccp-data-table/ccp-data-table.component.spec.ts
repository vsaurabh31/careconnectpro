import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CcpDataTableComponent } from './ccp-data-table.component';

describe('CcpDataTableComponent', () => {
  let component: CcpDataTableComponent;
  let fixture: ComponentFixture<CcpDataTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CcpDataTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CcpDataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
