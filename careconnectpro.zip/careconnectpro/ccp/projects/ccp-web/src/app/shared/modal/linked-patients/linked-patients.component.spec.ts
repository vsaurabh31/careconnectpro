import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkedPatientsComponent } from './linked-patients.component';

describe('LinkedPatientsComponent', () => {
  let component: LinkedPatientsComponent;
  let fixture: ComponentFixture<LinkedPatientsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LinkedPatientsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LinkedPatientsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
