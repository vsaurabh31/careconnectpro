import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientPaymentProfileComponent } from './patient-payment-profile.component';

describe('PatientPaymentProfileComponent', () => {
  let component: PatientPaymentProfileComponent;
  let fixture: ComponentFixture<PatientPaymentProfileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PatientPaymentProfileComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientPaymentProfileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
