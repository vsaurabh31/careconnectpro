import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { Physician, Address, PatientReferralPhysician, AddressCodes, StateUS, Patient, UserSession, PeoplePlacesCodes, IdType } from 'model-lib';
import { PatientService, AlertService, DataService, HelperService, AuthService, NotificationsService } from 'service-lib';
import { APIUrls } from 'model-lib';
import { AlertType } from 'model-lib';
import { AppMessage } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-physician',
  templateUrl: './physician.component.html',
  styleUrls: ['./physician.component.scss']
})
export class PhysicianComponent extends BaseComponent implements OnInit {
  physician: Physician = {};
  disablePrimary: boolean = false;
  physicianPhone: string;
  physicianFax: string = "";
  physicianAddress: Address = {};
  isPrimary: boolean = true;
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  usStates: StateUS[] = AddressCodes.USStates;
  disableSubmitBtn: boolean = false;
  isInTakeMode: boolean = false;
  physicianNpi: string = "";
  isAdminMode: boolean = false;


  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private dataService: DataService,
    private helperService: HelperService,
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationsService,
    public dialogRef: MatDialogRef<PhysicianComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.isAdminMode) {
      this.isAdminMode = this.data.isAdminMode;
    }

    if (!!this.data.value) {
      this.isEditMode = true;
      this.physician = { ...this.data.value };
      this.physicianAddress = this.helperService.getPrimaryAddress(this.physician);
      if (this.physicianAddress) {
        this.physicianAddress.state = this.usStates[0].id;
      }
      const phone = this.helperService.getContactByType(PeoplePlacesCodes.ContactWorkPhone, this.physician.contacts);
      const fax = this.helperService.getContactByType(PeoplePlacesCodes.ContactFax, this.physician.contacts);
      const _npi = this.helperService.getIdentificationByType(IdType.npi, this.physician);
      if (!!phone) {
        this.physicianPhone = phone.value;
      }
      if (!!fax) {
        this.physicianFax = fax.value;
      }
      if (!!_npi) {
        this.physicianNpi = _npi.value;
      }
      
      if(!this.isAdminMode) {
        const patient = this.patientService.getPatient();
        const refPhysician = patient.referralPhysicians.find(item => item.physicianId == this.physician.id);
        if (!!refPhysician) {
          this.isPrimary = !!refPhysician.isPrimary ? true : false;
        }
      }
      this.getStateForEdit();
    }
    
    if(!this.isAdminMode) {
      this.validateIsPrimaryEnable();
      this.isInTakeMode = this.patientService.getInTakeMode();
      this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
        .subscribe(val => {
          this.isInTakeMode = val;
        });
    };

    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  validateIsPrimaryEnable() {
    const patient: Patient = this.patientService.getPatient();
    if (!patient.referralPhysicians) {
      return
    }
    const idx = patient.referralPhysicians.findIndex(item => item.isPrimary == true);
    if ((idx > -1) && (patient.referralPhysicians[idx].physicianId != this.physician.id)) {
      this.disablePrimary = true;
      if (this.isEditMode) {
        this.disableSubmitBtn = true;
      } else {
        this.isPrimary = false;
      }
      this.alertService.displayWarningMessage(AlertType.Toast, '',
        "Another physician is set as the primary for this patient. This record can't be changed.");
    } else {
      this.disablePrimary = false;
    }
  }

  getStateForEdit() {
    if (this.usStates.findIndex(item => item.id == this.physicianAddress.state) < 0) {
      const alternateState = this.usStates.find(item => item.value == this.physicianAddress.state);
      if (!!alternateState) {
        this.physicianAddress.state = alternateState.id;
      }
    }
  }

  initData() {
    this.physicianAddress.state = this.usStates[0].id;
  }

  closeDialog(refreshView?: boolean, returnThirdParty?: boolean): void {
    if ( this.isAdminMode && returnThirdParty) {
      this.router.navigateByUrl(`thirdparty/physician/detail/${this.physician.id}`);
      this.notificationService.refreshPhysicianRecord();
      this.dialogRef.close(refreshView);   
    } else {
      this.dialogRef.close(refreshView); 
    }  
  }


  submitForm() {
    let patient = this.patientService.getPatient();
    if (!!this.data.returnData) {
      this.addPhysicianDatabase();
      return
    }

    if (this.isInTakeMode) {
      if (this.isEditMode) {
        this.updateView(patient);
      } else {
        this.addPhysicianDatabase();
      }
    } else {
      if (this.isEditMode) {
        if (!this.isAdminMode) {
          this.dbUpdateReferralPhysician(patient);
        } else {
          this.updatePhysicianDatabase();
        }        
      } else {
        this.addPhysicianDatabase();
      }
    }
  }


  dbAddReferralPhysician(patient: Patient, refPhysician: PatientReferralPhysician) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(refPhysician, APIUrls.PatientReferralPhysician)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            refPhysician.id = data;
            patient.referralPhysicians.push(refPhysician);
            this.patientService.updatePatient(patient);
            this.dialogRef.close(this.physician);
          } else {
            this.alertService.displayErrorMessage(AlertType.Dialog, "", "Api Error - Add Physician to patient failed.");            
          }          
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateReferralPhysician(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let idx = patient.referralPhysicians.findIndex(item => item.physicianId == this.physician.id);
    let refPhysician: PatientReferralPhysician = patient.referralPhysicians[idx];
    refPhysician.isPrimary = this.isPrimary;
    let ret = this.dataService
      .updateData(refPhysician, APIUrls.PatientReferralPhysician)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView(patient: Patient) {
    if (this.isEditMode) {
      let idx = patient.referralPhysicians.findIndex(item => item.physicianId == this.physician.id);
      patient.referralPhysicians[idx].isPrimary = this.isPrimary;
      this.patientService.updatePatient(patient);
      this.alertService.displaySuccessMessage(
        AlertType.Toast,
        '',
        'Physician record updated!'
      );
      this.closeDialog();
    } else {
      this.addPhysicianDatabase();
    }
  }

  getPhysicianContactIdent() {
    const currentUser = this.authService.getUserLoggedIn();
    this.physician.companyId = currentUser.companyId;
    this.physician.lastUpdatedUserId = currentUser.employeeId;
    this.physicianAddress.isPrimary = true;
    this.physicianAddress.country = "US";
    this.physician = this.helperService.addUpdateAddress(this.physicianAddress, this.physician);
    this.physician = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactWorkPhone, this.physicianPhone, this.physician);
    this.physician = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactFax, this.physicianFax, this.physician);
    this.physician = this.helperService.addUpdateIdentificationByVal("", IdType.npi, this.physicianNpi, this.physician);
  }


  updatePhysicianDatabase() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.getPhysicianContactIdent();
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.physician, APIUrls.Physician)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              '',
              'Physician record updated successfully!!'
            );
            this.closeDialog(true);
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.ErrorUpdateDatabaseRecordFailed
            );
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  addPhysicianDatabase() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.getPhysicianContactIdent();
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.physician, APIUrls.Physician)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.physician.id = data;
              if (!this.isAdminMode) {
                this.postDbAddNonAdmin(data);
              } else {
                this.alertService.displaySuccessMessage(
                  AlertType.Toast,
                  '',
                  'Physician record added successfully!!'
                );
                this.closeDialog(true, true);
              }
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.ErrorUpdateDatabaseRecordFailed
            );
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  postDbAddNonAdmin(data: string) {
    this.alertService.displaySuccessMessage(
      AlertType.Toast,
      '',
      'Physician added to patient record!'
    );
    this.physician.id = data;
    let patient = this.patientService.getPatient();
    let refPhysician: PatientReferralPhysician = { physicianId: data, isPrimary: this.isPrimary };
    if (!patient.referralPhysicians) {
      patient.referralPhysicians = [];
    }
    if (this.isInTakeMode) {
      patient.referralPhysicians.push(refPhysician);
      this.patientService.updatePatient(patient);
      this.dialogRef.close(this.physician);
    } else {
      refPhysician.patientId = patient.id;
      this.dbAddReferralPhysician(patient, refPhysician);
    }
  }

  
  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }


}
