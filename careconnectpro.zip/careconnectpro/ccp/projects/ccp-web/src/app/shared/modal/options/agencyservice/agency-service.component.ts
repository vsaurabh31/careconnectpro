import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { Guid } from 'guid-typescript';
import { AlertType, APIUrls, Company, CompanyService, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService } from 'service-lib';
import { BaseComponent } from '../../../core/base.component';

@Component({
  selector: 'app-agency-service',
  templateUrl: './agency-service.component.html',
  styleUrls: ['./agency-service.component.scss']
})
export class AgencyServiceComponent extends BaseComponent implements OnInit {

  agencyService: CompanyService = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  agency: Company = {};
  recordExist: boolean = false;

  constructor(
    private companyService: CompanyBusinessService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<AgencyServiceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.agencyService = { ...this.data.value };
    } else {
      this.agencyService.id = Guid.create().toString();
    }
    this.agency = this.companyService.getCompany();
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {
    if (this.validateExistingRecord()) {
      return;
    }
    if (this.isEditMode) {
      this.dbUpdateAgencyService();
    } else {
        this.dbAddAgencyService();
    }
}

clearRecordExistError() {
  this.recordExist = false;
}

validateExistingRecord(): boolean {
  const agency = this.companyService.getCompany();
  if (!agency.services) {
    return false;
  }
  if (agency.services.findIndex(item => (item.serviceName == this.agencyService.serviceName) && (item.id != this.agencyService.id)) > -1) {
    this.recordExist = true;
    return true;
  }
  return false;
}

dbAddAgencyService() {
  this.alertService.setDisplayExceptionAlertMsg(true);
  this.isProcessing = true;
  this.agencyService.companyId = this.agency.id;
  let ret = this.dataService
    .postData(this.agencyService, APIUrls.CompanyServices)
    .finally(() => {
      this.isProcessing = false;
    })
    .subscribe(
      data => {
        if (!!data) {
          this.agencyService.id = data;
        }
        this.updateView();
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
}

dbUpdateAgencyService() {
  this.alertService.setDisplayExceptionAlertMsg(true);
  this.isProcessing = true;
  let ret = this.dataService
    .updateData(this.agencyService, APIUrls.CompanyServices)
    .finally(() => {
      this.isProcessing = false;
    })
    .subscribe(
      data => {
        this.updateView();
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
}

updateView() {
  let alertMsg: string = "";
  if (this.isEditMode) {
    alertMsg = 'Agency service updated!';
  } else {
    alertMsg = 'Agency service added!';
  }
  this.companyService.refreshView();
  this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
  this.closeDialog();
}

}
