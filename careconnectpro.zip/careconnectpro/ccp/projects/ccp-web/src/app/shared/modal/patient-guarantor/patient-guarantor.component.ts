import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { PatientGuarantor, Address, StateUS, AddressCodes, UserSession, AlertType, ContactType, PatientConstants, PeoplePlacesCodes, AppMessage, APIUrls, Patient, RaceType } from 'model-lib';
import { PatientService, AlertService, DataService, HelperService, AuthService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';
import { Guid } from 'guid-typescript';

@Component({
  selector: 'app-patient-guarantor',
  templateUrl: './patient-guarantor.component.html',
  styleUrls: ['./patient-guarantor.component.scss']
})
export class PatientGuarantorComponent extends BaseComponent implements OnInit {
  isCancel: boolean = false;
  guarantor: PatientGuarantor = {};
  disablePrimary: boolean = false;
  guarantorPhone: string = "";
  guarantorFax: string = "";
  guarantorEmail: string = "";
  guarantorAddress: Address = {};
  isPrimary: boolean = true;
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  usStates: StateUS[] = AddressCodes.USStates;
  disableSubmitBtn: boolean = false;
  recordExistInPatient: boolean = false;
  isInTakeMode: boolean = false;

  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private dataService: DataService,
    private helperService: HelperService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<PatientGuarantorComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.guarantor = { ...this.data.value };
      this.guarantorAddress = this.helperService.getPrimaryAddress(this.guarantor);
      const phone =  this.helperService.getContactByType(PeoplePlacesCodes.ContactHomePhone, this.guarantor.contacts);
      const fax = this.helperService.getContactByType(PeoplePlacesCodes.ContactFax, this.guarantor.contacts);
      const email = this.helperService.getContactByType(PeoplePlacesCodes.ContactEmail, this.guarantor.contacts);
      if (!!phone) {
        this.guarantorPhone = phone.value;
      }
      if (!!fax) {
        this.guarantorFax = fax.value;
      }
      if (!!email) {
        this.guarantorEmail = email.value;
      }
      this.getStateForEdit();
    } else {
      this.guarantor.id = Guid.create().toString();
      this.guarantorAddress.isPrimary = true;
    }

    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data:UserSession) => {
      if (!data.companyId) {
        this.closeDialog(true);
      }
    });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
  }


  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  closeDialog(isCancel: boolean): void {
    this.dialogRef.close(isCancel);
  }

  getStateForEdit() {
    if (this.usStates.findIndex(item => item.id == this.guarantorAddress.state) < 0) {
      const alternateState = this.usStates.find(item => item.value == this.guarantorAddress.state);
      if (!!alternateState) {
        this.guarantorAddress.state = alternateState.id;
      }
    }
  }

  initData() {
    this.guarantorAddress.state = this.usStates[0].id;
  }

  submitForm() {
    const userSession = this.authService.getUserLoggedIn();
    this.guarantor = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactHomePhone, this.guarantorPhone, this.guarantor);
    this.guarantor = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactFax, this.guarantorFax, this.guarantor);
    this.guarantor = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactEmail, this.guarantorEmail, this.guarantor);
    this.guarantor = this.helperService.addUpdateAddress(this.guarantorAddress, this.guarantor);
    let patient = this.patientService.getPatient();
    patient.isPatientGuarantor = false;
    this.guarantor.patientId = patient.id;
    this.guarantor.race = RaceType.NotApplicable;
    this.guarantor.lastUpdatedUserId = userSession.employeeId;

    if (!patient.guarantors) {
      patient.guarantors = [];
    }
  
    if (this.isInTakeMode) {
      this.updateView(patient);
    } else {
      if (this.isEditMode) {
        this.dbUpdateGuarantor(patient);
      } else {
        this.dbAddGuarantor(patient);
      }
    }
  }

  dbAddGuarantor(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.guarantor, APIUrls.PatientGuarantor)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.guarantor.id = data;
          }
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateGuarantor(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.guarantor, APIUrls.PatientGuarantor)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView(patient: Patient) {
    let displayInfoAlert: boolean = true;
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = 'Guarantor data record updated!';
      let idx = patient.guarantors.findIndex(item => item.id == this.guarantor.id);
      patient.guarantors[idx] = this.guarantor;
    } else {
      if (patient.guarantors.findIndex(item => item.taxId == this.guarantor.taxId) < 0) {
        patient.guarantors.push(this.guarantor);
        alertMsg = 'Guarantor requested data record added!';
      } else {
        this.recordExistInPatient = true;
        return
      }
    }
    
    this.patientService.updatePatient(patient);
    if (displayInfoAlert) {
      this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    } else {
      this.alertService.displayWarningMessage(AlertType.Toast, '', alertMsg);
    }
    this.closeDialog(false);
  }




  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId){
      this.closeDialog(true);
    }
  }


}
