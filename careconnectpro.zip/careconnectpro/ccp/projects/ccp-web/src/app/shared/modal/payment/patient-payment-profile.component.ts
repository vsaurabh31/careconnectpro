import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { PatientService, AlertService, HelperService, AuthService, DataService } from 'service-lib';
import { StateUS, AddressCodes, Address, PaymentProfile, UserSession, Patient, AlertType, GenericIdValue, PaymentConstants, AppMessage, APIUrls } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { Guid } from 'guid-typescript';

@Component({
  selector: 'app-patient-payment-profile',
  templateUrl: './patient-payment-profile.component.html',
  styleUrls: ['./patient-payment-profile.component.scss']
})
export class PatientPaymentProfileComponent extends BaseComponent implements OnInit {
  paymentProfile: PaymentProfile = {};
  disablePrimary: boolean = false;
  isPrimary: boolean = true;
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  usStates: StateUS[] = AddressCodes.USStates;
  recordExistInPatient: boolean = false;
  paymentTypes: GenericIdValue[] = PaymentConstants.PaymentTypes.sort((a, b) => a.value.localeCompare(b.value));;
  ccTypes: GenericIdValue[] = PaymentConstants.CCardTypes.sort((a, b) => a.value.localeCompare(b.value));
  isInTakeMode: boolean = false;

  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private helperService: HelperService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<PatientPaymentProfileComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.paymentProfile = { ...this.data.value };
      this.getStateForEdit();
    } else {
      this.paymentProfile.paymentTypeId = this.paymentTypes[0].id;
      this.paymentProfile.cardTypeId = this.ccTypes[0].id;
      this.paymentProfile.id = Guid.create().toString();
      this.paymentProfile.isPrimary = true;
    }

    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
      this.isInTakeMode = this.patientService.getInTakeMode();
      this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
        .subscribe(val => {
          this.isInTakeMode = val;
        });
  }



  getStateForEdit() {
    if (this.usStates.findIndex(item => item.id == this.paymentProfile.billingState) < 0) {
      const alternateState = this.usStates.find(item => item.value == this.paymentProfile.billingState);
      if (!!alternateState) {
        this.paymentProfile.billingState = alternateState.id;
      }
    }
  }

  initData() {
    this.paymentProfile.billingState = this.usStates[0].id;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  submitForm() {
    let patient = this.patientService.getPatient();
    this.paymentProfile.patientId = patient.id;
    if (!patient.paymentProfiles) {
      patient.paymentProfiles = [];
    }
    this.preProcessSubmit();
    if (this.isInTakeMode) {
      this.updateView(patient);
    } else {
      if (this.isEditMode) {
        this.dbUpdatePaymentInfo(patient);
      } else {
        this.dbAddPaymentInfo(patient);
      }
    }

  }


  dbAddPaymentInfo(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.paymentProfile, APIUrls.PatientPaymentProfile)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.paymentProfile.id = data;
          }
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdatePaymentInfo(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.paymentProfile, APIUrls.PatientPaymentProfile)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView(patient: Patient) {
    let displayInfoAlert: boolean = true;
    let alertMsg: string = "";
       if (this.isEditMode) {
      alertMsg = 'Payment profile data record updated!';
      let idx = patient.paymentProfiles.findIndex(item => item.id == this.paymentProfile.id);
      patient.paymentProfiles[idx] = this.paymentProfile;
    } else {
      if (!this.validateExistingPayment(patient.paymentProfiles)) {
        patient.paymentProfiles.push(this.paymentProfile);
        alertMsg = 'Payment profile data record added!';
      } else {
        this.recordExistInPatient = true;
        return
      }
    }
    this.patientService.updatePatient(patient);
    if (displayInfoAlert) {
      this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    } else {
      this.alertService.displayWarningMessage(AlertType.Toast, '', alertMsg);
    }
    this.closeDialog();
  }



  getPatientInfo() {
    const _patient = this.patientService.getPatient();
    if (!_patient.lastName) {
      this.alertService.displayWarningMessage(AlertType.Toast, "", "Patient information is not yet available");
      return;
    }
    this.paymentProfile.billingFirstName = _patient.firstName;
    this.paymentProfile.billingLastName = _patient.lastName;
    if (!_patient.addresses) {
      this.alertService.displayWarningMessage(AlertType.Toast, "", "Patient address is not yet available");
      return;
    }
    if ((!!_patient.addresses) && (_patient.addresses.length > 0)) {
      const primaryAddress = this.helperService.getPrimaryAddress(_patient);
      this.paymentProfile.billingAddress1 = primaryAddress.address1;
      this.paymentProfile.billingAddress2 = primaryAddress.address2;
      this.paymentProfile.billingCity = primaryAddress.city;
      this.paymentProfile.billingState = primaryAddress.state;
      this.paymentProfile.billingZipCode = primaryAddress.zipCode;
    }
  }

  preProcessSubmit() {
    switch (this.paymentProfile.paymentTypeId) {
        case "Cash":
        case "Check":
          this.clearCreditCardDetails();
          this.clearBankAccountDetails();
          break;
        case "CreditCard":
          this.clearBankAccountDetails();
          break;
        case "BankAccount":
          this.clearCreditCardDetails();
          break;
    }
  }

  clearCreditCardDetails() {
    this.paymentProfile.billingFirstName = "";
    this.paymentProfile.billingLastName = "";
    this.paymentProfile.cardCvv ="";
    this.paymentProfile.cardExpDate = null;
    this.paymentProfile.cardNumber = "";
    this.paymentProfile.cardTypeId = "";
    this.paymentProfile.billingAddress1 = "";
    this.paymentProfile.billingAddress2 = "";
    this.paymentProfile.billingAddress3 = "";
    this.paymentProfile.billingCity = "";
    this.paymentProfile.billingState = "";
    this.paymentProfile.billingZipCode = "";
  }

  
  clearBankAccountDetails() {
    this.paymentProfile.bankName = "";
    this.paymentProfile.bankAccountNumber = "";
    this.paymentProfile.bankRoutingNumber = "";
  }

  validateExistingPayment(payments: PaymentProfile[]) {
    var isExist = false;

    if (payments.findIndex(item => (item.paymentTypeId == this.paymentProfile.paymentTypeId) && (item.cardTypeId == this.paymentProfile.cardTypeId)
      && (item.cardNumber == this.paymentProfile.cardNumber)) > -1) {
      isExist = true;
    }
    if (payments.findIndex(item => (item.paymentTypeId == this.paymentProfile.paymentTypeId) && (item.bankName == this.paymentProfile.bankName)
      && (item.bankRoutingNumber == this.paymentProfile.bankRoutingNumber) && (item.bankAccountNumber == this.paymentProfile.bankAccountNumber)) > -1) {
      isExist = true;
    }
    return isExist;
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

}
