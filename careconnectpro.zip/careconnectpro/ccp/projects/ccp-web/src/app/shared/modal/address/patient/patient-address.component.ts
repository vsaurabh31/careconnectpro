import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../../core/base.component';
import { Address, StateUS, AddressCodes, Patient, AlertType, UserSession, AppMessage, APIUrls, PatientAddress } from 'model-lib';
import { PatientService, AlertService, AuthService, DataService } from 'service-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-patient-address',
  templateUrl: './patient-address.component.html',
  styleUrls: ['./patient-address.component.scss']
})
export class PatientAddressComponent extends BaseComponent implements OnInit {
  patientAddress: PatientAddress = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  usStates: StateUS[] = AddressCodes.USStates;
  patient: Patient = {};
  disablePrimary: boolean = false;
  isInTakeMode: boolean = false;

  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<PatientAddressComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.patientAddress = { ...this.data.value };
      this.getStateForEdit();
    } else {
      this.patientAddress.id = Guid.create().toString();
      this.patientAddress.isPrimary = true;
    }
    this.validateIsPrimaryEnable();
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  validateIsPrimaryEnable() {
    const patient: Patient = this.patientService.getPatient();
    if (!patient.addresses) {
      patient.addresses = [];
      this.patient.addresses = [];
    }
    const idx = patient.addresses.findIndex(item => item.isPrimary == true);
    if ((idx > -1) && (patient.addresses[idx].id != this.patientAddress.id)) {
      if (!this.isEditMode) {
        this.patientAddress.isPrimary = false;
      }
      this.disablePrimary = true;
      this.alertService.displayWarningMessage(AlertType.Toast, '',
        "Another address is set as the primary for this patient. The primary address field can't be changed.");
    } else {
      this.disablePrimary = false;
    }
  }

  getStateForEdit() {
    if (this.usStates.findIndex(item => item.id == this.patientAddress.state) < 0) {
      const alternateState = this.usStates.find(item => item.value == this.patientAddress.state);
      if (!!alternateState) {
        this.patientAddress.state = alternateState.id;
      }
    }
  }

  initData() {
    this.patientAddress.state = this.usStates[0].id;
  }


  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {
    let patient = this.patientService.getPatient();
    this.patientAddress.patientId = patient.id;
    if (!patient.addresses) {
      patient.addresses = [];
    }

    if (this.isInTakeMode) {
      this.updateView(patient);
    } else {
      if (this.isEditMode) {
        this.dbUpdateAddress(patient);
      } else {
        this.dbAddAddress(patient);
      }
    }
  }

  dbAddAddress(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.patientAddress, APIUrls.PatientAddress)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.patientAddress.id = data;
          }
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateAddress(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.patientAddress, APIUrls.PatientAddress)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  updateView(patient: Patient) {
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = 'Address record updated!';
      let idx = patient.addresses.findIndex(item => item.id == this.patientAddress.id);
      patient.addresses[idx] = this.patientAddress;
      this.patientService.updatePatient(patient);
    } else {
      alertMsg = 'Address record added!';
      patient.addresses.push(this.patientAddress);
    }
    this.patientService.updatePatient(patient);
    this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    this.closeDialog();
  }
}
