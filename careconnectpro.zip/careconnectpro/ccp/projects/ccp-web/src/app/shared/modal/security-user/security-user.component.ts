import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AlertType, APIUrls, AppRole, Employee, EmployeeProfile, EmployeeSummary, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, HelperService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-security-user',
  templateUrl: './security-user.component.html',
  styleUrls: ['./security-user.component.scss'],
})
export class SecurityUserComponent extends BaseComponent implements OnInit {
  roleUsers: EmployeeSummary[] = [];
  appRole: AppRole = {};
  isProcessing: boolean = false;
  constructor(
    private alertService: AlertService,
    private helperService: HelperService,
    private authService: AuthService,
    private dataService: DataService,
    private router: Router,
    public dialogRef: MatDialogRef<SecurityUserComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit() {
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });

    if (!!this.data.value) {
      this.appRole = { ...this.data.value };
      this.getDbUsers();
    } else {
      this.closeDialog();
    }    
  }

  openPersonnelEdit(id: string) {
    this.router.navigateByUrl(`options/personnels/edit/${id}`);
    this.closeDialog();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  getDbUsers() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .getAllData(this.roleUsers, this.appRole.id, APIUrls.EmployeeGetAllEmployeesSummaryByRole)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.roleUsers = data;
          this.roleUsers.sort((a,b) => {return a.lastName.localeCompare(b.lastName)});
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
