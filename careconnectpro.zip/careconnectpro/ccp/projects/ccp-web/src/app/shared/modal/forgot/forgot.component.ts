import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import {
  BaseApiResponse,
  APIUrls,
  AlertType,
  AppMessage,
  UserLogin,
  GenericEmailMessage,
  MessageStatus
} from 'model-lib';
import { DataService, AlertService } from 'service-lib';
@Component({
  selector: 'app-forgot',
  templateUrl: './forgot.component.html',
  styleUrls: ['./forgot.component.scss']
})
export class ForgotComponent extends BaseComponent implements OnInit {
  resetPasswordSent = false;
  resetEmailDoesNotExist = false;
  webServerUrl: string = APIUrls.GetWebAppRootUrl;
  userLogin: UserLogin = {};
  isProcessing: boolean = false;
  resetPasswordMessage: GenericEmailMessage = {};
  messageStatus: MessageStatus = {};
  resetMail = false;
  errorMsg = '';
  isPasswordResetError = false;

  constructor(
    public dialogRef: MatDialogRef<ForgotComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dataService: DataService,
    private alertService: AlertService
  ) {
    super();
  }
  ngOnInit(): void {
    this.initMessageStatus();
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  resetPasswordClicked() {
    this.resetMail = true;
    this.userLogin = {};
    this.userLogin.resetPasswordEmail = '';
    this.clearResetError();
  }

  initMessageStatus() {
    this.messageStatus.isSuccessful = false;
    this.messageStatus.resultText = '';
  }

  getMessageTemplate(): string {
    const msg = `<div class="PlainText">Hello!<br><br>
      We've generated a URL to <span data-markjs="true" class="markclgluv583" style="background-color: yellow; color: black;">reset</span>
      your <span data-markjs="true" class="marktbxpr3yxk" style="background-color: yellow; color: black;">password</span>.
      If you did not request to <span data-markjs="true" class="markclgluv583" style="background-color: yellow; color: black;">
      reset</span> your <span data-markjs="true" class="marktbxpr3yxk" style="background-color: yellow; color: black;">password</span>
      or if you've changed your mind, simply ignore this email and nothing will happen.<br>
      You can reset your password by clicking the following URL: <br>
      <a href="${
        this.webServerUrl
      }#/resetpassword/{{ccptoken}}" target = "_blank" rel = "noopener noreferrer" data - auth="NotApplicable">
      ${this.webServerUrl}#/resetpassword/{{ccptoken}} </a><br>
      <br>
      If clicking the URL above does not work,
      copy and paste the URL into a browser window.The URL will only be valid for a limited time and will expire.
      <br>
      <br>
      Thank you, <br>
      <br>
      Care Connect Pro Support
      <br>
      1-(800) 771-3642
      <br>
      info@careconnectpro.com
      <br>
    </div>`;
    return msg;
  }

  getResetPasswordToken() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let response: BaseApiResponse;
    const ret = this.dataService
      .getSingleData(
        response,
        this.userLogin.resetPasswordEmail,
        APIUrls.GetChangePasswordToken
      )
      .finally(() => {})
      .subscribe(
        data => {
          const ret: BaseApiResponse = data;
          if (ret != null) {
            this.userLogin.token = ret.responseMessage;
            this.generateResetPasswordEmail();
          }
        },
        error => {
          this.isProcessing = false;
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  generateResetPasswordEmail() {
    this.resetPasswordMessage.email = this.userLogin.resetPasswordEmail;
    this.resetPasswordMessage.msgContent = this.getMessageTemplate();
    this.resetPasswordMessage.subject = AppMessage.ResetEmailSubject;
    this.resetPasswordMessage.token = this.userLogin.token;
    this.resetPasswordMessage.authCode = APIUrls.EmailAuthCode;
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.resetPasswordMessage, APIUrls.SendEmailApi)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const x: any = data;
          this.messageStatus.isSuccessful = true;
          this.messageStatus.resultText = AppMessage.ResetEmailSentCheckEmail;
        },
        error => {
          this.errorMsg = error;
        }
      );
  }

  clearResetError() {
    this.resetEmailDoesNotExist = false;
    this.messageStatus.isSuccessful = false;
    this.errorMsg = '';
    this.isPasswordResetError = false;
  }

  public verifyResetAccount() {
    this.clearResetError();
    this.isProcessing = true;
    let response: any;
    const ret = this.dataService
      .getSingleData(
        response,
        this.userLogin.resetPasswordEmail,
        APIUrls.AccountValidateUsername
      )
      .finally(() => {})
      .subscribe(
        (data: any) => {
          const ret: boolean = data;
          if (ret) {
            this.getResetPasswordToken();
          } else {
            this.resetEmailDoesNotExist = true;
            this.isProcessing = false;
            this.errorMsg = AppMessage.ErrorUsernameDoesnotExist;
          }
        },
        (error: any) => {
          this.messageStatus.isSuccessful = false;
          this.errorMsg = AppMessage.SendMessageFailedGeneralError;
          this.isPasswordResetError = true;
          this.isProcessing = false;
        }
      );
  }
}
