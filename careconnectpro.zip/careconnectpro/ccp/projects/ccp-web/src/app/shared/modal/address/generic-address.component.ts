import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { StateUS, AddressCodes, AlertType, UserSession } from 'model-lib';
import { AlertService, AuthService, DataService } from 'service-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';
import { BaseComponent } from '../../core/base.component';
@Component({
  selector: 'app-generic-address',
  templateUrl: './generic-address.component.html',
  styleUrls: ['./generic-address.component.scss']
})
export class GenericAddressComponent extends BaseComponent implements OnInit {
  address: any = {};
  addresses: any[] = [];
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  usStates: StateUS[] = AddressCodes.USStates;
  disablePrimary: boolean = false;
  apiAddUrl: string = "";
  apiUpdateUrl: string = "";
  updateDatabase: boolean = true;
  entityName: string = "Record";

  constructor(
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<GenericAddressComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    this.apiAddUrl = this.data.apiAddUrl;
    this.apiUpdateUrl = this.data.apiUpdateUrl;
    this.updateDatabase = this.data.updateDatabase;
    this.address = { ...this.data.value };

    if (!!this.data.addresses) {
      this.addresses = this.data.addresses;
    }
 
    if (!!this.data.entityName) {
      this.entityName = this.data.entityName;
    }

    if (!!this.address.id) {
      this.isEditMode = true;
      this.getStateForEdit();      
    } else {
      this.address.id = Guid.create().toString();
      this.address.isPrimary = true;
      this.address.state = this.usStates[0].id;
    }
    this.validateIsPrimaryEnable();
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  validateIsPrimaryEnable() {
     if (!this.addresses) {
      this.addresses = [];
    }
    const idx = this.addresses.findIndex(item => item.isPrimary == true);
    if ((idx > -1) && (this.addresses[idx].id != this.address.id)) {
      if (!this.isEditMode) {
        this.address.isPrimary = false;
      }
      this.disablePrimary = true;
      this.alertService.displayWarningMessage(AlertType.Toast, '',
        `Another address is set as the primary for this ${this.entityName}. The primary address field can't be changed.`);
    } else {
      this.disablePrimary = false;
    }
  }

  getStateForEdit() {
    if (this.usStates.findIndex(item => item.id == this.address.state) < 0) {
      const alternateState = this.usStates.find(item => item.value == this.address.state);
      if (!!alternateState) {
        this.address.state = alternateState.id;
      }
    }
  }

  initData() {
    this.address.state = this.usStates[0].id;
  }


  closeDialog(): void {
    this.dialogRef.close(this.address);
  }

  submitForm() {
    if (!this.updateDatabase) {
      this.closeDialog();
    } else {
      if (this.isEditMode) {
        this.dbUpdateAddress();
      } else {
        this.dbAddAddress();
      }
    }
  }

  dbAddAddress() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.address, this.apiAddUrl)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.address.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateAddress() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.address, this.apiUpdateUrl)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView() {
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = `${this.entityName} address updated!`;
    } else {
      alertMsg = `${this.entityName} address added!`;
    }
    this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    this.closeDialog();
  }

}
