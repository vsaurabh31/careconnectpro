import { Component, OnInit, Inject, Input } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { AlertService } from 'service-lib';
import { AppNotificationMessage } from 'model-lib';

@Component({
  selector: 'app-generic-message',
  templateUrl: './generic-message.component.html',
  styleUrls: ['./generic-message.component.scss']
})
export class GenericMessageComponent extends BaseComponent implements OnInit {
  messageDetail: String;
  appMessage: AppNotificationMessage = {};

  constructor(
    public dialogRef: MatDialogRef<GenericMessageComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private alertService: AlertService
  ) {
    super();
  }

  ngOnInit(): void {
    this.appMessage = this.alertService.getMessageNotification();
    this.messageDetail = this.appMessage.detail;
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
