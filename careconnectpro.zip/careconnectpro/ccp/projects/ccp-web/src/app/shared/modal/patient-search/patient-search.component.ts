import { Component, Inject, OnInit } from '@angular/core';
import { BaseComponent } from '../../../shared/core/base.component';
import { Contact, AlertType, APIUrls, Patient,  GenericSearch, PatientSearchResult, UserSession  } from 'model-lib';
import { HelperService, AlertService, DataService, AuthService, PatientService } from 'service-lib';
import { Router } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { } from 'model-lib';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-modal-patient-search',
  templateUrl: './patient-search.component.html',
  styleUrls: ['./patient-search.component.scss']
})
export class ModalPatientSearchComponent extends BaseComponent implements OnInit {

  patSearchKeyword: string = "";
  isProcessing: boolean = false;
  patients: PatientSearchResult[] = [];
  showNoRecordFound: boolean = false;
  patientSearch: GenericSearch = { searchFilter: "name" };
  isShowAllRec: boolean = false;

  constructor(
    private helperService: HelperService,
    private alertService: AlertService,
    private dataService: DataService,
    private authService: AuthService,
    private patientService: PatientService,
    private router: Router,
    public dialogRef: MatDialogRef<ModalPatientSearchComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { 
    super();
  }

  ngOnInit(): void {
    this.patientSearch.searchFilter = "name"; 
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data:UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
  }

  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  
  searchPatient() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.clearNoRecordError();
    this.isProcessing = true;
    const _userSession = this.authService.getUserLoggedIn();
    this.patientSearch.companyId = _userSession.companyId;
    let ret = this.dataService
      .postData(this.patientSearch, APIUrls.SearchPatients)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: PatientSearchResult[] = data;
          this.patients = response;
          if (this.patients.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );

  }

  getContactById(contactTypeVal: string, contacts: Contact[]): string {
    return this.helperService.getContactById(contactTypeVal, contacts);
  }

  getCombinedAddress(_data: any) {
    return this.helperService.getCombinedAddress(_data);
  }

  selectPatient(patient: PatientSearchResult) {
    this.closeDialog(patient.id);
  }

  closeDialog(patientId?: string): void {
    this.dialogRef.close(patientId); 
  }
}
