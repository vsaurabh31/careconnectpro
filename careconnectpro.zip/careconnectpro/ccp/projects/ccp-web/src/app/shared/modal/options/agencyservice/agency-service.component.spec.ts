import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyServiceComponent } from './agency-service.component';

describe('AgencyServiceComponent', () => {
  let component: AgencyServiceComponent;
  let fixture: ComponentFixture<AgencyServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgencyServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
