import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GenericIdentificationComponent } from './generic-identification.component';

describe('GenericIdentificationComponent', () => {
  let component: GenericIdentificationComponent;
  let fixture: ComponentFixture<GenericIdentificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GenericIdentificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GenericIdentificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
