import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalProviderSearchComponent } from './medical-provider-search.component';

describe('ProviderSearchComponent', () => {
  let component: MedicalProviderSearchComponent;
  let fixture: ComponentFixture<MedicalProviderSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalProviderSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalProviderSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
