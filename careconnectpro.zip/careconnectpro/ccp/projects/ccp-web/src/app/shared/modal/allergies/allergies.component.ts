import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { PatientAllergy, Patient, UserSession, AlertType, AppMessage, APIUrls } from 'model-lib';
import { BaseComponent } from '../../core/base.component';
import { AuthService, PatientService, AlertService, DataService } from 'service-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-allergies',
  templateUrl: './allergies.component.html',
  styleUrls: ['./allergies.component.scss']
})
export class AllergiesComponent extends BaseComponent implements OnInit {
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  patAllergy: PatientAllergy = {};
  patient: Patient = {};
  recordExistInPatient: boolean = false;
  isInTakeMode: boolean = false;

  constructor(
    private authService: AuthService,
    private patientService: PatientService,
    private alertService: AlertService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<AllergiesComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit() {
    this.initData();
    this.isEditMode = this.data.editMode;
    if (!this.isEditMode) {
      this.patAllergy.id = Guid.create().toString();
      this.patAllergy.value = true;
    } else {
      this.patAllergy = { ...this.data.value };
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
  }

  initData() {
    this.patient = this.patientService.getPatient();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {
    this.patient = this.patientService.getPatient();
    this.patAllergy.patientId = this.patient.id;
    if (!this.patient.allergies) {
      this.patient.allergies = [];
    }
    if (this.isInTakeMode) {
      this.updateView();
    } else {
      if (this.isEditMode) {
        this.dbUpdateHistory();
      } else {
        if (!this.validateExistingRecord()) {
          this.dbAddHistory();
        } else {
          this.recordExistInPatient = true;
          return
        }
        
      }
    }
  }

  validateExistingRecord(): boolean {
    if (this.patient.allergies.findIndex(item => item.allergyName == this.patAllergy.allergyName) > -1) {
      this.recordExistInPatient = true;
      return true;
    }
    return false;
  }


  dbAddHistory() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.patAllergy, APIUrls.PatientAllergy)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.patAllergy.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateHistory() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.patAllergy, APIUrls.PatientAllergy)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView() {
    let _isSuccess = false;
    let alertMsg: string = "";
     if (!this.isEditMode) {
      if (!this.validateExistingRecord()) {
        this.patient.allergies.push(this.patAllergy);
        _isSuccess = true;
        alertMsg = 'Allergy record added!';
      } else {
        this.recordExistInPatient = true;
        return
      }
    } else {
      let _index = this.patient.allergies.findIndex(item => item.id == this.patAllergy.id);
      if (_index > - 1) {
        this.patient.allergies[_index] = this.patAllergy;
        _isSuccess = true;
        alertMsg = 'Allergy record updated!';
      } else {
        this.alertService.displayErrorMessage(AlertType.Toast, '',
          "Allergy record doesn't exist in patient record.");
      }
    }
    this.patientService.updatePatient(this.patient);
    if (_isSuccess) {
      this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    }
    this.closeDialog();
  }


  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

}
