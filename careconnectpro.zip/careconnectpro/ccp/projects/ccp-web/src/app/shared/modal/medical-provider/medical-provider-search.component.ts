import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { MedicalProviderComponent } from './medical-provider.component';
import { BaseComponent } from '../../core/base.component';
import { MedicalProvider, Address, Patient, PatientReferralProvider, AlertType, APIUrls, AppMessage, Contact, UserSession, MedicalProviderSearchResult } from 'model-lib';
import { AlertService, DataService, HelperService, PatientService, AuthService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';
import { GenericSearch } from 'model-lib';

@Component({
  selector: 'app-medical-provider-search',
  templateUrl: './medical-provider-search.component.html',
  styleUrls: ['./medical-provider-search.component.scss']
})
export class MedicalProviderSearchComponent extends BaseComponent implements OnInit {
  provider: MedicalProviderSearchResult = {};
  providerPhone: string;
  providerFax: string = "";
  providerAddress: Address = {};
  isPrimary: boolean;
  providerSearch: GenericSearch = { searchFilter: "name" };
  providers: MedicalProvider[] = [];
  showNoRecordFound: boolean = false;
  patient: Patient = {};
  isProcessing: boolean = false;
  recordExistInPatient: boolean = false;
  isInTakeMode: boolean = false;


  constructor(private dialog: MatDialog,
    private authService: AuthService,
    private patientService: PatientService,
    private alertService: AlertService,
    private dataService: DataService,
    private helperService: HelperService,
    public dialogRef: MatDialogRef<MedicalProviderSearchComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) { 
      super();
    }


  ngOnInit(): void {
    this.validateUserSession();
    this.refreshPatientData();
    this.patientService.isPatientRecordChanged$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        if (val) {
          this.refreshPatientData();
        }
      });
      this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data:UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
      this.isInTakeMode = this.patientService.getInTakeMode();
      this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
        .subscribe(val => {
          this.isInTakeMode = val;
        });
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId){
      this.closeDialog();
    }
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  refreshPatientData() {
    this.patient = this.patientService.getPatient();
    if (!this.patient.companyId) {
      const _userSession = this.authService.getUserLoggedIn();
      this.providerSearch.companyId = _userSession.companyId;
      this.patient.companyId = _userSession.companyId;
    }
    this.providerSearch.companyId = this.patient.companyId;
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  getAddressData(_provider:MedicalProviderSearchResult, fieldName: string) {
    const primaryAddress = this.helperService.getPrimaryAddress(_provider);
    return primaryAddress[fieldName];
  }

  openAddProviderDialog(): void {
    this.dialogRef.close();
    const dialogRef = this.dialog.open(MedicalProviderComponent, {
      data: { name: 'Add Medical Provider' },
    });
    dialogRef.afterClosed().subscribe((result) => { });
  }

  searchProvider() {
    this.showNoRecordFound = false;
    let x = this.providerSearch;
    if ((this.providerSearch.searchKeyword != null) && (this.providerSearch.searchKeyword != "")) {
      this.dbSearch();
    }
  }

  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  selectProvider(provider:MedicalProvider) {
    if (!!this.data.returnData) {
      this.dialogRef.close(provider);
      return
    }
    this.continuePatientIntake(provider);
  }

  continuePatientIntake(provider:MedicalProvider) {
    let patient = this.patientService.getPatient();
    if(!patient.referralProviders) {
      patient.referralProviders = [];
    }
    if (patient.referralProviders.findIndex(item => item.providerId == provider.id) < 0) {
      let refProvider: PatientReferralProvider = {providerId: provider.id, isPrimary: false}; 
      refProvider.patientId = patient.id;
      if (this.isInTakeMode) {
        this.updateView(patient, refProvider);
      } else {
        this.dbAddProvider(patient, refProvider);
      }

    } else {
      this.recordExistInPatient = true;
      return
    }
    this.closeDialog();
  }

  updateView(patient: Patient, refProvider: PatientReferralProvider) {
    patient.referralProviders.push(refProvider);      
    this.patientService.updatePatient(patient);
    this.alertService.displaySuccessMessage(
      AlertType.Toast,
      '',
      'Medical provider added to patient record!'
    );
    this.closeDialog();
  }

  dbAddProvider(patient: Patient, refProvider: PatientReferralProvider) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(refProvider, APIUrls.PatientReferralProvider)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            refProvider.id = data;
          }
          this.updateView(patient, refProvider);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  getDbProviderRecord(id: string) {
    const _provider: MedicalProvider = {};
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .getSingleData(_provider,id, APIUrls.MedicalProvider)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          const response: MedicalProvider = data;
            this.selectProvider(response);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  } 


  dbSearch() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.providerSearch, APIUrls.SearchMedicalProviders)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: MedicalProviderSearchResult[] = data;
          this.providers = response;
          if (this.providers.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

}
