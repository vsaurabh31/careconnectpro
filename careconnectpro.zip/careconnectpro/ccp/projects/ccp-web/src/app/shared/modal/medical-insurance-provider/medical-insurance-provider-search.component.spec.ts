import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalInsuranceProviderSearchComponent } from './medical-insurance-provider-search.component';

describe('MedicalInsuranceProviderSearchComponent', () => {
  let component: MedicalInsuranceProviderSearchComponent;
  let fixture: ComponentFixture<MedicalInsuranceProviderSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalInsuranceProviderSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalInsuranceProviderSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
