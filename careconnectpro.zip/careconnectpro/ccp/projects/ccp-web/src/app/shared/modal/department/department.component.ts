import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { Guid } from 'guid-typescript';
import { AlertType, APIUrls, Company, Department, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';
@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.scss'],
})
export class DepartmentComponent extends BaseComponent implements OnInit {
  agencyDepartment: Department = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  agency: Company = {};
  recordExist: boolean = false;

  constructor(
    private agencyService: CompanyBusinessService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<DepartmentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.agencyDepartment = { ...this.data.value };
    } else {
      this.agencyDepartment.id = Guid.create().toString();
    }
    this.agency = this.agencyService.getCompany();
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {

    if (this.isEditMode) {
      this.dbUpdateDepartment();
    } else {
      if (!this.validateExistingRecord()){
        this.dbAddDepartment();
      }
    }
}

clearRecordExistError() {
  this.recordExist = false;
}

validateExistingRecord(): boolean {
  const agency = this.agencyService.getCompany();
  if (!agency.departments) {
    return false;
  }
  if (agency.departments.findIndex(item => item.name == this.agencyDepartment.name) > -1) {
    this.recordExist = true;
    return true;
  }
  return false;
}

dbAddDepartment() {
  this.alertService.setDisplayExceptionAlertMsg(true);
  this.isProcessing = true;
  this.agencyDepartment.companyId = this.agency.id;
  let ret = this.dataService
    .postData(this.agencyDepartment, APIUrls.CompanyDepartmentsApi)
    .finally(() => {
      this.isProcessing = false;
    })
    .subscribe(
      data => {
        if (!!data) {
          this.agencyDepartment.id = data;
        }
        this.updateView();
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
}

dbUpdateDepartment() {
  this.alertService.setDisplayExceptionAlertMsg(true);
  this.isProcessing = true;
  let ret = this.dataService
    .updateData(this.agencyDepartment, APIUrls.CompanyDepartmentsApi)
    .finally(() => {
      this.isProcessing = false;
    })
    .subscribe(
      data => {
        this.updateView();
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
}


updateView() {
  let alertMsg: string = "";
  if (this.isEditMode) {
    alertMsg = 'Department updated!';
  } else {
    alertMsg = 'Department added!';
  }
  this.agencyService.refreshView();
  this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
  this.closeDialog();
}
}
