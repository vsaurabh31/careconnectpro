import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalHistoryAddupdateComponent } from './medical-history-addupdate.component';

describe('MedicalHistoryAddupdateComponent', () => {
  let component: MedicalHistoryAddupdateComponent;
  let fixture: ComponentFixture<MedicalHistoryAddupdateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MedicalHistoryAddupdateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalHistoryAddupdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
