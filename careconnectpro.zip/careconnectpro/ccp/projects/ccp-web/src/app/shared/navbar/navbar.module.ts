import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../../shared/shared.module';
import { NavbarComponent } from './navbar.component';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatMenuModule } from '@angular/material/menu';
import { MatExpansionModule } from '@angular/material/expansion';

@NgModule({
  declarations: [NavbarComponent],
  imports: [CommonModule,SharedModule, MatSidenavModule, MatMenuModule, MatExpansionModule],
  exports: [NavbarComponent]
})
export class NavbarModule {}
