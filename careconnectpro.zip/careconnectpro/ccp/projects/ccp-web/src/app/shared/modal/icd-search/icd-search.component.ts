import { Component, OnInit, Inject } from '@angular/core';
import { BaseComponent } from '../../core/base.component';
import { GenericSearch, IcdCode, APIUrls, AlertType, AppMessage, UserSession } from 'model-lib';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AlertService, AuthService, DataService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-icd-search',
  templateUrl: './icd-search.component.html',
  styleUrls: ['./icd-search.component.scss']
})
export class IcdSearchComponent extends BaseComponent implements OnInit {
  icdSearch: GenericSearch = { searchFilter: "name" };
  showNoRecordFound: boolean = false;
  isProcessing: boolean = false;
  recordExistInPatient: boolean = false;
  icdCodes: IcdCode[] = [];
  selectedIcdCode: IcdCode = {};
  
  constructor(
    private dialog: MatDialog,
    private authService: AuthService,
    private alertService: AlertService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<IcdSearchComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { 
    super();
  }

  ngOnInit(): void {
    this.icdSearch.searchFilter = "description";
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data: UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
  }

  selectIcdCode(icdCode: IcdCode) {
    this.selectedIcdCode = icdCode;
    this.closeDialog();
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  closeDialog(): void {
    this.dialogRef.close(this.selectedIcdCode);
  }

  
  searchIcd() {
    this.showNoRecordFound = false;
    let x = this.icdSearch;
    if ((this.icdSearch.searchKeyword != null) && (this.icdSearch.searchKeyword != "")) {
      this.dbSearch();
    }
  }

  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  dbSearch() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.icdSearch, APIUrls.IcdSearch)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: IcdCode[] = data;
          this.icdCodes = response;
          if (this.icdCodes.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

}
