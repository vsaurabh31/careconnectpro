import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ccp-data-table',
  templateUrl: './ccp-data-table.component.html',
  styleUrls: ['./ccp-data-table.component.scss']
})
export class CcpDataTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
