import { Component, Inject, OnInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { MatCard } from '@angular/material/card';
import { AlertType, APIUrls, AppConstants, CompanySubscription, EmployeeContact, GenericEmailMessage, SubscriptionPackage, UserPaymentInfo, UserSession } from 'model-lib';
import { AlertService, AppHtmlControlService, AuthService, BillingService, CompanyBusinessService, DataService, HelperService, SubscriptionService } from 'service-lib';
import { BaseComponent } from '../../../core/base.component';
import { takeUntil } from 'rxjs/operators';



@Component({
  selector: 'app-renew-subscription',
  templateUrl: './renew-subscription.component.html',
  styleUrls: ['./renew-subscription.component.scss']
})
export class RenewSubscriptionComponent extends BaseComponent implements OnInit {
  companySubscription: CompanySubscription = {};
  subscriptionPackages: SubscriptionPackage[] = [];
  isSelectedPlan: Boolean = false;
  taxAmount: number = 0;
  packageUnitAmount: number = 0;
  paymentInformation: UserPaymentInfo = { totalMonths: 1 };
  ccMonthYear: string = '';
  webServerUrl: string = APIUrls.GetWebAppRootUrl;
  activationEmail: GenericEmailMessage = {};
  isProcessing: boolean = false;
  paymentComplete: boolean = false;
  
  constructor(
    private subscriptionService: SubscriptionService,
    private dataService: DataService,
    private billingService: BillingService,
    private alertService: AlertService,
    private appHtmlControl: AppHtmlControlService,
    private authService: AuthService,
    private agencyService: CompanyBusinessService,
    private helperService: HelperService,
    public dialogRef: MatDialogRef<RenewSubscriptionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) { 
    super();
    this.paymentInformation.totalMonths = 1;
  }


  ngOnInit(): void {
    this.subscriptionPackages = this.subscriptionService.getSubscriptionPackages();
    this.calculateTotalPkgAmount();
      this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  getSubscriptionPackagePrice(pkgName: string) {
    return this.subscriptionService.getSubscriptionPackagePrice(pkgName);
  }

  selectSubscriptionPackage(pkgName: string) {    
    if (!!pkgName) {
      let _package = this.subscriptionPackages.filter(
        x => x.packageName.toLowerCase() == pkgName.toLowerCase()
      );
      if (_package.length > 0) {
        this.companySubscription.packageId = _package[0].packageName;
      }
    }
    this.isSelectedPlan = true;
    this.calculateTotalPkgAmount();
    }


  displayConfirmationOpenApp() {
    this.isProcessing = false;
    this.paymentComplete = true;
   }


  getPackageUnitAmount() {
    return this.subscriptionService.getSubscriptionPackagePrice(
      this.companySubscription.packageId
    );
  }

  calculateTotalPkgAmount() {
    if (this.paymentInformation.totalMonths < 1) {
      this.paymentInformation.totalMonths = 1;
    }
    this.companySubscription.totalAmount =
      this.getPackageUnitAmount() *
      this.paymentInformation.totalMonths *
      (1 + AppConstants.DefaultTaxRate);
    this.paymentInformation.totalAmount = this.companySubscription.totalAmount;
    this.companySubscription.startDate = new Date();
    let _endDate = new Date();
    let _months: number = +this.paymentInformation.totalMonths;
    if (this.getPackageUnitAmount() == 0) {
      _endDate.setMonth(this.companySubscription.startDate.getMonth() + 1);
    } else {
      _endDate.setMonth(
        this.companySubscription.startDate.getMonth() + _months
      );
    }
    this.companySubscription.endDate = _endDate;
  }

  getTaxAmount(): number {
    if (!this.companySubscription) {
      return 0;
    }
    return (
      this.getPackageUnitAmount() *
      this.paymentInformation.totalMonths *
      AppConstants.DefaultTaxRate
    );
  }

  submitForm() {
    this.submitPayment();
  }

  formatCcNumber(keyPressed: any): void {
    this.paymentInformation.cardNumber = this.appHtmlControl.formatCcNumber(
      this.paymentInformation.cardNumber
    );
  }

  showCreditCard(): boolean {
    if (
      !!this.companySubscription.packageId &&
      this.companySubscription.packageId.toLocaleLowerCase() == 'trial'
    ) {
      return false;
    } else {
      return true;
    }
  }

  submitPayment(): void {
    this.paymentInformation = this.billingService.processPayment(
      this.paymentInformation
    );
    this.alertService.displaySuccessMessage(
      AlertType.Toast,
      'Payment',
      'Processed successfully!'
    );
    this.SaveSubscription();
  }

   SaveSubscription() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    const agency = this.agencyService.getCompany();
    this.isProcessing = true;
    this.companySubscription.companyId = agency.id;
    this.companySubscription.isActive = true;
    let ret = this.dataService
      .postData(this.companySubscription, APIUrls.CompanySubscriptionsApi)
      .finally(() => {})
      .subscribe(
        data => {
          if (data != undefined) {
            this.companySubscription.id = data.id;
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              'Subscription',
              'Added successfully!'
            );
            this.agencyService.refreshView();
            if (!!agency.administratorUserId) {
              this.dbGetAdminContacts(agency.administratorUserId);
            }            
          }
        },
        error => {
          this.isProcessing = false;
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbGetAdminContacts(administratorUserId: string) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let response: EmployeeContact;
    let ret = this.dataService
      .getAllData(
        response,
        administratorUserId,
        APIUrls.EmployeeContact
      )
      .finally(() => {
       this.alertService.showSpinner(false);
        this.isProcessing = false;
      })
      .subscribe(
        (data: EmployeeContact[]) => {
          if (!!data && data.length > 0) {
            const adminEmail = this.helperService.getContactByType("Email", data).value; 
            this.SendSubscriptionReceiptEmail(adminEmail);
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  GetMessageTemplate(): string {
    const agency = this.agencyService.getCompany();
    const msg = `<div class="PlainText">Thank you for renewing your Care Connect Pro subscription.<br><br>
      Company name: ${agency.name} <br>
      Subscription Type: ${this.companySubscription.packageId} <br>
      Subscription Number: ${this.companySubscription.id} <br>
      Amount charged: $${this.companySubscription.totalAmount} <br>
      Start Date: ${this.companySubscription.startDate} <br>
      End Date: ${this.companySubscription.endDate} <br><br>
     
      <br>
      Thank you, <br>
      <br>
      Care Connect Pro Support
      <br>
      1-(800) 771-3642
      <br>
      info@careconnectpro.com
      <br>
    </div>`;
    return msg;
  }

  SendSubscriptionReceiptEmail(adminEmail: string) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let agency = this.agencyService.getCompany();
    this.activationEmail.email = adminEmail;
    this.activationEmail.msgContent = this.GetMessageTemplate();
    this.activationEmail.subject =
      'Care Connect Pro - Subscription Renewal Receipt';
    this.activationEmail.token = this.companySubscription.companyId;
    this.activationEmail.authCode = APIUrls.EmailAuthCode;

    let ret = this.dataService
      .postData(this.activationEmail, APIUrls.SendEmailApi)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (data != undefined) {
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              'Subscription renewal receipt',
              'sent successfully!'
            );
            this.closeDialog();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }




}
