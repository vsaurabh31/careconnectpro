import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { PatientService, AlertService, DataService, HelperService, AuthService } from 'service-lib';
import { Patient, PatientMedicalHistory, UserSession, AlertType, GenericIdValue, CompanyPatientMedicalHistory, APIUrls, AppMessage } from 'model-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';
import { PatientConstants } from 'model-lib';
@Component({
  selector: 'app-condition-history',
  templateUrl: './condition-history.component.html',
  styleUrls: ['./condition-history.component.scss']
})
export class ConditionHistoryComponent extends BaseComponent  implements OnInit {
  patient: Patient = {};
  conditionHistory: PatientMedicalHistory = {};
  isEditMode: boolean = false;
  conditionType: string = "";
  isProcessing: boolean = false;
  recordExistInPatient: boolean = false;
  icdCondition: boolean = false;
  medicalHistoryTypes: GenericIdValue[] = [];
  isInTakeMode: boolean = false;
  
  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<ConditionHistoryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.initData();    
    if (!!this.data.value) {
      this.conditionHistory = { ...this.data.value };
      this.isEditMode = this.data.editMode;
      if (!this.isEditMode) {
        this.conditionHistory.value = true;
        this.conditionHistory.id = Guid.create().toString();
        this.conditionHistory.medicalHistoryTypeId = PatientConstants.ConditionHistory;
      }
       this.conditionType = !!this.conditionHistory.icdId ? `${ this.conditionHistory.icdId }-${ this.conditionHistory.name }`:this.conditionHistory.name; 
       this.icdCondition = !!this.conditionHistory.icdId ? true: false;
      } 
      if (!this.icdCondition && !this.isEditMode) {
        this.conditionHistory.name = this.medicalHistoryTypes[0]?.value;
      }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data:UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
    this.patientService.companyPatientMedicalHistory$
    .pipe(takeUntil(this.destroy$))
    .subscribe(val => {
      if (val) {
        this.mapToConditionHistory(val);
      }
    });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
  }

  mapToConditionHistory(_medicalHistory: CompanyPatientMedicalHistory[]) {
    let _history: GenericIdValue[] = [];
    if (!_medicalHistory) {
      _medicalHistory = [];
    }
    _medicalHistory.sort((a,b) => a.value.localeCompare(b.value)).filter(item => item.historyType == PatientConstants.ConditionHistory).forEach(item => {      
      _history.push({id: item.id, value: item.value});
    });
    if (_history.length > 0) {
      this.medicalHistoryTypes = _history;
    }
  }


  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {
    if (!this.conditionHistory.icdId && !this.conditionHistory.name) {
      this.alertService.displayWarningMessage(AlertType.Toast, "", "Condition medical history fields are not yet setup by this agency");
      return
    }
    this.patient = this.patientService.getPatient();
    this.conditionHistory.patientId = this.patient.id;
    if (!this.patient.medicalHistory) {
      this.patient.medicalHistory = [];
    }

    if (this.isInTakeMode) {
      this.updateView();
    } else {
      if (this.isEditMode) {
        this.dbUpdateHistory();
      } else {
        if (!this.validateExistingRecord()) {
          this.dbAddHistory();
        } 

      }
    }

  }

  validateExistingRecord(): boolean {
    if (this.patient.medicalHistory.findIndex(item => item.name == this.conditionHistory.name && item.medicalHistoryTypeId == PatientConstants.ConditionHistory) > -1) {
      this.recordExistInPatient = true;
      return true;
    }
    return false;
  }


  dbAddHistory() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.conditionHistory, APIUrls.PatientMedicalHistory)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.conditionHistory.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateHistory() {
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.conditionHistory, APIUrls.PatientMedicalHistory)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView() {
    let _isSuccess = false;
    let alertMsg: string = "";
    if (!this.isEditMode) {
      if (!this.validateExistingRecord()) {
        this.patient.medicalHistory.push(this.conditionHistory); 
        _isSuccess = true;
        alertMsg = 'Condition record added!';
      } else {
        this.recordExistInPatient = true;
        return
      }
    } else {
      let _index = this.patient.medicalHistory.findIndex(item => item.id == this.conditionHistory.id);
      if (_index > - 1) {
          this.patient.medicalHistory[_index] = this.conditionHistory;
          _isSuccess = true;
          alertMsg = 'Condition record updated!';
      } else {
        this.alertService.displayErrorMessage(AlertType.Toast,'', 
        "Condition doesn't exist in patient record."); 
      }
    }
    this.patientService.updatePatient(this.patient);
    if ( _isSuccess ) {
      this.alertService.displaySuccessMessage(AlertType.Toast,'',alertMsg );
    }
    this.closeDialog();
  }



  clearRecordExistError() {
    this.recordExistInPatient = false;
  }
  
  initData() {
    this.patient = this.patientService.getPatient();
    this.conditionHistory.value = true;
    this.mapToConditionHistory(this.patientService.getCompanyPatientMedicalHistory())
  }
  
  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId){
      this.closeDialog();
    }
  }  
}
