import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyIdentificationComponent } from './agency-identification.component';

describe('AgencyIdentificationComponent', () => {
  let component: AgencyIdentificationComponent;
  let fixture: ComponentFixture<AgencyIdentificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgencyIdentificationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyIdentificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
