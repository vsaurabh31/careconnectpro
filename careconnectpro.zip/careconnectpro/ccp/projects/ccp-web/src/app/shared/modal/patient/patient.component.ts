import { Component, OnInit, Inject, ViewChild, AfterContentInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { PatientService, AlertService, DataService, HelperService, AuthService } from 'service-lib';
import { Patient, IdType, AlertType, UserSession, AppMessage, APIUrls } from 'model-lib';
import { GenderCode } from 'model-lib';
import { PeoplePlacesCodes } from 'model-lib';
import { GenericIdValue } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { Guid } from 'guid-typescript';
import { NgForm, Validators } from '@angular/forms';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.scss']
})
export class PatientComponent extends BaseComponent implements OnInit {
  patient: Patient = {};
  genders: GenericIdValue[] = PeoplePlacesCodes.GenderCodes;
  maritalStatutes: GenericIdValue[] = PeoplePlacesCodes.MaritalStatusCodes;
  patientSsn: string = "";
  isEditMode: boolean = false;
  isProcessing: boolean = false;
  isInTakeMode: boolean = false;
  patientHic: string = "";
  @ViewChild('f1') ccpForm: NgForm;
  
  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private dataService: DataService,
    private helperService: HelperService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<PatientComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this,this.validateUserSession();
    this.initData();
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data:UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });      
  }


  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {
    this.isProcessing = true;
    const ssnId: string  = Guid.create().toString();
    this.patient = this.helperService.addUpdateIdentificationByVal(ssnId, IdType.ssn, this.patientSsn, this.patient);
    const hicId: string  = Guid.create().toString();
    this.patient = this.helperService.addUpdateIdentificationByVal(hicId, IdType.hicn, this.patientHic, this.patient);

    if (this.isInTakeMode) {
      this.updateView();
    } else {
      if (this.isEditMode) {
        this.dbUpdatePatient();
      } else {
        this.dbAddPatient();
      }
    }
  }

  dbAddPatient() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.patient, APIUrls.Patient)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.patient.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdatePatient() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.patient, APIUrls.Patient)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView() {
      this.patientService.updatePatient(this.patient);
    this.isProcessing = false;
    this.alertService.displaySuccessMessage(AlertType.Toast, "", "Patient information updated");
    this.closeDialog();
  }



  initData() {
    this.patient = { ...this.patientService.getPatient() };
    if (!this.data.isEditMode)
    {
    this.patient.gender = "Male";
    this.patient.maritalStatus = "Single";
    } else {
      this.isEditMode = this.data.isEditMode;
    }
    const _ssnContact = this.helperService.getIdentificationByType(IdType.ssn, this.patient);
    if (!!_ssnContact) {
      this.patientSsn = _ssnContact.value;
    }
    const _hicNumber = this.helperService.getIdentificationByType(IdType.hicn, this.patient);
    if (!!_hicNumber) {
      this.patientHic = _hicNumber.value;
    }
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId){
      this.closeDialog();
    }
  }
}
