import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { PatientService, AlertService, DataService, HelperService, AuthService } from 'service-lib';
import { StateUS, Address, MedicalProvider, ContactType, AddressCodes, AlertType, APIUrls, PatientReferralProvider, AppMessage, UserSession, PeoplePlacesCodes, Patient, IdType } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { Router } from '@angular/router';

@Component({
  selector: 'app-medical-provider',
  templateUrl: './medical-provider.component.html',
  styleUrls: ['./medical-provider.component.scss']
})
export class MedicalProviderComponent extends BaseComponent implements OnInit {
  provider: MedicalProvider = {};
  providerPhone: string;
  providerFax: string = "";
  providerNpi: string = "";
  providerAddress: Address = {};
  isPrimary: boolean = true;
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  usStates: StateUS[] = [];
  isInTakeMode: boolean = false;
  isAdminMode: boolean = false;
  
  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private dataService: DataService,
    private helperService: HelperService,
    private authService: AuthService,
    private router: Router,
    public dialogRef: MatDialogRef<MedicalProviderComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super()
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.isAdminMode) {
      this.isAdminMode = this.data.isAdminMode;
    }

    if (!!this.data.value) {
      this.isEditMode = true;
      this.provider = { ...this.data.value };
      this.providerAddress = this.helperService.getPrimaryAddress(this.provider);
      const phone =  this.helperService.getContactByType(PeoplePlacesCodes.ContactWorkPhone, this.provider.contacts);
      const fax = this.helperService.getContactByType(PeoplePlacesCodes.ContactFax, this.provider.contacts);
      const _npi = this.helperService.getIdentificationByType(IdType.npi, this.provider);
      if (!!phone) {
        this.providerPhone = phone.value;
      }
      if (!!fax) {
        this.providerFax = fax.value;
      }
      if (!!_npi) {
        this.providerNpi = _npi.value;
      }
      this.getStateForEdit();
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data:UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });

    if(!this.isAdminMode) {
      const patient = this.patientService.getPatient();
      const refProvider = patient.referralProviders.find(item => item.providerId == this.provider.id);
      if (!!refProvider) {
        this.isPrimary = !!refProvider.isPrimary? true: false;
      }
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
    }
  }

  getStateForEdit() {
    if (this.usStates.findIndex(item => item.id == this.providerAddress.state) < 0) {
      const alternateState = this.usStates.find(item => item.value == this.providerAddress.state);
      if (!!alternateState) {
        this.providerAddress.state = alternateState.id;
      }
    }
  }

  initData() {
    this.usStates = AddressCodes.USStates.map((item) => { return item });
    this.providerAddress.state = this.usStates[0].id;
  }

  closeDialog(refreshView?: boolean, returnThirdParty?: boolean): void {
    if ( this.isAdminMode && returnThirdParty) {
      this.router.navigateByUrl(`thirdparty/medicalprovider/detail/${this.provider.id}`);
      this.dialogRef.close(refreshView);   
    } else {
      this.dialogRef.close(refreshView); 
    }   
  }

  submitForm() {
    let patient = this.patientService.getPatient();
    if (!!this.data.returnData) {
      this.addProviderDatabase();  
      return
    }
    
    if (this.isInTakeMode) {
      if (this.isEditMode) {
        if (!this.isAdminMode) {
          this.updateView(patient);
        } else {
          this.updateProviderDatabase();
        } 
      } else {
        this.addProviderDatabase();
      }
    } else {
      if (this.isEditMode) {
        if (!this.isAdminMode) {
        this.dbUpdateReferralProvider(patient);
        } else {
          this.updateProviderDatabase();
        }
      } else {
        this.addProviderDatabase();
      }
    }
  }

  dbAddReferralProvider(patient: Patient, refProvider: PatientReferralProvider) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(refProvider, APIUrls.PatientReferralProvider)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.provider.id = data;
          }
          patient.referralProviders.push(refProvider);
          this.patientService.updatePatient(patient);             
          this.closeDialog();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateReferralProvider(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.provider, APIUrls.PatientReferralProvider)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView(patient: Patient) {
    if (this.isEditMode) {
      let idx = patient.referralProviders.findIndex(item => item.providerId == this.provider.id);
      this.patientService.updatePatient(patient);
      this.alertService.displaySuccessMessage(
        AlertType.Toast,
        '',
        'Medical provider record updated!'
      );
      this.closeDialog();
    } else {
      this.addProviderDatabase();
    }
  }


  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId){
      this.closeDialog();
    }
  }

  getProviderContactIdent() {
    const currentUser = this.authService.getUserLoggedIn(); 
    this.provider.companyId = currentUser.companyId;
    this.provider.longName = this.provider.name;
    this.provider.lastUpdatedUserId = currentUser.employeeId;
    this.providerAddress.isPrimary = true;
    this.providerAddress.country = "US";
    this.providerAddress.lastUpdatedUserId = currentUser.employeeId;
    this.provider = this.helperService.addUpdateAddress(this.providerAddress, this.provider);
    this.provider = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactWorkPhone, this.providerPhone, this.provider);
    this.provider = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactFax, this.providerFax, this.provider);
    this.provider = this.helperService.addUpdateIdentificationByVal("", IdType.npi, this.providerNpi, this.provider);
  }


  updateProviderDatabase() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.getProviderContactIdent();
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.provider, APIUrls.MedicalProvider)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              '',
              'Medical provider record updated successfully!!'
            );
            this.closeDialog(true);
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.ErrorUpdateDatabaseRecordFailed
            );
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  addProviderDatabase(){  
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.getProviderContactIdent();
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.provider, APIUrls.MedicalProvider)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.provider.id = data;
            if (!this.isAdminMode) {
              let patient = this.patientService.getPatient();
              let refProvider: PatientReferralProvider = {providerId: data};
              if (!patient.referralProviders) {
                patient.referralProviders = [];
              }
              if (this.isInTakeMode) {
                patient.referralProviders.push(refProvider);
                this.patientService.updatePatient(patient);             
                this.dialogRef.close(this.provider);
              } else {
                refProvider.patientId = patient.id;
                this.dbAddReferralProvider(patient, refProvider);
              } 
            } else {
              this.alertService.displaySuccessMessage(
                AlertType.Toast,
                '',
                'Medical provider added to patient record!'
              );
              this.closeDialog(true, true);
            }           
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.ErrorUpdateDatabaseRecordFailed
            );
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


}
