import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from './../core/base.component';
import { BroadcastMessageComponent } from '../../shared/modal/broadcast-message/broadcast-message.component';
import {
  AuthService,
  MediaService,
  AlertService,
  DataService,
  CareConnectLocalStorage,
  PatientService,
  NotificationsService,
  AppHtmlControlService,
} from 'service-lib';
import { UserSession, APIUrls, PatientSearchKeys, SystemBroadcastDetail, AppChatDetail, AppMessageDetail, GenericSearch } from 'model-lib';
import { AlertType } from 'model-lib';
import { AppMessage } from 'model-lib';
import { Router } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.scss']
})
export class NavbarComponent extends BaseComponent implements OnInit {
  menubarActive: boolean = false;
  activeUser: UserSession;
  userImage: string;
  userImageAltText: string = '';
  isProcessing: boolean = false;
  patientSearch: GenericSearch = {};
  broadcastMsgs: SystemBroadcastDetail[] = [];
  chatMessages: AppChatDetail[] = [];
  inboxMessages: AppMessageDetail[] = [];
  totalMessages: number = 0;

  constructor(
    private router: Router,
    private authService: AuthService,
    private mediaSvc: MediaService,
    private alertService: AlertService,
    private dataService: DataService,
    private patientService: PatientService,
    private localStore: CareConnectLocalStorage,
    private notifyService: NotificationsService,
    public dialog: MatDialog
  ) {
    super();
  }

  ngOnInit(): void {
    this.getUserInfo();
    this.notifyService.systemBroadcastMessages$.pipe(takeUntil(this.destroy$))
      .subscribe((val: SystemBroadcastDetail[]) => {
        this.broadcastMsgs = [...val];
        this.totalMessages = this.broadcastMsgs.length + this.inboxMessages.length + this.chatMessages.length;
      })
      this.getNotificationMessages();
  }


  getNotificationMessages() {
    this.broadcastMsgs = this.notifyService.getBroadcastMsgs();
    this.chatMessages = this.notifyService.getChatMsgs();
    this.inboxMessages = this.notifyService.getInboxMsgs();
    this.totalMessages = this.broadcastMsgs.length + this.inboxMessages.length + this.chatMessages.length;
  }

  openInboxMsg() { }

  openChatMsg() { }

  openBroadcastMsg() {
    this.broadcastMsgs.sort((a,b) => { return +new Date(a.dateCreated) - +new Date(b.dateCreated)});
    const dialogRef = this.dialog.open(BroadcastMessageComponent, {
      data: this.broadcastMsgs[0],
    });    
   }

  toggle() {
    this.menubarActive = !this.menubarActive;
  }

  logout() {
    this.authService.logout();
  }
  goProfile() {
    this.router.navigateByUrl('profile');
  }

  searchPatient() {
    this.patientSearch.searchFilter = "name";
    this.patientService.setSearchKeyword(this.patientSearch);
    this.patientService.updateTriggerHeaderSearch(true);
    this.router.navigateByUrl('patient/manage');
  }

  openAgencySetting() {
    this.router.navigateByUrl('options/agency');
  }

  getUserInfo() {
    const authToken = this.localStore.getAuthToken();
    if (!authToken) {
      this.authService.logout();
    }
    this.activeUser = this.authService.getUserLoggedIn();
    if (!!authToken && !this.activeUser) {
      this.getLoggedInUserInfo();
    } else {
      this.setupUserImage();
    }
  }

  setupUserImage() {
    if (
      !!this.activeUser &&
      this.activeUser.employeePhotoName != undefined &&
      this.activeUser.employeePhotoName != null &&
      this.activeUser.employeePhotoName != ''
    ) {
      this.userImage =
        APIUrls.GetImageEmployee + '/' + this.activeUser.employeePhotoName;

      this.userImageAltText = this.activeUser.fullName + 'profile pic';
    } else {
      this.userImage = this.mediaSvc.defaultUserImage;
    }
  }

  getLoggedInUserInfo() {
    this.isProcessing = true;
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let request: UserSession;
    let ret = this.dataService
      .getSingleData(request, "", APIUrls.GetUserSignedInInfo)
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (data) => {
          const response: UserSession = data;
          if ((!!response) && (!!response.companyId)) {
            this.authService.setUserLoggedIn(response);
            this.activeUser = response;
            this.setupUserImage();
          } else {
            this.alertService.displayErrorMessage(AlertType.Dialog, AppMessage.SessionExpiredHeaderText, AppMessage.SessionExpiredHeaderText + ". " + AppMessage.SessionExpiredBodyText);
            this.authService.logout();
          }
        },
        (error) => {
          this.authService.logout();
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
