import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shared.spinner',
  templateUrl: './shared.spinner.component.html'
})
export class SharedSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
