import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../core/base.component';
import { PatientMedicalInsurance, UserSession, AlertType, MedicalInsuranceProvider, APIUrls, AppMessage, Patient } from 'model-lib';
import { DataService, PatientService, AlertService, HelperService, AuthService } from 'service-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';
import { MedicalInsuranceProviderSearchComponent } from '../medical-insurance-provider/medical-insurance-provider-search.component';

@Component({
  selector: 'app-insurance',
  templateUrl: './private-insurance.component.html',
  styleUrls: ['./private-insurance.component.scss']
})

export class PrivateInsuranceComponent extends BaseComponent implements OnInit {
  privateInsurance: PatientMedicalInsurance = {};
  insProviderName: string = "";
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  recordExistInPatient: boolean = false;
  isMissingProvider: boolean = false;
  isInTakeMode: boolean = false;

  constructor(
    private dataService: DataService,
    private patientService: PatientService,
    private alertService: AlertService,
    private helperService: HelperService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<PrivateInsuranceComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public dialog: MatDialog
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.privateInsurance = { ...this.data.value };
      if (!!this.privateInsurance.insuranceProviderId) {
        this.getProviderDetail(this.privateInsurance.insuranceProviderId);
      }
    } else {
      this.privateInsurance.id = Guid.create().toString();
    }

    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
  }

  initData() {
    this.privateInsurance.rx = false;
  }


  closeDialog(): void {
    this.dialogRef.close();
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  lookupPcp() {
  }

  submitForm() {
    this.isMissingProvider = false;
    let patient = this.patientService.getPatient();
    if (!patient.privateInsurance) {
      patient.privateInsurance = [];
    }

    this.privateInsurance.patientId = patient.id;
    if (!this.preProcessSubmit()) {
      return;
    };
    if (this.isInTakeMode) {
      this.updateView(patient);
    } else {
      if (this.isEditMode) {
        this.dbUpdateInsurance(patient);
      } else {
        this.dbAddInsurance(patient);
      }
    }
  }


  dbAddInsurance(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.privateInsurance, APIUrls.PatientPrivateInsurance)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.privateInsurance.id = data;
          }
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateInsurance(patient: Patient) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.privateInsurance, APIUrls.PatientPrivateInsurance)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView(patient);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView(patient: Patient) {
    let displayInfoAlert: boolean = true;
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = 'Private medical insurance data record updated!';
      let idx = patient.privateInsurance.findIndex(item => item.id == this.privateInsurance.id);
      patient.privateInsurance[idx] = this.privateInsurance;
    } else {
      if (patient.privateInsurance.findIndex(item => item.insuranceProviderId == this.privateInsurance.insuranceProviderId) < 0) {
        patient.privateInsurance.push(this.privateInsurance);
        alertMsg = 'Private medical insurance data record added!';
      } else {
        this.recordExistInPatient = true;
        return
      }
    }
    this.patientService.updatePatient(patient);
    if (displayInfoAlert) {
      this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    } else {
      this.alertService.displayWarningMessage(AlertType.Toast, '', alertMsg);
    }
    this.closeDialog();
  }


  preProcessSubmit() {
    if (!this.privateInsurance.insuranceProviderId) {
      this.isMissingProvider = true;
      return false;
    }
    return true;
  }


  openSearchMedInsuranceDialog(): void {
    const dialogRef = this.dialog.open(MedicalInsuranceProviderSearchComponent, {
      data: { name: 'Lookup Medical Insurance Provider', returnData: true },
    });
    dialogRef.afterClosed().subscribe((result: MedicalInsuranceProvider) => {
      if (!!result) {
        this.insProviderName = result.name;
        this.privateInsurance.insuranceProviderId = result.id;
      }
    });
  }

  getProviderDetail(providerId: string) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const _provider: MedicalInsuranceProvider = {};
    let ret = this.dataService
      .getSingleData(_provider, providerId, APIUrls.InsuranceProvider)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: MedicalInsuranceProvider = data;
          if (!!response) {
            this.insProviderName = response.name;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  getPatientInfo() {
    const _patient = this.patientService.getPatient();
    const prefix = !!_patient.prefix ? _patient.prefix : "";
    const middleName = !!_patient.middleName ? _patient.middleName : "";
    const suffix = !!_patient.suffix ? _patient.suffix : "";
    if (!_patient.lastName) {
      this.alertService.displayWarningMessage(AlertType.Toast, "", "Patient information is not yet available");
      return;
    }
    this.privateInsurance.subscriberName = `${prefix} ${_patient.firstName} ${middleName} ${_patient.lastName} ${suffix}`;
  }
}
