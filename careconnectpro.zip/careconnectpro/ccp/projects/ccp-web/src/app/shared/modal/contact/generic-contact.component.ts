import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { GenericIdValue, PeoplePlacesCodes, AlertType, UserSession } from 'model-lib';
import { AlertService, HelperService, AuthService, DataService } from 'service-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-generic-contact',
  templateUrl: './generic-contact.component.html',
  styleUrls: ['./generic-contact.component.scss']
})
export class GenericContactComponent extends BaseComponent implements OnInit {

  contactTypes: GenericIdValue[] = PeoplePlacesCodes.ContactTypes;
  contact: any = {};
  contacts: any[] = [];
  selectedContactType: string = "";
  entity: any = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  apiAddUrl: string = "";
  apiUpdateUrl: string = "";
  updateDatabase: boolean = true;
  entityName: string = "Record";
  recordExistInEntity: boolean = false;

  constructor(
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<GenericContactComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();

    if (!!this.data.contacts) {
      this.contacts = this.data.contacts;
    }

    this.apiAddUrl = this.data.apiAddUrl;
    this.apiUpdateUrl = this.data.apiUpdateUrl;
    this.updateDatabase = this.data.updateDatabase;
    this.contact = { ...this.data.value };

    if (!!this.data.entityName) {
      this.entityName = this.data.entityName;
    }

    if (!!this.contact.id) {
      this.isEditMode = true;
      this.getContactForEdit();
    } else {
      this.contact.id = Guid.create().toString();
      if (this.contactTypes.length > 0) {
        this.selectedContactType = this.contactTypes[0].id;
      }
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  clearRecordExistError() {
    this.recordExistInEntity = false;
  }

  getContactForEdit() {
    this.selectedContactType = this.contact.contactTypeId.toString();
  }

  closeDialog(): void {
    this.dialogRef.close(this.contact);
  }

  initData() {
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  submitForm() {
    this.contact.contactTypeId = this.selectedContactType;
   
    if (!this.updateDatabase) {
      this.closeDialog();
    } else {
      if (this.isEditMode) {
        this.dbUpdateContact();
      } else {
        if (!this.validateExistingRecord()) {
          this.dbAddContact();
        }        
      }
    }
  }

  validateExistingRecord(): boolean {
    if (this.contacts.findIndex(item => item.contactTypeId == this.selectedContactType) > -1) {
      this.recordExistInEntity = true;
      return true;
    }
    return false;
  }

    dbAddContact() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.contact, this.apiAddUrl)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.contact.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateContact() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.contact, this.apiUpdateUrl)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView() {
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = `${this.entityName} contact updated!`;
    } else {
      alertMsg = `${this.entityName} contact added!`;
    }
    this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    this.closeDialog();
  }
}

