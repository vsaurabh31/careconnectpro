import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AlertType, APIUrls, Company, CompanySystemSettings, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';
@Component({
  selector: 'app-advanced',
  templateUrl: './advanced.component.html',
  styleUrls: ['./advanced.component.scss'],
})
export class AdvancedComponent extends BaseComponent implements OnInit {
  companySetting: CompanySystemSettings = {};
  isProcessing: boolean = false;
  constructor(
    private alertService: AlertService,
    private dataService: DataService,
    private agencyService: CompanyBusinessService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<AdvancedComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    if (!!this.data.value) {
      this.companySetting = { ...this.data.value };
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data: UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
  }
  closeDialog(): void {
    this.dialogRef.close();
  }

  toggleChat() {
    this.companySetting.enableChat = !this.companySetting.enableChat;
  }
  toggleMessaging() {
    this.companySetting.enableMessages = !this.companySetting.enableMessages;
  }
  toggleBroadcast() {
    this.companySetting.enableBroadcastMsgs = !this.companySetting.enableBroadcastMsgs;
  }


  saveSettings() {
    if (!!this.companySetting.id) {
      this.updateSettingsDb();
    } else {
      this.newDbSettings();
    }
  }

  newDbSettings() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const company: Company = this.agencyService.getCompany();
    this.companySetting.companyId = company.id;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.companySetting, APIUrls.CompanySettingsApi)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(AlertType.Toast, "", "Company Advanced Features Updated");
            this.agencyService.refreshView();
            this.closeDialog();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateSettingsDb() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .updateData(this.companySetting, APIUrls.CompanySettingsApi)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.alertService.displaySuccessMessage(AlertType.Toast, "", "Company Advanced Features Updated");
            this.agencyService.refreshView();
            this.closeDialog();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

}
