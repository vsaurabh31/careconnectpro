import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientGuarantorComponent } from './patient-guarantor.component';

describe('PatientGuarantorComponent', () => {
  let component: PatientGuarantorComponent;
  let fixture: ComponentFixture<PatientGuarantorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PatientGuarantorComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientGuarantorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
