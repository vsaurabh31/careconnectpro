import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Guid } from 'guid-typescript';
import { AlertType, APIUrls, Company, CompanyIdentification, GenericIdValue, IdTypeEntity, PeoplePlacesCodes, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService, HelperService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-agency-identification',
  templateUrl: './agency-identification.component.html',
  styleUrls: ['./agency-identification.component.scss']
})
export class AgencyIdentificationComponent extends BaseComponent implements OnInit {

  identificationTypes: GenericIdValue[] = PeoplePlacesCodes.AgencyIdentificationTypes;
  agencyIdentification: CompanyIdentification = {};
  selectedIdentificationType: string = "";
  agency: Company = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  recordExistInPatient: boolean = false;

  constructor(
    private agencyService: CompanyBusinessService,
    private alertService: AlertService,
    private helperService: HelperService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<AgencyIdentificationComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.agencyIdentification = { ...this.data.value };
      this.getIdentificationForEdit();
    } else {
      this.agencyIdentification.id = Guid.create().toString();
      if (this.identificationTypes.length > 0) {
        this.selectedIdentificationType = this.identificationTypes[0].id;
      }
    }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  getIdentificationForEdit() {
    this.selectedIdentificationType = this.helperService.getIdentificationIdByTypeId(this.agencyIdentification.idTypeId);
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  initData() { }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  submitForm() {
    const _session = this.authService.getUserLoggedIn();
    this.agencyIdentification.idTypeId = this.helperService.getIdentificationTypeByStringType(this.selectedIdentificationType);
    if (this.isEditMode) {
        this.dbUpdateIdentification();
      } else {
        this.agencyIdentification.companyId = _session.companyId;
        if (!this.validateExistingRecord()) {
          this.dbAddIdentification();
        }        
      }
  }

  validateExistingRecord(): boolean {
    const agency = this.agencyService.getCompany();
    const _selectedId = this.helperService.getIdentificationTypeByStringType(this.selectedIdentificationType);
    if (agency.identifications.findIndex(item => item.idTypeId == _selectedId) > -1) {
      this.recordExistInPatient = true;
      return true;
    }
    return false;
  }


  dbAddIdentification() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.agencyIdentification, APIUrls.CompanyIdentification)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.agencyIdentification.id = data;
          }
          this.agencyService.refreshView();
          this.closeDialog();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateIdentification() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.agencyIdentification, APIUrls.CompanyIdentification)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.agencyService.refreshView();
          this.closeDialog();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


}
