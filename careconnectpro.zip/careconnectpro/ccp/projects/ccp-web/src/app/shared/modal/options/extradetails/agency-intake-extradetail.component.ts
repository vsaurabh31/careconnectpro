import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { Guid } from 'guid-typescript';
import { AlertType, APIUrls, Company, CompanyExtraDetails, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, CompanyBusinessService, DataService } from 'service-lib';
import { BaseComponent } from '../../../core/base.component';

@Component({
  selector: 'app-agency-intake-extradetail',
  templateUrl: './agency-intake-extradetail.component.html',
  styleUrls: ['./agency-intake-extradetail.component.scss']
})
export class AgencyIntakeExtradetailComponent extends BaseComponent implements OnInit {
  agencyExtraDetail: CompanyExtraDetails = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  agency: Company = {};
  recordExist: boolean = false;

  constructor(
    private agencyService: CompanyBusinessService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<AgencyIntakeExtradetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }


  ngOnInit(): void {
    this.validateUserSession();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.agencyExtraDetail = { ...this.data.value };
    } else {
      this.agencyExtraDetail.id = Guid.create().toString();
      this.agencyExtraDetail.fieldType = 2; //string
      this.agencyExtraDetail.extraDetailEntityId = 1 //patient intake
    }
    this.agency = this.agencyService.getCompany();
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {
    if (this.validateExistingRecord()) {
      return;
    }
    if (this.isEditMode) {
      this.dbUpdateExtraDetail();
    } else {
      this.dbAddExtraDetail();
    }
  }

  clearRecordExistError() {
    this.recordExist = false;
  }

  validateExistingRecord(): boolean {
    const agency = this.agencyService.getCompany();
    if (!agency.extraDetails) {
      return false;
    }
    if (agency.extraDetails.findIndex(item => (item.fieldName == this.agencyExtraDetail.fieldName) && (item.id != this.agencyExtraDetail.id)) > -1) {
      this.recordExist = true;
      return true;
    }
    return false;
  }

  dbAddExtraDetail() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.agencyExtraDetail.companyId = this.agency.id;
    let ret = this.dataService
      .postData(this.agencyExtraDetail, APIUrls.CompanyExtraDetail)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.agencyExtraDetail.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateExtraDetail() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.agencyExtraDetail, APIUrls.CompanyExtraDetail)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  updateView() {
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = 'Custom intake field updated!';
    } else {
      alertMsg = 'Custom intake field added!';
    }
    this.agencyService.refreshView();
    this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    this.closeDialog();
  }

}
