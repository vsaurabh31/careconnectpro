import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { BaseComponent } from '../../../core/base.component';
import { GenericIdValue, PeoplePlacesCodes, Patient, PatientExtraDetails, AlertType, AppMessage, APIUrls, CompanyExtraDetails, UserSession } from 'model-lib';
import { PatientService, AlertService, HelperService, DataService, AuthService } from 'service-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-patient-extradetail',
  templateUrl: './patient-extradetail.component.html',
  styleUrls: ['./patient-extradetail.component.scss']
})
export class PatientExtraDetailComponent extends BaseComponent implements OnInit {
  extraDetails: GenericIdValue[] = [];
  patientExtraDetail: PatientExtraDetails = {};
  selectedExtraDetailType: string = "";
  patient: Patient = {};
  isProcessing: boolean = false;
  isEditMode: boolean = false;
  patientExtraDetailTypes: GenericIdValue[] = [];
  companyExtraDetails: CompanyExtraDetails[] = [];
  recordExistInPatient: boolean = false;
  isInTakeMode: boolean = false;

  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<PatientExtraDetailComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateUserSession();
    this.initData();
    if (!!this.data.value) {
      this.isEditMode = true;
      this.patientExtraDetail = { ...this.data.value };
    } else {
      this.patientExtraDetail.id = Guid.create().toString();
    }
    this.patientService.extraDetailsDropDown$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        if (val) {
          this.extraDetails = val;
        }
      });
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
  }


  closeDialog(): void {
    this.dialogRef.close();
  }

  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId) {
      this.closeDialog();
    }
  }

  initData() {
    this.patient = this.patientService.getPatient();
    this.extraDetails = this.patientService.getExtraDetailsDropDown();
    if (this.extraDetails.length > 0) {
      this.patientExtraDetail.extraDetailId = this.extraDetails[0].id;
    }
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  submitForm() {
    this.patient = this.patientService.getPatient();
    this.patientExtraDetail.patientId = this.patient.id;
    if (!this.patient.extraDetails) {
      this.patient.extraDetails = [];
    }

    if (this.isInTakeMode) {
      this.updateView();
    } else {
      if (this.isEditMode) {
        this.dbUpdateExtraDetail();
      } else {
        if (!this.validateExistingRecord())
        {
          this.dbAddExtraDetail();
        }        
      }
    }
  }


  dbAddExtraDetail() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.patientExtraDetail, APIUrls.PatientExtraDetail)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.patientExtraDetail.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateExtraDetail() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.patientExtraDetail, APIUrls.PatientExtraDetail)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  validateExistingRecord(): boolean {
    if (this.patient.extraDetails.findIndex(item => item.extraDetailId == this.patientExtraDetail.extraDetailId) > -1) {
      this.recordExistInPatient = true;
      return true;
    }
    return false;
  }


  updateView() {
    let displayInfoAlert: boolean = true;
    let alertMsg: string = "";
    if (this.isEditMode) {
      alertMsg = 'Patient additional data record updated!';
      let idx = this.patient.extraDetails.findIndex(item => item.id == this.patientExtraDetail.id);
      this.patient.extraDetails[idx] = this.patientExtraDetail;
    } else {
      if (!this.validateExistingRecord()) {
        this.patient.extraDetails.push(this.patientExtraDetail);
        alertMsg = 'Patient additional data record added!';
      } 
    }
    this.patientService.updatePatient(this.patient);
    if (displayInfoAlert) {
      this.alertService.displaySuccessMessage(AlertType.Toast, '', alertMsg);
    } else {
      this.alertService.displayWarningMessage(AlertType.Toast, '', alertMsg);
    }

    this.closeDialog();
  }
}
