import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MedicalInsuranceProviderComponent } from './medical-insurance-provider.component';

describe('MedicalInsuranceProviderComponent', () => {
  let component: MedicalInsuranceProviderComponent;
  let fixture: ComponentFixture<MedicalInsuranceProviderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MedicalInsuranceProviderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MedicalInsuranceProviderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
