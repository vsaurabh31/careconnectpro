import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { BaseComponent } from '../../../shared/core/base.component';
import { takeUntil } from 'rxjs/operators';
import 'rxjs/add/operator/finally';
import { UserSignup } from 'model-lib';
import { SubscriptionService } from 'service-lib';

@Component({
  selector: 'app-email-register-confirm',
  templateUrl: './email-register-confirm.component.html',
  styleUrls: ['./email-register-confirm.component.scss']
})
export class EmailRegisterConfirmComponent extends BaseComponent
  implements OnInit {
  companyRegistration: UserSignup = {};
  constructor(
    public dialogRef: MatDialogRef<EmailRegisterConfirmComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private subscriptionService: SubscriptionService
  ) {
    super();
  }

  ngOnInit(): void {
    this.companyRegistration = this.subscriptionService.getCompanyRegistration();
    this.subscriptionService.companyRegistration$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.companyRegistration = val;
      });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
}
