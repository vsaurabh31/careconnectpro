import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AlertType, APIUrls, AppAsset, AppRole, AppRolePermission, UserSession } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, SecurityService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';

@Component({
  selector: 'app-security-permission',
  templateUrl: './security-permission.component.html',
  styleUrls: ['./security-permission.component.scss'],
})
export class SecurityPermissionComponent extends BaseComponent implements OnInit {
  appRole: AppRole = {};
  userPermissions: AppRolePermission[] = [];
  isProcessing: boolean = false;
  appAssets: AppAsset[] = [];
  viewPermissionMap: { [assetId: string]: boolean; } = {};
  createPermissionMap: { [assetId: string]: boolean; } = {};
  updatePermissionMap: { [assetId: string]: boolean; } = {};
  deletePermissionMap: { [assetId: string]: boolean; } = {};

  constructor(
    private dataService: DataService,
    private alertService: AlertService,
    private securityService: SecurityService,
    private authService: AuthService,
    public dialogRef: MatDialogRef<SecurityPermissionComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }

  ngOnInit() {
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!data.companyId) {
          this.closeDialog();
        }
      });

    if (!!this.data.value) {
      this.appRole = { ...this.data.value };
      this.getDbAssets();
    } else {
      this.closeDialog();
    }
  }

  submitForm() {
    this.mapViewPermissionToUserDb();
  }

  closeDialog(): void {
    this.dialogRef.close();
  }

  getDbPermissions() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .getAllData(this.userPermissions, this.appRole.id, APIUrls.RolePermission)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          if (!!data) {
            this.userPermissions = data;
          }
          this.mapDbPermissionToView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  savePermissionToDb() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .updateData(this.userPermissions, APIUrls.RolePermission)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          this.alertService.displaySuccessMessage(AlertType.Toast, "", "Role permissions updated successfully")
          this.securityService.refreshView();
          this.closeDialog();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  mapViewPermissionToUserDb() {
    this.appAssets.forEach(assetItem => {
      const _singleIdx = this.userPermissions.findIndex(item => item.assetId == assetItem.id);
      if (_singleIdx < 0) {
        let singlePermission: AppRolePermission = {};
        singlePermission.assetId = assetItem.id;
        singlePermission.roleId = this.appRole.id;
        singlePermission.viewAsset = this.viewPermissionMap[assetItem.id];
        singlePermission.createAsset = this.createPermissionMap[assetItem.id];
        singlePermission.updateAsset = this.updatePermissionMap[assetItem.id];
        singlePermission.deleteAsset = this.deletePermissionMap[assetItem.id];
        this.userPermissions.push(singlePermission);
      } else {
        this.userPermissions[_singleIdx].viewAsset = this.viewPermissionMap[assetItem.id];
        this.userPermissions[_singleIdx].createAsset = this.createPermissionMap[assetItem.id];
        this.userPermissions[_singleIdx].updateAsset = this.updatePermissionMap[assetItem.id];
        this.userPermissions[_singleIdx].deleteAsset = this.deletePermissionMap[assetItem.id];
      }
    })
    this.savePermissionToDb();
  }

  mapDbPermissionToView() {
    this.userPermissions.forEach(item => {
      this.viewPermissionMap[item.assetId] = item.viewAsset;
      this.createPermissionMap[item.assetId] = item.createAsset;
      this.updatePermissionMap[item.assetId] = item.updateAsset;
      this.deletePermissionMap[item.assetId] = item.deleteAsset;
    })
    this.appAssets.forEach(item => {
      if (!this.viewPermissionMap[item.id]) {
        this.viewPermissionMap[item.id] = false;
      }
      if (!this.createPermissionMap[item.id]) {
        this.createPermissionMap[item.id] = false;
      }
      if (!this.updatePermissionMap[item.id]) {
        this.updatePermissionMap[item.id] = false;
      }
      if (!this.deletePermissionMap[item.id]) {
        this.deletePermissionMap[item.id] = false;
      }
    })
  }

  getDbAssets() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .getAllData(this.appAssets, "", APIUrls.RoleAsset)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          this.appAssets = data;
          this.appAssets.sort((a, b) => { return a.name.localeCompare(b.name) });
          this.getDbPermissions();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

}
