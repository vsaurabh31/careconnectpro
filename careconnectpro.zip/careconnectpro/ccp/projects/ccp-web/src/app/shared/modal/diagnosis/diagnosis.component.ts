import { Component, OnInit, Inject } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA
} from '@angular/material/dialog';
import { PatientService, AlertService, AuthService, DataService } from 'service-lib';
import { BaseComponent } from '../../core/base.component';
import { Patient, GenericIdValue, PatientDiagnosis, UserSession, CompanyPatientMedicalHistory, AlertType, PatientConstants, APIUrls, AppMessage } from 'model-lib';
import { Guid } from 'guid-typescript';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-diagnosis',
  templateUrl: './diagnosis.component.html',
  styleUrls: ['./diagnosis.component.scss']
})
export class DiagnosisComponent extends BaseComponent implements OnInit {
  patient: Patient = {};
  isEditMode: boolean = false;
  conditionType: string = "";
  isProcessing: boolean = false;
  recordExistInPatient: boolean = false;
  icdCondition: boolean = false;
  medicalHistoryTypes: GenericIdValue[] = [];
  diagnosis: PatientDiagnosis = {};
  isInTakeMode: boolean = false;

  constructor(
    private patientService: PatientService,
    private alertService: AlertService,
    private authService: AuthService,
    private dataService: DataService,
    public dialogRef: MatDialogRef<DiagnosisComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {
    super();
  }


  ngOnInit(): void {
    this.initData();    
    if (!!this.data.value) {
      this.diagnosis = { ...this.data.value };
      this.isEditMode = this.data.editMode;
      if (!this.isEditMode) {
        this.diagnosis.id = Guid.create().toString();
      }
       this.conditionType = !!this.diagnosis.icdId ? `${ this.diagnosis.icdId }-${ this.diagnosis.condition }`:this.diagnosis.condition; 
       this.icdCondition = !!this.diagnosis.icdId ? true: false;
      } 
      if (!this.icdCondition && !this.isEditMode) {
        this.diagnosis.condition = this.medicalHistoryTypes[0].value;
      }
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data:UserSession) => {
      if (!data.companyId) {
        this.closeDialog();
      }
    });
    this.patientService.companyPatientMedicalHistory$
    .pipe(takeUntil(this.destroy$))
    .subscribe(val => {
      if (val) {
        this.mapToConditionHistory(val);
      }
    });
    this.isInTakeMode = this.patientService.getInTakeMode();
    this.patientService.isInTakeModeChanged$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.isInTakeMode = val;
      });
  }

  mapToConditionHistory(_medicalHistory: CompanyPatientMedicalHistory[]) {
    let _history: GenericIdValue[] = [];
    _medicalHistory.sort((a,b) => a.value.localeCompare(b.value)).filter(item => item.historyType == PatientConstants.ConditionHistory).forEach(item => {      
      _history.push({id: item.id, value: item.value});
    });
    if (_history.length > 0) {
      this.medicalHistoryTypes = _history;
    }
  }


  closeDialog(): void {
    this.dialogRef.close();
  }

  submitForm() {
    this.patient = this.patientService.getPatient();
    this.diagnosis.patientId = this.patient.id;
    if (!this.patient.diagnosis) {
      this.patient.diagnosis = [];
    }
    if (this.isInTakeMode) {
      this.updateView();
    } else {
      if (this.isEditMode) {
        this.dbUpdateDiagnosis();
      } else {
        this.dbAddDiagnosis();
      }
    }
  }

  dbAddDiagnosis() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.diagnosis, APIUrls.PatientDiagnosis)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (!!data) {
            this.diagnosis.id = data;
          }
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbUpdateDiagnosis() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    let ret = this.dataService
      .updateData(this.diagnosis, APIUrls.PatientDiagnosis)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.updateView();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  updateView() {
    let _isSuccess = false;
    let alertMsg: string = "";
   if (!this.isEditMode) {
      if (this.patient.diagnosis.findIndex(item => item.condition == this.diagnosis.condition) < 0) {
        this.patient.diagnosis.push(this.diagnosis); 
        _isSuccess = true;
        alertMsg = 'Diagnosis record added!';
      } else {
        this.recordExistInPatient = true;
        return
      }
    } else {
      let _index = this.patient.diagnosis.findIndex(item => item.id == this.diagnosis.id);
      if (_index > - 1) {
          this.patient.diagnosis[_index] = this.diagnosis;
          _isSuccess = true;
          alertMsg = 'Diagnosis record updated!';
      } else {
        this.alertService.displayErrorMessage(AlertType.Toast,'', 
        "Diagnosis doesn't exist in patient record."); 
      }
    }
    this.patientService.updatePatient(this.patient);
    if ( _isSuccess ) {
      this.alertService.displaySuccessMessage(AlertType.Toast,'',alertMsg );
    }
    this.closeDialog();
  }


  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  initData() {
    this.patient = this.patientService.getPatient();
    this.mapToConditionHistory(this.patientService.getCompanyPatientMedicalHistory())
  }
  
  validateUserSession() {
    const _userSession: UserSession = this.authService.getUserLoggedIn();
    if (!_userSession || !_userSession.companyId){
      this.closeDialog();
    }
  } 
}
