import { Component, HostListener, OnInit } from '@angular/core';
import { DeviceDetectorService } from 'ngx-device-detector';
import { MessageService, Message } from 'primeng/api';
import { BaseComponent } from './shared/core/base.component';
import { AlertService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';
import {
  AppNotificationMessage,
  AlertSeverityType,
  WindowSize
} from 'model-lib';
import { MatDialog } from '@angular/material/dialog';
import { GenericMessageComponent } from './shared/modal/generic-message/generic-message.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [MessageService]
})
export class AppComponent extends BaseComponent implements OnInit {
  msgs: Message[] = [];
  showDialog: boolean = false;
  dialogMessageText: String = '';
  showSpinner: boolean = false;
  title = 'ccp-web';
  deviceInfo = null;
  constructor(
    private deviceService: DeviceDetectorService,
    private messageService: MessageService,
    private alertService: AlertService,
    public dialog: MatDialog
  ) {
    super();
    this.epicFunction();
    this.onResize();
  }

  ngOnInit() {
    this.alertService.appToastMessage$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.displayToastNotification(val);
      });
    this.alertService.appSystemMessage$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.displayMessageNotification(val);
      });
    this.alertService.appDialogMessage$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.dialog.open(GenericMessageComponent);
      });
    this.alertService.showSpinner$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        if (val) {
          this.showSpinner = true;
        } else {
          this.showSpinner = false;
        }
      });
  }

  epicFunction() {}

  displayDialogMessage(msg: AppNotificationMessage) {
    this.dialogMessageText = msg.detail.toString();
    this.showDialog = true;
  }

  displayMessageNotification(msg: AppNotificationMessage) {
    this.msgs = [];
    switch (msg.messageType) {
      case AlertSeverityType.Info:
        this.msgs.push({
          severity: 'info',
          summary: msg.summary.toString(),
          detail: msg.detail.toString()
        });
        break;
      case AlertSeverityType.Success:
        this.msgs.push({
          severity: 'success',
          summary: msg.summary.toString(),
          detail: msg.detail.toString()
        });
        break;
      case AlertSeverityType.Warning:
        this.msgs.push({
          severity: 'warn',
          summary: msg.summary.toString(),
          detail: msg.detail.toString()
        });
        break;
      case AlertSeverityType.Error:
        this.msgs.push({
          severity: 'error',
          summary: msg.summary.toString(),
          detail: msg.detail.toString()
        });
        break;
    }
  }

  displayToastNotification(msg: AppNotificationMessage) {
    switch (msg.messageType) {
      case AlertSeverityType.Info:
        this.messageService.add({
          key: 'tst',
          severity: 'info',
          summary: msg.summary.toString(),
          detail: msg.detail.toString()
        });
        break;
      case AlertSeverityType.Success:
        this.messageService.add({
          key: 'tst',
          severity: 'success',
          summary: msg.summary.toString(),
          detail: msg.detail.toString()
        });
        break;
      case AlertSeverityType.Warning:
        this.messageService.add({
          key: 'tst',
          severity: 'warn',
          summary: msg.summary.toString(),
          detail: msg.detail.toString()
        });
        break;
      case AlertSeverityType.Error:
        this.messageService.add({
          key: 'tst',
          severity: 'error',
          summary: msg.summary.toString(),
          detail: msg.detail.toString()
        });
        break;
    }
  }

  @HostListener('window:resize', ['$event'])
  onResize(event?) {
    let windowSize: WindowSize = {screenType: "Desktop"};
    windowSize.width = window.innerWidth;
    windowSize.height = window.innerHeight;
    if (windowSize.width >= 768) {
      windowSize.screenType = "Desktop";
    }
    if (windowSize.width < 768 ) {
      windowSize.screenType = "Mobile";
    }
    this.alertService.updateWindowSize(windowSize);
  }
}
