import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { WatchDemoComponent } from './../../shared/modal/watch-demo/watch-demo.component';
@Component({
  selector: 'app-auth-layout',
  templateUrl: './auth-layout.component.html',
  styleUrls: ['./auth-layout.component.scss']
})
export class AuthLayoutComponent implements OnInit {
  constructor(public dialog: MatDialog) {}

  ngOnInit(): void {}
  openDialog() {
    this.dialog.open(WatchDemoComponent);
  }
}
