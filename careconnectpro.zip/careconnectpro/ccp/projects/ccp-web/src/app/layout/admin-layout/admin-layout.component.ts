import { Component, OnInit, Renderer2, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AlertType, NavItem, SystemBroadcastDetail } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AppMessageService, AuthService, NotificationsService, SignalrhubService } from 'service-lib';
import { BaseComponent } from '../../shared/core/base.component';
import { BroadcastMessageComponent } from '../../shared/modal/broadcast-message/broadcast-message.component';
@Component({
  selector: 'app-admin-layout',
  templateUrl: './admin-layout.component.html',
  styleUrls: ['./admin-layout.component.scss'],
})
export class AdminLayoutComponent extends BaseComponent implements OnInit {
  showSystemAlert: boolean = false;
  systemBroadcastMsg: SystemBroadcastDetail = {};
  currentYear: number = new Date().getFullYear();
  navItems: NavItem[] = [
    {
      displayName: 'Dashboard',
      iconName: 'dashboard',
      route: 'dashboard',
    },
    {
      displayName: 'Options',
      iconName: 'settings_applications',
      route: 'options',
      children: [
        {
          displayName: 'My Agency',
          iconName: 'business',
          route: 'options/agency',
        },
        {
          displayName: 'Security',
          iconName: 'security',
          route: 'options/security',
        },
        {
          displayName: 'Personnels',
          iconName: 'people',
          route: 'options/personnels',
        },
        {
          displayName: 'Broadcast',
          iconName: 'announcement',
          route: 'options/broadcast',
        },
      ],
    },
    {
      displayName: 'Patients',
      iconName: 'supervisor_account',
      route: 'patient',
      children: [
        {
          displayName: 'Search',
          iconName: 'person_search',
          route: 'patient/manage',
        },
        {
          displayName: 'Intake',
          iconName: 'person_add',
          route: 'patient/intake',
        },
      ],
    },
    {
      displayName: 'Episode Management',
      iconName: 'format_list_numbered',
      route: 'episode',
      children: [
        {
          displayName: 'Search',
          iconName: 'search',
          route: 'episode/search',
        },
        {
          displayName: 'Add',
          iconName: 'playlist_add',
          route: 'episode/add',
        },
      ],
    },
    {
      displayName: 'Case Management',
      iconName: 'folder_shared',
      route: 'case',
      children: [
        {
          displayName: 'My Cases',
          iconName: 'view_list',
          route: 'case/mycases',
        },
      ],
    },
    {
      displayName: 'Task Management',
      iconName: 'task_alt',
      route: 'case',
      children: [
        {
          displayName: 'Agency Tasks',
          iconName: 'business',
          route: 'task/agencytasks',
        },
        {
          displayName: 'My Tasks',
          iconName: 'person',
          route: 'task/mytasks',
        }
      ],
    },
    {
      displayName: 'Billing',
      iconName: 'monetization_on',
      route: 'billing',
      children: [
        {
          displayName: 'Setup',
          iconName: 'settings',
          route: 'billing/setup',
        },
        {
          displayName: 'View History',
          iconName: 'history',
          route: 'billing/history',
        },
        {
          displayName: 'Process',
          iconName: 'play_circle_filled',
          route: 'billing/process',
        }
      ],
    },
    {
      displayName: 'Reports',
      iconName: 'assessment',
      route: 'reports',
      children: [
        {
          displayName: 'Standard Reports',
          iconName: 'timeline',
          route: 'reports/standard',
        },
        {
          displayName: 'Custom Reports',
          iconName: 'rule',
          route: 'reports/custom',
        }
      ],
    },
    {
      displayName: 'Third Party',
      iconName: 'business',
      route: 'thirdparty',
      children: [
        {
          displayName: 'Physicians',
          iconName: 'medical_services',
          route: 'thirdparty/physician',
        },
        {
          displayName: 'Insurance Providers',
          iconName: 'money',
          route: 'thirdparty/insuranceprovider',
        },
        {
          displayName: 'Medical Providers',
          iconName: 'local_hospital',
          route: 'thirdparty/medicalprovider',
        },
        {
          displayName: 'Vendors',
          iconName: 'business_center',
          route: 'thirdparty/vendor',
        }
      ],
    },
    {
      displayName: 'Calendar',
      iconName: 'calendar_today',
      route: 'calendar',
      children: [
        {
          displayName: 'Agency',
          iconName: 'business',
          route: 'calendar/company',
        },
        {
          displayName: 'Personal',
          iconName: 'perm_contact_calendar',
          route: 'calendar/personal',
        },
      ],
    },
    {
      displayName: 'Messages',
      iconName: 'chat',
      route: 'message',
      children: [
        {
          displayName: 'Chat',
          iconName: 'chat_bubble_outline',
          route: 'message/chat',
        },
        {
          displayName: 'Inbox',
          iconName: 'mail',
          route: 'message/email',
        },
        {
          displayName: 'Sent',
          iconName: 'present_to_all',
          route: 'message/email',
        },
        {
          displayName: 'Trash',
          iconName: 'delete_sweep',
          route: 'message/email',
        },
      ],
    },
  ];
  sidebarActive: boolean = false;
  constructor(private renderer: Renderer2,
    public dialog: MatDialog,
    private hubService: SignalrhubService,
    private authService: AuthService,
    private notifyService: NotificationsService
    ) {
    super();
  }

  ngOnInit(): void {
    this.renderer.removeClass(document.body, 'modal-open');
    this.initData();
  }


  toggle() {
    this.sidebarActive = !this.sidebarActive;
    if (this.sidebarActive == true) {
      this.renderer.addClass(document.body, 'modal-open');
    } else {
      this.renderer.removeClass(document.body, 'modal-open');
    }
  }

  initData() {
    this.hubService.connectSysBroadcastHub();
    this.monitorSystemBroadcasts();
  }

  monitorSystemBroadcasts() {
      this.hubService.listenSystemBroadcastMessages()
      .pipe(takeUntil(this.destroy$))
      .subscribe(broadcastMsg => {
        const userSession = this.authService.getUserLoggedIn();
        if (!!userSession && userSession.companyId == broadcastMsg.companyId) {
          this.notifyService.addBroadcastMessage(broadcastMsg);
          this.systemBroadcastMsg = broadcastMsg;
          this.showSystemAlert = true;
        }
      });
  }

  clearSystemAlert() {
    this.showSystemAlert = false;
  }

  openBroadcastMsg() {
    this.clearSystemAlert();
    this.openMesssageDetailDialog();
  }

  openMesssageDetailDialog() {
    const dialogRef = this.dialog.open(BroadcastMessageComponent, {
      data: this.systemBroadcastMsg,
    });    
  }
  
}
