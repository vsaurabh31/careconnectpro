import { Component, OnInit } from '@angular/core';
import { map, takeUntil } from 'rxjs/operators';
import { Breakpoints, BreakpointObserver } from '@angular/cdk/layout';
import { BaseComponent } from '../../shared/core/base.component';
import { AlertService, AuthService, DataService } from 'service-lib';
import { AlertType, APIUrls, DashboardMiniCardData, DashboardMonthlyIntake, DashboardMyCases, DashboardRegionalMarket, DashboardServicesByReferral, EpisodeSearchResult, GenericSearch } from 'model-lib';
import { DashboardServicesRequested } from 'projects/model-lib/src/lib/models';
import { Label } from 'ng2-charts';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent extends BaseComponent implements OnInit {
  currentYear: number = new Date().getFullYear();
  miniCardData: any[];
  isProcessing: boolean = false;
  myCases: DashboardMyCases[] = [];
  monthlyIntake: DashboardMonthlyIntake[] = [];
  regionMarket: DashboardRegionalMarket[] = [];
  servicesRequested: DashboardServicesRequested[] = [];
  referralServices: DashboardServicesByReferral[] = [];
  episodes: EpisodeSearchResult[] = [];
  episodeSearch: GenericSearch = { searchFilter: "casemanagerid" };
  isMyCasesReady: boolean = false;
  isMonthlyIntakeReady: boolean = false;
  monthlyIntakeData: number[] = [];
  monthlyIntakeDataLabel: Label[] = [];
  isRegionMarketReady: boolean = false;
  regionMarketData: number[] = [];
  regionMarketDataLabel: Label[] = [];
  isServicesRequestedReady: boolean = false;
  servicesRequestedData: number[] = [];
  servicesRequestedDataLabel: Label[] = [];
  isReferralServicesReady: boolean = false;
  physicianServicesData: number[] = [];
  providerServicesData: number[] = [];
  referralServicesDataLabel: Label[] = [];

  /** Based on the screen size, switch from standard to one column per row */
  cardLayout = this.breakpointObserver.observe(Breakpoints.Handset).pipe(
    map(({ matches }) => {
      if (matches) {
        return {
          columns: 1,
          miniCard: { cols: 1, rows: 1 },
          chart: { cols: 1, rows: 2 },
          table: { cols: 1, rows: 4 },
        };
      }

      return {
        columns: 4,
        miniCard: { cols: 1, rows: 1 },
        chart: { cols: 2, rows: 2 },
        table: { cols: 4, rows: 4 },
      };
    })
  );

  constructor(private breakpointObserver: BreakpointObserver,
    private dataService: DataService, 
    private alertService: AlertService, private authService: AuthService) {
    super();
  }

  ngOnInit() {
    this.dbGetMiniCardData();
    this.dbGetMonthlyIntakeData();
    this.dbGetRegionalMarketData();
    this.dbGetServicesByReferralData();
    this.dbGetServicesRequestedData();
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe(()  => {
      this.searchEpisode();
    });
    const _userSession = this.authService.getUserLoggedIn();
    if (!!_userSession) {
      this.searchEpisode();
    }
  }



  dbGetMiniCardData() {
    this.isProcessing = true;
    this.alertService.setDisplayExceptionAlertMsg(true);
    let response: DashboardMiniCardData;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.DashboardMiniCardData
      )
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        (data: DashboardMiniCardData[]) => {
          this.miniCardData = [...data];
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbGetMyCasesData() {
    this.isMyCasesReady = false;
    this.alertService.setDisplayExceptionAlertMsg(true);
    let response: DashboardMyCases;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.DashboardMyCases
      )
      .finally(() => {
        this.isMyCasesReady = true;
      })
      .subscribe(
        (responseData: DashboardMyCases[]) => {
          this.myCases = responseData;
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  searchEpisode() {    
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isMyCasesReady = false;
    this.isProcessing = true;
    const _userSession = this.authService.getUserLoggedIn();
    this.episodeSearch.searchKeyword = _userSession.employeeId;  
    this.episodeSearch.companyId = _userSession.companyId;
    let ret = this.dataService
      .postData(this.episodeSearch, APIUrls.SearchEpisodes)
      .finally(() => {
        this.isProcessing = false;
        this.isMyCasesReady = true;
      })
      .subscribe(
        data => {
          const response: EpisodeSearchResult[] = data;
          this.episodes = response;
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbGetMonthlyIntakeData() {
    this.isMonthlyIntakeReady = false;
    this.alertService.setDisplayExceptionAlertMsg(true);
    let response: DashboardMonthlyIntake;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.DashboardMonthlyIntake
      )
      .finally(() => {
        this.isMonthlyIntakeReady = true;
      })
      .subscribe(
        (data: DashboardMonthlyIntake[]) => {
          this.monthlyIntakeDataLabel = data.map(x => x.month);
          this.monthlyIntakeData = data.map(x => x.total);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbGetRegionalMarketData() {
    this.isRegionMarketReady = false;
    this.alertService.setDisplayExceptionAlertMsg(true);
    let response: DashboardRegionalMarket;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.DashboardRegionalMarket
      )
      .finally(() => {
        this.isRegionMarketReady = true;
      })
      .subscribe(
        (data: DashboardRegionalMarket[]) => {
          this.regionMarketDataLabel = data.map(x => x.region);
          this.regionMarketData = data.map(x => x.total);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbGetServicesByReferralData() {
    this.isReferralServicesReady = false;
    this.alertService.setDisplayExceptionAlertMsg(true);
    let response: DashboardServicesByReferral;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.DashboardServicesByReferral
      )
      .finally(() => {
        this.isReferralServicesReady = true;
      })
      .subscribe(
        (data: DashboardServicesByReferral[]) => {
          this.referralServicesDataLabel = data.map(x => x.serviceName);
          this.physicianServicesData = data.map(x => x.physician);
          this.providerServicesData = data.map(x => x.medicalProvider);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  dbGetServicesRequestedData() {
    this.isServicesRequestedReady = false;
    this.alertService.setDisplayExceptionAlertMsg(true);
    let response: DashboardServicesRequested;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.DashboardServiceRequested
      )
      .finally(() => {
        this.isServicesRequestedReady = true;
      })
      .subscribe(
        (data: DashboardServicesRequested[]) => {
          this.servicesRequestedDataLabel = data.map(x => x.serviceName);
          this.servicesRequestedData = data.map(x => x.total);
        },
        error => {          
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


}
