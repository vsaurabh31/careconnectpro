import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TaskManagementHeaderComponent } from './task-management-header.component';

describe('TaskManagementHeaderComponent', () => {
  let component: TaskManagementHeaderComponent;
  let fixture: ComponentFixture<TaskManagementHeaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TaskManagementHeaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TaskManagementHeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
