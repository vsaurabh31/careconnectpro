import { Component, Input, OnInit, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { AddressCodes, AlertType, APIUrls, AppRole, Department, Employee, EmployeeAddress, EmployeeSummary, GenericIdValue, IdType, PeoplePlacesCodes, SalaryCode, StateUS } from 'model-lib';
import { AlertService, DataService, HelperService } from 'service-lib';
import { BaseComponent } from '../../../../shared/core/base.component';

@Component({
  selector: 'app-personnel-shared',
  templateUrl: './personnel-shared.component.html',
  styleUrls: ['./personnel-shared.component.scss']
})
export class PersonnelSharedComponent extends BaseComponent implements OnInit {
@Input() isEdit: boolean;
@Input() employee: Employee;
showForm:boolean = false;
empPassword2: string = "";
employeePhone: string = "";
employeeEmail: string = "";
employeeEvv: string = "";
employeeSsn: string = "";
employeeAddress: EmployeeAddress = {};
genders: GenericIdValue[] = PeoplePlacesCodes.GenderCodes;
usStates: StateUS[] = AddressCodes.USStates;
departmentsSelect: GenericIdValue[] = [];
userRolesSelect: GenericIdValue[] = [];
supervisorsSelect: GenericIdValue[] = [];
departments: Department[] = [];
appRoles: AppRole[] = [];
employees: EmployeeSummary[] = [];
salaryCodesSelect: GenericIdValue[] = [];
salaryCodes: SalaryCode[] = [];
disablePassword2: boolean = true;
isProcessing: boolean = false;

  constructor(
    private router: Router,
    private dataService: DataService,
    private alertService: AlertService,
    private helperService: HelperService
  ) {
    super();
   }

  ngOnInit(): void {
    this.initData();
  }

  ngOnChanges(changes: SimpleChanges) {
   this.initData();
  }

  submitForm() {
    if (!this.employee.roleId || !this.employee.reportToId || !this.employee.departmentId 
      || !this.employee.roleId || !this.employee.gender || !this.employeeAddress.state 
      || !this.employee.salaryType || (!this.disablePassword2 && this.empPassword2 != this.employee.loginInfo.passwordHash)){
      return
    }

    if (this.isEdit) {
      this.dbUpdatePersonnel();
    } else {
      this.dbAddPersonnel();
    }
  }


  exitView() {
     this.router.navigateByUrl("options/personnels");
  }

  enablePassword2() {
    this.disablePassword2 = false;
  }
  

  initData() {
    if (!this.isEdit) {
      this.employee = {};
      this.employee.loginInfo = {};
      this.showForm = true;
      this. getDropDownData();
    } else {
      this.disablePassword2 =true;
      if (!this.employee.id) {
        this.employee = {};
        this.employee.loginInfo = {};    
        this.showForm = false;
      } else {
        if (!this.employee.loginInfo){
          this.employee.loginInfo = {};
        }
        this.employeeAddress = this.helperService.getPrimaryAddress(this.employee);
        this.employeeEmail = this.helperService.getContactByType(PeoplePlacesCodes.ContactEmail, this.employee.contacts)?.value;
        this.employeePhone = this.helperService.getContactByType(PeoplePlacesCodes.ContactWorkPhone, this.employee.contacts)?.value;
        this.employeeEvv = this.helperService.getIdentificationByType(IdType.evvid, this.employee)?.value;
        this.employeeSsn = this.helperService.getIdentificationByType(IdType.ssn, this.employee)?.value;
        this.showForm = true;
        this. getDropDownData();
      }
    }

  }

  getDropDownData() {
    this.getAllEmployees();
    this.getAllDepartments();
    this.getAllRoles();
    this.getSalaryCodes();
  }

  populateDeptDropDown() {
    let x: any = this.departments;
    let y: any = x.sort(function(a: any, b: any) {
      return a.name > b.name ? 1 : b.name > a.name ? -1 : 0;
    });
    let z: any = y.map(function(dept: any) {
      return {
        label: dept.name,
        value: dept.id
      };
    });
    this.departmentsSelect = z;
  }

  populateRolesDropDown() {
    let x: any = this.appRoles;
    let y: any = x.sort(function(a: any, b: any) {
      return a.name > b.name ? 1 : b.name > a.name ? -1 : 0;
    });
    let z: any = y.map(function(role: any) {
      return {
        label: role.name,
        value: role.id
      };
    });
    this.userRolesSelect = z;
  }

  populateReportToDropDown() {
    let x: any = this.employees;
    let y: any = x.sort(function(a: any, b: any) {
      return a.lastName > b.lastName ? 1 : b.lastName > a.lastName ? -1 : 0;
    });
    let z: any = y.map(function(employee: any) {
      return {
        label: employee.lastName + "," + employee.firstName,
        value: employee.employeeId
      };
    });
    this.supervisorsSelect = z;
  }

  populateSalaryDropDown() {
    let x: any = this.salaryCodes;
    let y: any = x.sort(function(a: any, b: any) {
      return a.id > b.id ? 1 : b.id > a.id ? -1 : 0;
    });
    let z: any = y.map(function(salary: any) {
      return {
        label: salary.id,
        value: salary.id
      };
    });
    this.salaryCodesSelect = z;
  }


  getAllEmployees() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: EmployeeSummary;
    let ret = this.dataService.getAllData(response, "", APIUrls.EmployeeGetAllEmployeesSummary)
    .finally(() => {
      this.alertService.showSpinner(false);
    })
    .subscribe(
      data => {
        if (data != undefined) {
          let ret: EmployeeSummary[] = data;
          this.employees = ret;
          this.populateReportToDropDown();
        }
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
  }

  getSalaryCodes() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: SalaryCode;
    let ret = this.dataService.getAllData(response, "", APIUrls.CodesGetSalaryCodes)
    .finally(() => {
      this.alertService.showSpinner(false);
    })
    .subscribe(
      data => {
        if (data != undefined) {
          let ret: SalaryCode[] = data;
          this.salaryCodes = ret;
          this.populateSalaryDropDown();
        }
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
  }


  getAllDepartments() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: Department;
    let ret = this.dataService.getAllData(response, "", APIUrls.CompanyDepartmentsApi)
    .finally(() => {
      this.alertService.showSpinner(false);
    })
    .subscribe(
      data => {
        if (data != undefined) {
          let ret: Department[] = data;
          this.departments = ret;
          this.populateDeptDropDown();
        }
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
  }


  getAllRoles() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    const _roles: AppRole[] = [];
    let ret = this.dataService.getAllData(_roles, "", APIUrls.CompanyRole)
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (data: any) => {
          let ret: AppRole[] = data;
          this.appRoles = ret;
          this.  populateRolesDropDown();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbAddPersonnel() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.employee.addresses = [];
    this.getEmployeeChildData();
    this.employee.loginInfo.email = this.employeeEmail;
    this.employee.loginInfo.phoneNumber = this.employeePhone;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(
        this.employee,
        APIUrls.Employee
      )
      .finally(() => {
       this.alertService.showSpinner(false);
       this.isProcessing = false;
      })
      .subscribe(
        (data: Employee) => {
          if (!!data) {
              this.alertService.displaySuccessMessage(AlertType.Toast, "", "Personnel record created successfully");
              this.exitView();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  getEmployeeChildData() {
    this.employeeAddress.isPrimary = true;
    this.employee = this.helperService.addUpdateAddress(this.employeeAddress, this.employee);
    this.employee = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactWorkPhone, this.employeePhone, this.employee);
    this.employee = this.helperService.addUpdateContactByVal("", PeoplePlacesCodes.ContactEmail, this.employeeEmail, this.employee);
    this.employee = this.helperService.addUpdateIdentificationByVal("", IdType.ssn, this.employeeSsn, this.employee);
    this.employee = this.helperService.addUpdateIdentificationByVal("", IdType.evvid, this.employeeEvv, this.employee);
  }

  
  dbUpdatePersonnel() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.getEmployeeChildData();
    if (!this.disablePassword2) {
      this.employee.loginInfo.isPasswordChanged = true;
    }

    this.alertService.showSpinner(true);
    let ret = this.dataService
      .updateData(
        this.employee,
        APIUrls.Employee
      )
      .finally(() => {
       this.alertService.showSpinner(false);
       this.isProcessing = false;
      })
      .subscribe(
        (data: Employee) => {
          if (!!data) {
              this.alertService.displaySuccessMessage(AlertType.Toast, "", "Personnel record updated successfully");
              this.exitView();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
