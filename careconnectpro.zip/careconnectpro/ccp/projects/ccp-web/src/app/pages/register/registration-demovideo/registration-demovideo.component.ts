import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-registration-demovideo',
  templateUrl: './registration-demovideo.component.html',
  styleUrls: ['./registration-demovideo.component.scss']
})
export class RegistrationDemovideoComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit(): void {}
  stageChange(event: number) {
    switch (event) {
      case 1:
        this.router.navigateByUrl('landing/register/subscribe2');
        break;
      case 2:
        this.router.navigateByUrl('landing/register/demo');
        break;
    }
  }
}
