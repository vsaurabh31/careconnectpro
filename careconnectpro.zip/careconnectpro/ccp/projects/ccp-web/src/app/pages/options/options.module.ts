import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from './../../shared/shared.module';
import { OptionsComponent } from './options.component';
import { BroadcastComponent } from './broadcast/broadcast.component';
import { PersonnelsComponent } from './personnels/personnels.component';
import { PersonnelEditComponent } from './personnels/edit/personnel-edit.component';
import { SecurityComponent } from './security/security.component';
import { AgencyComponent } from './agency/agency.component';
import { AgencyBasicInfoComponent } from './agency/pages/basic-info/agency-basic-info.component';
import { AgencyDepartmentComponent } from './agency/pages/department/agency-department.component';
import { AgencyPatientExtraDetailsComponent } from './agency/pages/extra-details/agency-patient-extra-details.component';
import { AgencyLocationsComponent } from './agency/pages/location/agency-locations.component';
import { AgencyServicesComponent } from './agency/pages/services/agency-services.component';
import { AgencySettingsComponent } from './agency/pages/settings/agency-settings.component';
import { AgencySubscriptionsComponent } from './agency/pages/subscription/agency-subscriptions.component';
import { SharedSpinnerComponent } from './../../shared/spinner/shared.spinner.component';
import { RenewSubscriptionComponent } from '../../shared/modal/options/renew/renew-subscription.component';
import { MedicalHistoryComponent } from './agency/pages/medical-history/medical-history.component';
import { PersonnelSharedComponent } from './personnels/shared/personnel-shared.component';
import { PersonnelAddComponent } from './personnels/add/personnel-add.component';
import { LocationContactIdentificationComponent } from './agency/pages/loc-contact-ident/location-contact-identification.component';

export const routes: Routes = [
  {
    path: '',
    component: OptionsComponent,
    children: [
      { path: 'broadcast', component: BroadcastComponent },
      { path: 'personnels', component: PersonnelsComponent },
      { path: 'personnels/edit/:id', component: PersonnelEditComponent },
      { path: 'personnels/new', component: PersonnelAddComponent },
      { path: 'security', component: SecurityComponent },
      { path: 'agency', component: AgencyComponent },
    ],
  },
];

@NgModule({
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
  declarations: [
    OptionsComponent,
    BroadcastComponent,
    PersonnelsComponent,
    PersonnelEditComponent,
    SecurityComponent,
    AgencyComponent,
    AgencyBasicInfoComponent,
    AgencyDepartmentComponent,
    AgencyPatientExtraDetailsComponent,
    AgencyLocationsComponent,
    AgencyServicesComponent,
    AgencySettingsComponent,
    AgencySubscriptionsComponent,
    SharedSpinnerComponent,
    RenewSubscriptionComponent,
     MedicalHistoryComponent,
     PersonnelSharedComponent,
     PersonnelAddComponent,
     LocationContactIdentificationComponent 
  ],
})
export class OptionsModule {}
