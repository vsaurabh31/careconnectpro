import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../../shared/shared.module';
import { EpisodeSearchComponent } from './search/episode-search.component';
import { EpisodeAddComponent } from './add/episode-add.component';
import { RouterModule, Routes } from '@angular/router';
import { EpisodeComponent } from './episode.component';
import { EpisodeHeaderComponent } from './pages/header/episode-header.component';
import { EpisodeDashboardComponent } from './pages/dashboard/episode-dashboard.component';
import { EpisodeTaskComponent } from './pages/task/episode-task.component';
import { EpisodeScheduleComponent } from './pages/schedule/episode-schedule.component';
import { EpisodeDocumentComponent } from './pages/documents/episode-document.component';
import { EpisodeDetailComponent } from './detail/episode-detail.component';
import { EpisodeVisitComponent } from './modal/visit/episode-visit.component';
import { EpisodeCaseManagerComponent } from './modal/case-manager/episode-case-manager.component';

import { FormsModule } from '@angular/forms';
import { FlatpickrModule } from 'angularx-flatpickr';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { EpisodeVisitListComponent } from './modal/visit/episode-visit-list.component';
import { EquipmentSuppliesComponent } from './pages/equipment-supplies/equipment-supplies.component';


export const routes: Routes = [
  {
    path: '',
    component: EpisodeComponent,
    children: [
      { path: 'search', component: EpisodeSearchComponent },
      { path: 'add', component: EpisodeAddComponent },
      { path: 'add/:id', component: EpisodeAddComponent },
      { path: 'detail/:id', component: EpisodeDetailComponent }
    ]
  }
];

@NgModule({
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes),
  FormsModule,
  NgbModalModule,
  FlatpickrModule.forRoot(),
  CalendarModule.forRoot({
    provide: DateAdapter,
    useFactory: adapterFactory,
  }),
  ],
  declarations: [EpisodeSearchComponent, EpisodeAddComponent, EpisodeComponent, EpisodeHeaderComponent, EpisodeDashboardComponent, EpisodeTaskComponent, 
    EpisodeScheduleComponent,EpisodeDocumentComponent, EpisodeDetailComponent, EpisodeVisitComponent, EpisodeCaseManagerComponent, EpisodeVisitListComponent, EquipmentSuppliesComponent
    ],
})
export class EpisodeManagementModule { }
