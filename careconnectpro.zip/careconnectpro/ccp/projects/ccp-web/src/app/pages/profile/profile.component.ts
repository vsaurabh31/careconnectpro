import { Component, OnInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { EditLoginComponent } from 'projects/ccp-web/src/app/shared/modal/edit-login/edit-login.component';
import { EditAboutMeComponent } from 'projects/ccp-web/src/app/shared/modal/edit-about-me/edit-about-me.component';
import { EditPersonalComponent } from 'projects/ccp-web/src/app/shared/modal/edit-personal/edit-personal.component';
import { AlertType, APIUrls, AppMessage, AppRole, ContactType, Department, Employee, EmployeeAddress, EmployeeSummary, PeoplePlacesCodes } from 'model-lib';
import { BaseComponent } from '../../shared/core/base.component';
import { AlertService, AuthService, DataService, EmployeeService, HelperService, MediaService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent extends BaseComponent implements OnInit {
  isProcessing: boolean = false;
  fullName: string = "";
  employee: Employee = {};
  primaryAddress: EmployeeAddress = {};
  employeeEmail: string = "";
  employeePhone: string = "";
  departments: Department[] = [];
  appRoles: AppRole[] = [];
  managerName: string = "";
  constructor(public dialog: MatDialog,
    private authService: AuthService,
    private employeeService: EmployeeService,
    private mediaSvc: MediaService,
    private alertService: AlertService,
    private helperService: HelperService,
    private dataService: DataService) {
    super();
  }

  ngOnInit() {
     this.initData();
     this.employeeService.isRecordChanged$
     .pipe(takeUntil(this.destroy$))
     .subscribe(val => {
       this.initData();
     });

  }

  initData() {
    this.authService.validateResetUserSession().pipe(takeUntil(this.destroy$))
    .subscribe(data => {
      this.getDbEmployeeData();
      this.getAllDepartments();
      this.getAllRoles();
    })
 
  }

  goEditLogin() {
    const dialogRef = this.dialog.open(EditLoginComponent, {
      data: { name: 'Edit Login Information', value: this.employee.loginInfo }});
  }

  goEditPersonal() {
    this.dialog.open(EditPersonalComponent, {
      data: { name: 'Edit Personal Information', value: this.employee }});
  }

  goEditAbout() {
    this.dialog.open(EditAboutMeComponent, {
      data: { name: 'Edit About Me', value: this.employee }});
  }

  getEmployeeImg(imgName: any): any {
    let imgUrl: any;

    if (imgName != undefined && imgName != "") {
      imgUrl = APIUrls.GetImageEmployee + "/" + imgName;
    } else {
      imgUrl = this.mediaSvc.defaultUserImage;
    }
    return imgUrl;
  }

  getDbEmployeeData() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    const userSession = this.authService.getUserLoggedIn();
    if (!userSession) {
      return
    }
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let response: Employee;
    let ret = this.dataService
      .getSingleData(
        response,
        userSession.employeeId,
        APIUrls.Employee
      )
      .finally(() => {
       this.alertService.showSpinner(false);
        this.isProcessing = false;
      })
      .subscribe(
        (data: Employee) => {
          if (!!data.id) {
            this.employee = data;
            this.fullName = this.helperService.getPersonCombinedFullName(this.employee);
            this.getEmployeeContacts();
            this.getManagerDbInfo(this.employee.reportToId);
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.ProfileInfoNotAvailable);
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  getCombinedAddress() {
    return this.helperService.getCombinedAddressByAddress(this.primaryAddress);
  }

  getEmployeeContacts() {
    this.primaryAddress = this.helperService.getPrimaryAddress(this.employee); 
    this.employeePhone = this.helperService.getContactByType(PeoplePlacesCodes.ContactWorkPhone, this.employee.contacts)?.value;
    this.employeeEmail = this.helperService.getContactByType(PeoplePlacesCodes.ContactEmail, this.employee.contacts)?.value;
  }

  getManagerDbInfo(employeeId: string) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    if (!employeeId) {
      return
    }
    this.alertService.showSpinner(true);
    let response: any;
    let ret = this.dataService.getSingleData(response, employeeId, APIUrls.Employee)
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (data: any) => {
          let ret: Employee = data;
          this.managerName = this.helperService.getPersonCombinedFullName(ret);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  getDepartmentNameById(id: string) {
    let ret: string = "";
    if (this.departments) {
      let x: any = this.departments.find(x => x.id == id);
      if (x != null && x != undefined && x != "") {
        ret = x.name;
      }
    }
    return ret;
  }

  getAllDepartments() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: Department;
    let ret = this.dataService.getAllData(response, "", APIUrls.CompanyDepartmentsApi)
    .finally(() => {
      this.alertService.showSpinner(false);
    })
    .subscribe(
      data => {
        if (data != undefined) {
          let ret: Department[] = data;
          this.departments = ret;
        }
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
  }


  getAllRoles() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    const _roles: AppRole[] = [];
    let ret = this.dataService.getAllData(_roles, "", APIUrls.CompanyRole)
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (data: any) => {
          let ret: AppRole[] = data;
          this.appRoles = ret;
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  getRoleNameById(id: string) {
    let ret: string = "";
    if (this.appRoles) {
      let x: any = this.appRoles.find(x => x.id == id);
      if (x != null && x != undefined && x != "") {
        ret = x.name;
      }
    }
    return ret;
  }

}
