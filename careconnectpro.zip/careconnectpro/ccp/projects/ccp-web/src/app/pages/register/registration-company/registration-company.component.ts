import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { EmailRegisterConfirmComponent } from '../../../shared/modal/email-register-confirm/email-register-confirm.component';
import { BaseComponent } from '../../../shared/core/base.component';
import { DataService, SubscriptionService, AuthService } from 'service-lib';
import {
  UserSignup,
  MessageStatus,
  APIUrls,
  AppMessage,
  GenericEmailMessage
} from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import 'rxjs/add/operator/finally';
import { Guid } from 'guid-typescript';

@Component({
  selector: 'app-registration-company',
  templateUrl: './registration-company.component.html',
  styleUrls: ['./registration-company.component.scss']
})
export class RegistrationCompanyComponent extends BaseComponent
  implements OnInit {
  companyRegistration: UserSignup = {};
  messageStatus: MessageStatus = {};
  errorMsg = '';
  isProcessing: boolean = false;
  webServerUrl: string = APIUrls.GetWebAppRootUrl;
  activationEmail: GenericEmailMessage = {};

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private dataService: DataService,
    private subscriptionService: SubscriptionService,
    private authService: AuthService
  ) {
    super();
  }

  ngOnInit(): void {
    this.isProcessing = false;
    this.clearResetError();
    this.companyRegistration = this.subscriptionService.getCompanyRegistration();
    this.subscriptionService.companyRegistration$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.companyRegistration = val;
      });
  }

  clearResetError() {
    this.messageStatus.isSuccessful = true;
    this.errorMsg = '';
  }

  submitForm(): void {
    this.verifyExistingCompany();
  }

  verifyExistingCompany() {
    this.isProcessing = true;
    let request: any;
    let ret = this.dataService
      .getSingleData(
        request,
        this.companyRegistration.email,
        APIUrls.VerifyCompanyEmailExist
      )
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          let ret: any = data;
          if (ret != '') {
            this.messageStatus.isSuccessful = false;
            this.errorMsg = AppMessage.RegisterCompanyEmailExist;
          } else {
            this.companyRegistration.confirmToken = Guid.create().toString();
            this.saveConfirmToken();
          }
        },
        error => {
          this.messageStatus.isSuccessful = false;
          this.errorMsg = error;
        }
      );
  }

  displayConfirmationMessage() {
    this.subscriptionService.setCompanyRegistration(this.companyRegistration);
    this.dialog.open(EmailRegisterConfirmComponent);
    this.authService.logout();
  }

  saveConfirmToken() {
    this.isProcessing = true;
    let request: UserSignup = {};
    let _companyRegistration = this.subscriptionService.getCompanyRegistration();
    let ret = this.dataService
      .postData(_companyRegistration, APIUrls.AccountSaveRegistrationToken)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (data != undefined) {
            this.sendConfirmationEmail();
          } else {
            this.messageStatus.isSuccessful = false;
            this.errorMsg = AppMessage.GenericApiError;
          }
        },
        error => {
          this.messageStatus.isSuccessful = false;
          this.errorMsg = error;
        }
      );
  }

  getMessageTemplate(): string {
    const msg = `<div class="PlainText">Hello!<br><br>
      We've generated a URL to confirm your account.
      If you did not request to create a Care Connect Pro account or if you've changed your mind, simply ignore this email and nothing will happen.<br>
      In order to continue the registration process, click the following URL: <br>
      <a href="${
        this.webServerUrl
      }#/landing/register/createlogin/{{ccptoken}}" target = "_blank" rel = "noopener noreferrer" data - auth="NotApplicable">
      ${this.webServerUrl}#/landing/register/createlogin/{{ccptoken}} </a><br>
      <br>
      If clicking the URL above does not work,
      copy and paste the URL into a browser window.The URL will only be valid for a limited time and will expire.
      <br>
      <br>
      Thank you, <br>
      <br>
      Care Connect Pro Support
      <br>
      1-(800) 771-3642
      <br>
      info@careconnectpro.com
      <br>
    </div>`;
    return msg;
  }

  sendConfirmationEmail() {
    this.activationEmail.email = this.companyRegistration.email;
    this.activationEmail.msgContent = this.getMessageTemplate();
    this.activationEmail.subject = AppMessage.EmailConfirmSubject;
    this.activationEmail.token = this.companyRegistration.confirmToken;
    this.activationEmail.authCode = APIUrls.EmailAuthCode;
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.activationEmail, APIUrls.SendEmailApi)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const x: any = data;
          this.messageStatus.isSuccessful = true;
          this.displayConfirmationMessage();
        },
        error => {
          this.messageStatus.isSuccessful = false;
          this.errorMsg = error;
        }
      );
  }
}
