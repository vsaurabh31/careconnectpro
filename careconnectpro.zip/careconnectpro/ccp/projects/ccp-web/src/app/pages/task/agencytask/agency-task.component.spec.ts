import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyTaskComponent } from './agency-task.component';

describe('AgencyTaskComponent', () => {
  let component: AgencyTaskComponent;
  let fixture: ComponentFixture<AgencyTaskComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgencyTaskComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
