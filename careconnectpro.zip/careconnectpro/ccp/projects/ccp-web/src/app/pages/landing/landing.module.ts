import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { LandingComponent } from './landing.component';
import { LoginComponent } from './../login/login.component';
import { SharedModule } from './../../shared/shared.module';
export const routes: Routes = [
  {
    path: '',
    component: LandingComponent,
    children: [
      {
        path: '',
        component: LoginComponent
      },
      {
        path: 'register',
        loadChildren: () =>
          import('../register/register.module').then(m => m.RegisterModule)
      }
    ]
  }
];

@NgModule({
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
  declarations: [LandingComponent, LoginComponent]
})
export class LandingModule {}
