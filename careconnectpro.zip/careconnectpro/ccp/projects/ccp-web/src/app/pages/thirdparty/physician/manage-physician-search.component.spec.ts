import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagePhysicianSearchComponent } from './manage-physician-search.component';

describe('ManagePhysicianSearchComponent', () => {
  let component: ManagePhysicianSearchComponent;
  let fixture: ComponentFixture<ManagePhysicianSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagePhysicianSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePhysicianSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
