import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ManagePhysicianSearchComponent } from './physician/manage-physician-search.component';
import { SharedModule } from './../../shared/shared.module';
import { ThirdpartyComponent } from './thirdparty.component';
import { ManageInsuranceSearchComponent } from './insurance/manage-insurance-search.component';
import { ManageProviderSearchComponent } from './provider/manage-provider-search.component';
import { ManageVendorSearchComponent } from './vendor/manage-vendor-search.component';
import { ManageVendorDetailComponent } from './vendor/detail/manage-vendor-detail.component';
import { ManageVendorAddressComponent } from './vendor/address/manage-vendor-address.component';
import { ManageVendorContactComponent } from './vendor/contact/manage-vendor-contact.component';
import { ManageVendorIdentificationComponent } from './vendor/identification/manage-vendor-identification.component';
import { ManageVendorServicesComponent } from './vendor/services/manage-vendor-services.component';
import { VendorBasicInfoComponent } from './vendor/modal/vendor-basic-info.component';
import { VendorServiceComponent } from './vendor/modal/service/vendor-service.component';
import { ManageVendorBasicInfoComponent } from './vendor/basic-info/manage-vendor-basic-info.component';
import { ManageProviderAddressComponent } from './provider/address/manage-provider-address.component';
import { ManageProviderBasicInfoComponent } from './provider/basic-info/manage-provider-basic-info.component';
import { ManageProviderDetailComponent } from './provider/detail/manage-provider-detail.component';
import { ManageProviderIdentificationComponent } from './provider/identification/manage-provider-identification.component';
import { ManageProviderContactComponent } from './provider/contact/manage-provider-contact.component';
import { ManagePhysicianAddressComponent } from './physician/address/manage-physician-address.component';
import { ManagePhysicianBasicInfoComponent } from './physician/basic-info/manage-physician-basic-info.component';
import { ManagePhysicianContactComponent } from './physician/contact/manage-physician-contact.component';
import { ManagePhysicianDetailComponent } from './physician/detail/manage-physician-detail.component';
import { PhysicianServiceComponent } from './physician/modal/service/physician-service.component';
import { ManagePhysicianServicesComponent } from './physician/services/manage-physician-services.component';
import { ManagePhysicianIdentificationComponent } from './physician/identification/manage-physician-identification.component';
import { ManageInsuranceAddressComponent } from './insurance/address/manage-insurance-address.component';
import { ManageInsuranceBasicInfoComponent } from './insurance/basic-info/manage-insurance-basic-info.component';
import { ManageInsuranceContactComponent } from './insurance/contact/manage-insurance-contact.component';
import { ManageInsuranceDetailComponent } from './insurance/detail/manage-insurance-detail.component';
import { ManageInsuranceIdentificationComponent } from './insurance/identification/manage-insurance-identification.component';

export const routes: Routes = [
  {
    path: '',
    component: ThirdpartyComponent,
    children: [
      { path: 'insuranceprovider', component: ManageInsuranceSearchComponent },
      { path: 'insuranceprovider/detail/:id', component: ManageInsuranceDetailComponent },
      { path: 'medicalprovider', component: ManageProviderSearchComponent },
      { path: 'medicalprovider/detail/:id', component: ManageProviderDetailComponent },
      { path: 'vendor', component: ManageVendorSearchComponent },
      { path: 'vendor/detail/:id', component: ManageVendorDetailComponent },
      { path: 'physician', component: ManagePhysicianSearchComponent },
      { path: 'physician/detail/:id', component: ManagePhysicianDetailComponent }
    ]
  }
];

@NgModule({
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
  declarations: [ 
    ManagePhysicianSearchComponent,
    ThirdpartyComponent,
    ManageInsuranceSearchComponent,
    ManageProviderSearchComponent,
    ManageVendorSearchComponent,
    ManageVendorDetailComponent,
    ManageVendorAddressComponent,
    ManageVendorContactComponent,
    ManageVendorIdentificationComponent,
    ManageVendorServicesComponent,
    VendorBasicInfoComponent,
    VendorServiceComponent,
    ManageVendorBasicInfoComponent,
    ManageProviderAddressComponent,
    ManageProviderBasicInfoComponent,
    ManageProviderDetailComponent,
    ManageProviderIdentificationComponent,
    ManageProviderContactComponent,
    ManagePhysicianAddressComponent,
    ManagePhysicianBasicInfoComponent,
    ManagePhysicianContactComponent,
    ManagePhysicianDetailComponent,
    PhysicianServiceComponent,
    ManagePhysicianServicesComponent,
    ManagePhysicianIdentificationComponent,
    ManageInsuranceAddressComponent,
    ManageInsuranceBasicInfoComponent,
    ManageInsuranceContactComponent,
    ManageInsuranceDetailComponent,
    ManageInsuranceIdentificationComponent
  ]
})
export class ThirdpartyModule { }
