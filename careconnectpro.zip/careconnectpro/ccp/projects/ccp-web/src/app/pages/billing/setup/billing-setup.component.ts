import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billing-setup',
  templateUrl: './billing-setup.component.html',
  styleUrls: ['./billing-setup.component.scss']
})
export class BillingSetupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
