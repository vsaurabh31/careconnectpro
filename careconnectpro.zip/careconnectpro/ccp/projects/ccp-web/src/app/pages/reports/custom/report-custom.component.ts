import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-custom',
  templateUrl: './report-custom.component.html',
  styleUrls: ['./report-custom.component.scss']
})
export class ReportCustomComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
