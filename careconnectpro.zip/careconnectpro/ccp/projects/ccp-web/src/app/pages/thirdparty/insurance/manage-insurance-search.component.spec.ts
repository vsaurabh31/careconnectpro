import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageInsuranceSearchComponent } from './manage-insurance-search.component';

describe('ManageInsuranceSearchComponent', () => {
  let component: ManageInsuranceSearchComponent;
  let fixture: ComponentFixture<ManageInsuranceSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageInsuranceSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageInsuranceSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
