import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertType, APIUrls, EmployeeSummary, GenericSearch } from 'model-lib';
import { AlertService, DataService, HelperService, MediaService } from 'service-lib';
import { BaseComponent } from '../../../shared/core/base.component';

@Component({
  selector: 'app-personnels',
  templateUrl: './personnels.component.html',
  styleUrls: ['./personnels.component.scss'],
})
export class PersonnelsComponent extends BaseComponent implements OnInit {
  employees: EmployeeSummary[] = [];
  origData: EmployeeSummary[] = [];
  searchKeyword: string = "";

  constructor(
    private dataService: DataService,
    private alertService: AlertService,
    private mediaService: MediaService,
    private helperService: HelperService,
    private router: Router) {
    super();
  }

  ngOnInit(): void {
this.dbGetAllEmployees();
  }

  editEmployee(id: string) {
    this.router.navigateByUrl(`options/personnels/edit/${id}`);
  }

  searchUser(_keyword: any) {  
    if (!this.searchKeyword || this.searchKeyword.trim() == "") {
      this.dbGetAllEmployees();
    } else {
      this.employees = [...this.origData];
      this.employees = this.employees.filter(item => (item.prefix + item.firstName + item.middleName + item.lastName + item.suffix).toLowerCase().indexOf(this.searchKeyword) > -1);
    }
  }

  addUser() {
    this.router.navigateByUrl(`options/personnels/new`);
  }


  getCombinedFullName(_employee: EmployeeSummary) {
    return this.helperService.getPersonCombinedFullName(_employee);
  }

  getEmployeeImg(imgName: any): any {
    let imgUrl: any;

    if (imgName != undefined && imgName != "") {
      imgUrl = APIUrls.GetImageEmployee + "/" + imgName;
    } else {
      imgUrl = this.mediaService.defaultUserImage;
    }
    return imgUrl;
  }


  dbGetAllEmployees() {
    this.alertService.showSpinner(true);
    this.alertService.setDisplayExceptionAlertMsg(true);
    let response: EmployeeSummary;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.EmployeeGetAllEmployeesSummary
      )
      .finally(() => {
       this.alertService.showSpinner(false);
      })
      .subscribe(
        (data:EmployeeSummary[]) => {
          if (!!data) {
              this.employees = data;
              this.origData = [...data];
          } 
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

}
