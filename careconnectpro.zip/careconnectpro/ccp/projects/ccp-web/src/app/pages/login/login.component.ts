import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ForgotComponent } from './../../shared/modal/forgot/forgot.component';
import { BaseComponent } from './../../shared/core/base.component';
import {
  AuthService,
  AlertService,
  CareConnectLocalStorage,
  DataService,
  NotificationsService
} from 'service-lib';
import 'rxjs/add/operator/finally';
import {
  UserLogin,
  UserSession,
  MessageStatus,
  APIUrls,
  AppMessage,
  AlertType,
  BaseApiResponse
} from 'model-lib';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent extends BaseComponent implements OnInit {
  userLogin: UserLogin = {};
  isProcessing = false;
  displayWelcomeMsg: boolean = false;
  messageStatus: MessageStatus = {};
  showPassword: boolean = false;

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private alertService: AlertService,
    private dataService: DataService,
    public authService: AuthService,
    private localStore: CareConnectLocalStorage,
    public notifyService: NotificationsService
  ) {
    super();
  }

  ngOnInit(): void {
    this.authService.validateBaseUrl();
    this.initMessageStatus();
  }

  toggleShowPassword() {
    this.showPassword = !this.showPassword;
  }

  initMessageStatus() {
    this.messageStatus.isSuccessful = false;
    this.messageStatus.resultText = '';
  }

  signup(): void {
    this.router.navigateByUrl('landing/register');
  }

  forgetPasswordDialog() {
    this.dialog.open(ForgotComponent);
  }

  submitAction(isLogin: boolean) {
    if (isLogin) {
      this.login();
    } else {
      this.signup();
    }
  }

  login() {
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    const apiResponse: BaseApiResponse = {};
    this.localStore.storeAuthToken("");
    let ret = this.dataService
      .getSingleDataUsingUrlParams(apiResponse, APIUrls.AccountLoginUser, this.userLogin)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          const response: BaseApiResponse = data;
          if (response.isSucceeded) {
            this.displayWelcomeMsg = true;
            this.localStore.storeAuthToken(response.responseMessage);
            this.notifyService.clearNotificationLocalStorage();
            this.getLoggedInUserInfo();
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.LoginFailedUserOrPasswordIncorrect
            );
          }
        },
        error => {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
      );
  }

  displayDashboard() {
    let userLoggedIn = this.authService.getUserLoggedIn();
    this.router.navigateByUrl('home');
    if (this.displayWelcomeMsg) {
      this.displayWelcomeMsg = false;
      this.alertService.displayInfoMessage(
        AlertType.Toast,
        '',
        'Welcome ' + userLoggedIn.fullName
      );
    }
  }

  getLoggedInUserInfo() {
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let request: UserSession;
    let ret = this.dataService
      .getSingleData(request, "", APIUrls.GetUserSignedInInfo)
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          const response: UserSession = data;
          if (!!response) {
            this.authService.setUserLoggedIn(response);
            this.displayDashboard();
          }
        },
        error => {
          this.login();
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
      );
  }
}
