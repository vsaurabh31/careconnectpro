import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-event',
  templateUrl: './company-event.component.html',
  styleUrls: ['./company-event.component.scss']
})
export class CompanyEventComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
