import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType, APIUrls, CompanyService, Episode, GenericIdValue, 
  GenericNameSearchResult, GenericSearch, Patient, DocumentType } from 'model-lib';
import { AlertService, DataService, EpisodeService, TaskManagementService } from 'service-lib';
import { BaseComponent } from '../../../shared/core/base.component';

@Component({
  selector: 'app-episode-detail',
  templateUrl: './episode-detail.component.html',
  styleUrls: ['./episode-detail.component.scss']
})
export class EpisodeDetailComponent extends BaseComponent implements OnInit {

  isAddMode: boolean;
  patient: Patient = {};
  isProcessing: boolean;
  episodeId: string;
  episode: Episode;
  apiCallCount: number = 0;
  showDetail: boolean;
  employeeNames: Map<string, string> = new Map<string, string>();
  companyServices: Map<string, string> = new Map<string, string>();

  constructor(
    private router: Router,
    private activeRoute: ActivatedRoute,
    private dataService: DataService,
    private alertService: AlertService,
    private episodeService: EpisodeService,
    private taskManagementService: TaskManagementService
  ) { 
    super();
  }

  ngOnInit(): void {
    this.apiCallCount = 0;
    this.showDetail = false;
    this.parseUrlQuery();
  }

  parseUrlQuery() {
    this.activeRoute.params.subscribe(parms => {
      this.episodeId = parms['id'];

      if (!!this.episodeId) {
        this.dbGetEpisode();
      } else {
        this.returnEpisodeSearch();
      }
    });
  }


getSupplementaryData() {
  this.getCompanyService();
  this.getEmployeeNames();
  this.dbGetDocumentTypes();
}

getCompanyService() {
  this.alertService.setDisplayExceptionAlertMsg(true);
  this.isProcessing = true;
  const obj: CompanyService = {};
  let ret = this.dataService
    .getAllData(obj, "", APIUrls.CompanyServices)
    .finally(() => {
      this.isProcessing = false;
    })
    .subscribe(
      data => {
        const services: CompanyService[] = data;
        if (services.length > 0) {
          services.forEach( x => {
            this.companyServices.set(x.id, x.serviceName);
          })
          this.mapCompanyServicesDropDown(services);
        }
        this.apiCallCount++;
        this.displayDetail();
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
}

displayDetail() {
if(this.apiCallCount > 2) {
  this.showDetail = true;
}
}

getEmployeeNames() {
  this.alertService.setDisplayExceptionAlertMsg(true);
  this.isProcessing = true;
  const genericSearch: GenericSearch = { searchFilter: "employee", searchKeyword: "" };
  let ret = this.dataService
    .postData(genericSearch, APIUrls.SearchGenericName)
    .finally(() => {
      this.isProcessing = false;
    })
    .subscribe(
      data => {
          const response: GenericNameSearchResult[] = data;
          if (response.length > 0) {
            response.forEach( x => {
              this.employeeNames.set(x.id, x.name);
            })
            this.mapEmployeeNamesToDropDown(response);
          }
          this.apiCallCount++;
          this.displayDetail();
      },
      error => {
        if (this.alertService.getDisplayExceptionAlertMsg()) {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
        this.alertService.setDisplayExceptionAlertMsg(false);
      }
    );
}

  dbGetEpisode() {
    this.isProcessing = true;
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: Episode;
    let ret = this.dataService
      .getSingleData(
        response,
        this.episodeId,
        APIUrls.Episode
      )
      .finally(() => {
       this.alertService.showSpinner(false);
        this.isProcessing = false;
      })
      .subscribe(
        (data: Episode) => {
          if (!!data.id) {
            this.episode = data;
            this.episodeService.updateEpisode(this.episode);
            this.getSupplementaryData();
          } else {
            this.returnEpisodeSearch();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
          this.returnEpisodeSearch();
        }
      );
  }


  dbGetDocumentTypes() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const docType: DocumentType = {};
    let ret = this.dataService
      .getAllData(docType, "", APIUrls.DocumentTypes)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
            const response: DocumentType[] = data;
            if (response.length > 0) {
                this.taskManagementService.updateDocumentTypes(response);
            }
            this.apiCallCount++;
            this.displayDetail();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  returnEpisodeSearch() {
    this.alertService.displayErrorMessage(AlertType.Toast, "", "Episode record was not found");
    this.router.navigateByUrl("episode/search");
  }

  mapCompanyServicesDropDown(companyBusServices: CompanyService[]) {
    let companyServiceDropDown: GenericIdValue[] = [];
    companyBusServices.forEach(item => {
      companyServiceDropDown.push({ id: item.id, value: item.serviceName });
    });
    if (companyServiceDropDown.length > 0) {
      this.episodeService.updateServiceRequestedDropDown(companyServiceDropDown);
    }
  }

  mapEmployeeNamesToDropDown(employees: GenericNameSearchResult[]) {
    let employeeNamesDropDown: GenericIdValue[] = [];
    employees.sort((a, b) => {
      return a.name.localeCompare(b.name)
    })
    employees.forEach(item => {
      employeeNamesDropDown.push({ id: item.id, value: item.name });
    });
    if (employeeNamesDropDown.length > 0) {
      this.episodeService.updateEmployeesDropDown(employeeNamesDropDown);
    }
  }
}
