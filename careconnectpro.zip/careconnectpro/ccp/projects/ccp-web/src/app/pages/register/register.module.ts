import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { RegisterComponent } from './register.component';
import { SharedModule } from './../../shared/shared.module';
import { RegistrationCompanyComponent } from './registration-company/registration-company.component';
import { RegistrationDemovideoComponent } from './registration-demovideo/registration-demovideo.component';
import { RegistrationSelectPlanComponent } from './registration-selectplan/registration-selectplan.component';
import { RegistrationCompleteComponent } from './registration-payment/registration-payment.component';
import { CreateLoginComponent } from './create-login/create-login.component';

export const routes: Routes = [
  {
    path: '',
    component: RegisterComponent,
    children: [
      { path: '', component: RegistrationCompanyComponent },
      { path: 'createlogin/:token', component: CreateLoginComponent },
      { path: 'demo', component: RegistrationDemovideoComponent },
      { path: 'selectplan', component: RegistrationSelectPlanComponent },
      { path: 'payment', component: RegistrationCompleteComponent }
    ]
  }
];

@NgModule({
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
  declarations: [
    RegisterComponent,
    RegistrationCompanyComponent,
    RegistrationDemovideoComponent,
    RegistrationSelectPlanComponent,
    RegistrationCompleteComponent,
    CreateLoginComponent
  ]
})
export class RegisterModule {}
