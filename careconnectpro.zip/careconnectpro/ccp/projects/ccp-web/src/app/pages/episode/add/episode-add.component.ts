import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { AlertType, APIUrls, CompanyService, Episode, GenericIdValue, GenericNameSearchResult, GenericSearch, Patient } from 'model-lib';
import { AlertService, AuthService, DataService, EpisodeService } from 'service-lib';
import { BaseComponent } from '../../../shared/core/base.component';
import { ModalPatientSearchComponent } from '../../../shared/modal/patient-search/patient-search.component';

@Component({
  selector: 'app-episode-add',
  templateUrl: './episode-add.component.html',
  styleUrls: ['./episode-add.component.scss']
})
export class EpisodeAddComponent extends BaseComponent implements OnInit {
  isAddMode: boolean;
  patient: Patient = {};
  isProcessing: boolean;
  episode: Episode = {};
  showDetail: boolean;
  employeeNames: Map<string, string> = new Map<string, string>();
  companyServices: Map<string, string> = new Map<string, string>();
  apiCallCount: number = 0;

  constructor(
    private dialog: MatDialog,
    private router: Router,
    private activeRoute: ActivatedRoute,
    private dataService: DataService,
    private alertService: AlertService,
    private episodeService: EpisodeService
  ) {
    super();
  }

  ngOnInit(): void {
    this.apiCallCount = 0;
    this.parseUrlQuery();
  }

  updateEpisode() {
    this.episodeService.updateEpisode(this.episode);
  }

  parseUrlQuery() {
    this.activeRoute.params.subscribe(parms => {
      const patientId = parms['id'];
      if (!!patientId) {
        this.dbGetPatient(patientId);
      } else {
        this.openSearchPatient();
      }
    });
  }

  openSearchPatient() {
    const dialogRef = this.dialog.open(ModalPatientSearchComponent, {
      data: { name: 'Add Episode: Patient Search' },
    });
    dialogRef.afterClosed().subscribe((result) => {
      if (!result) {
        this.router.navigateByUrl("episode/search");
      } else {
        this.router.navigateByUrl(`episode/add/${result}`);
      }
    });
  }

  getSupplementaryData() {
    this.getCompanyService();
    this.getEmployeeNames();
  }

  dbGetPatient(patientId: string) {
    this.isProcessing = true;
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: Patient;
    let ret = this.dataService
      .getSingleData(
        response,
        patientId,
        APIUrls.Patient
      )
      .finally(() => {
        this.alertService.showSpinner(false);
        this.isProcessing = false;
      })
      .subscribe(
        (data: Patient) => {
          if (!!data.id) {
            this.patient = data;
            this.episode.patientId = this.patient.id;
            this.isAddMode = true;
            this.getSupplementaryData();
          } else {
            this.returnEpisodeSearch();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
          this.returnEpisodeSearch();
        }
      );
  }

  returnEpisodeSearch() {
    this.alertService.displayErrorMessage(AlertType.Toast, "", "Patient record was not found");
    this.router.navigateByUrl("episode/search");
  }

  getCompanyService() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const obj: CompanyService = {};
    let ret = this.dataService
      .getAllData(obj, "", APIUrls.CompanyServices)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const services: CompanyService[] = data;
          if (services.length > 0) {
            services.forEach(x => {
              this.companyServices.set(x.id, x.serviceName);
            })
            this.mapCompanyServicesDropDown(services);
          }
          this.apiCallCount++;
          this.displayDetail();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  displayDetail() {
    if (this.apiCallCount > 1) {
      this.showDetail = true;
      this.updateEpisode();
    }
  }

  getEmployeeNames() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const genericSearch: GenericSearch = { searchFilter: "employee", searchKeyword: "" };
    let ret = this.dataService
      .postData(genericSearch, APIUrls.SearchGenericName)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: GenericNameSearchResult[] = data;
          if (response.length > 0) {
            response.forEach(x => {
              this.employeeNames.set(x.id, x.name);
            })
            this.mapEmployeeNamesToDropDown(response); 
          }         
          this.apiCallCount++;
          
          this.displayDetail();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  mapCompanyServicesDropDown(companyBusServices: CompanyService[]) {
    let companyServiceDropDown: GenericIdValue[] = [];
    companyBusServices.forEach(item => {
      companyServiceDropDown.push({ id: item.id, value: item.serviceName });
    });
    if (companyServiceDropDown.length > 0) {
      this.episodeService.updateServiceRequestedDropDown(companyServiceDropDown);
    }
  }

  mapEmployeeNamesToDropDown(employees: GenericNameSearchResult[]) {
    let employeeNamesDropDown: GenericIdValue[] = [];
    employees.sort((a, b) => {
      return a.name.localeCompare(b.name)
    })
    employees.forEach(item => {
      employeeNamesDropDown.push({ id: item.id, value: item.name });
    });
    if (employeeNamesDropDown.length > 0) {
      this.episodeService.updateEmployeesDropDown(employeeNamesDropDown);
    }
  }

}
