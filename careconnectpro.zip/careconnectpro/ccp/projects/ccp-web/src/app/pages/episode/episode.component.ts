import { Component, OnInit } from '@angular/core';
import { AlertType, APIUrls, CompanyService, EmployeeSummary, GenericIdValue } from 'model-lib';
import { AlertService, AuthService, DataService, EpisodeService, HelperService } from 'service-lib';
import { BaseComponent } from '../../shared/core/base.component';

@Component({
  selector: 'app-episode',
  templateUrl: './episode.component.html',
  styleUrls: ['./episode.component.scss']
})
export class EpisodeComponent extends BaseComponent implements OnInit {

  isProcessing: boolean;
  
  constructor() {
    super();
   }

  ngOnInit(): void { }

  
}
