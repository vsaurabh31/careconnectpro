import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from '../../../shared/core/base.component';
import {
  MatDialog,
} from '@angular/material/dialog';
import { Address, MedicalProviderSearchResult } from 'model-lib';
import { AlertService, DataService, AppHtmlControlService } from 'service-lib';
import { APIUrls } from 'model-lib';
import { AlertType } from 'model-lib';
import { GenericSearch } from 'model-lib';
import { MatTooltip } from '@angular/material/tooltip';
import { ConfirmDeleteComponent } from '../../../shared/modal/confirm-delete/confirm-delete.component';
import { LinkedPatientsComponent } from '../../../shared/modal/linked-patients/linked-patients.component';
import { MedicalProviderComponent } from '../../../shared/modal/medical-provider/medical-provider.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-manage-provider-search',
  templateUrl: './manage-provider-search.component.html',
  styleUrls: ['./manage-provider-search.component.scss']
})
export class ManageProviderSearchComponent extends BaseComponent implements OnInit {

  providerPhone: string;
  providerFax: string = "";
  providerAddress: Address = {};
  isPrimary: boolean;
  providerSearch: GenericSearch = { searchFilter: "name" };
  providers: MedicalProviderSearchResult[] = [];
  showNoRecordFound: boolean = false;
  isProcessing: boolean = false;
  recordExistInPatient: boolean = false;
  isShowAllRec: boolean = false;


  @ViewChild('toolTip1') toolTip1: MatTooltip;

  constructor(
    private dialog: MatDialog,
    private alertService: AlertService,
    private dataService: DataService,
    private appHtmlControlService: AppHtmlControlService,
    private router: Router
  ) {
    super();
  }

  ngOnInit(): void {
    this.providerSearch.searchFilter = "name";
    this.providerSearch.searchKeyword = "";
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  toggleDisplayAllRecords() {
    if (this.isShowAllRec) {
      this.providerSearch.searchKeyword = "";
      this.dbSearch();
    } else {
      this.providerSearch.searchFilter = "name";
    }
  }


  openAddProviderDialog(): void {
    const dialogRef = this.dialog.open(MedicalProviderComponent, {
      data: { name: 'Add Medical Provider', returnData: true, isAdminMode: true},
    });
    dialogRef.afterClosed().subscribe((result) => {   
      if (!!result) {
        if (!this.providerSearch.searchKeyword) {
          this.providerSearch.searchFilter = "all";
          this.providerSearch.searchKeyword = "";
          this.isShowAllRec = true;
        }
        this.dbSearch();
      }
    });
  }

  
  searchProvider() {
    this.showNoRecordFound = false;
    let x = this.providerSearch;
    if ((this.providerSearch.searchKeyword != null) && (this.providerSearch.searchKeyword != "")) {
      this.dbSearch();
    }
  }

  openLinkedPatientsDialog(val: MedicalProviderSearchResult) {
    const patientSearch: GenericSearch = {searchFilter: "provider", searchKeyword: val.id };
    if (val.linkedPatients == 0) {
      this.alertService.displayWarningMessage(AlertType.Toast, "", "No patients are linked to this medical provider.");
      return;
    }
      const dialogRef = this.dialog.open(LinkedPatientsComponent, {
        data: { title: val.name, value: patientSearch },
      });
      dialogRef.afterClosed().subscribe((result) => {});
  }


  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  openEditProvider(providerId: string) {
    this.router.navigateByUrl(`thirdparty/medicalprovider/detail/${providerId}`)
  }

  offSetToolTipLoc(msg: string, _toolTip: MatTooltip) {
    this.appHtmlControlService.offSetToolTipLoc(msg, _toolTip);
  }


  openDeleteDialog(val: string) {
    const dialogRef = this.dialog.open(ConfirmDeleteComponent, { data: val });
    dialogRef.afterClosed().subscribe(result => {
      if ((!!result.response) && (result.response)) {
        this.deleteProvider(val);
      }
    });
  }

  dbSearchByKeyword() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.providerSearch, APIUrls.SearchMedicalProviders)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          const response: MedicalProviderSearchResult[] = data;
          this.providers = response;
          if (this.providers.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  
  deleteProvider(_id: string) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .deleteData(_id, APIUrls.MedicalProvider)
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          this.alertService.displaySuccessMessage(AlertType.Toast, "", "Insurance provider record deleted successfully!!");
          this.dbSearch();
         },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  } 


  dbSearch() {
    if (this.isShowAllRec) {
      this.providerSearch.searchFilter = "all";
    } 
    this.dbSearchByKeyword();
  }


}

