import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { DataService, AlertService, AuthService } from 'service-lib';
import {
  UserLogin,
  UserSession,
  BaseApiResponse,
  APIUrls,
  AlertType,
  AppMessage
} from 'model-lib';
import { BaseComponent } from '../../shared/core/base.component';
import 'rxjs/add/operator/finally';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent extends BaseComponent implements OnInit {
  isTokenValid: boolean = false;
  password2: string = '';
  userLogin: UserLogin = {};
  isPasswordError: boolean = false;
  errorMsg: string = '';
  disableSubmit: boolean = false;
  userSession: UserSession = {};
  isProcessing = false;

  constructor(
    private activeRoute: ActivatedRoute,
    private dataService: DataService,
    private alertService: AlertService,
    private authService: AuthService
  ) {
    super();
  }

  ngOnInit(): void {
    this.userSession = this.authService.getUserLoggedIn();
    this.parseUrlQuery();
  }

  getTokenUserName() {
    this.clearError();
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let request: BaseApiResponse;
    let ret = this.dataService
      .getSingleData(request, this.userLogin.token, APIUrls.GetTokenUserName)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
        if (this.isPasswordError) {
          this.logout();
        }
      })
      .subscribe(
        data => {
          let ret: BaseApiResponse = data;
          if (ret.isSucceeded) {
            this.userLogin.userName = ret.responseMessage;
            this.verifyPasswordRequestToken();
          } else {
            this.isPasswordError = true;
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              'Error retrieving your password change request. Contact CareConnect Helpdesk'
            );
          }
        },
        error => {
          this.isPasswordError = true;
          this.errorMsg = AppMessage.VerifyResetPasswordTokenFailed;
          this.disableSubmit = true;
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
      );
  }

  verifyPasswordRequestToken() {
    this.clearError();
    this.isProcessing = true;
    let response: BaseApiResponse;
    let ret = this.dataService
      .getSingleData(
        response,
        this.userLogin.token,
        APIUrls.VerifyPasswordRequestToken
      )
      .finally(() => {
        this.alertService.showSpinner(false);
        if (this.isPasswordError) {
          this.logout();
        }
      })
      .subscribe(
        data => {
          let ret: BaseApiResponse = data;
          if (ret.isSucceeded) {
            this.isTokenValid = true;
            this.disableSubmit = false;
          } else {
            this.isPasswordError = true;
            this.errorMsg = ret.responseMessage;
            this.disableSubmit = true;
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              this.errorMsg
            );
          }
        },
        error => {
          this.isPasswordError = true;
          this.errorMsg = AppMessage.VerifyResetPasswordTokenFailed;
          this.disableSubmit = true;
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
      );
  }

  clearError() {
    this.disableSubmit = false;
    this.isPasswordError = false;
  }

  changePassword() {
    this.clearError();
    this.isProcessing = true;
    let ret = this.authService
      .ChangeUserPassword(this.userLogin)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        (data: any) => {
          let x: boolean = data;
          if (x) {
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              '',
              AppMessage.ResetPasswordSuccess
            );
            this.clearErrorMsg();
            this.logout();
          } else {
            this.errorMsg = AppMessage.ResetPasswordFailed;
            this.isPasswordError = true;
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              this.errorMsg
            );
          }
        },
        (error: any) => {
          this.isPasswordError = true;
          this.errorMsg = AppMessage.ResetPasswordFailed;
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            AppMessage.ResetPasswordFailed
          );
        }
      );
  }

  clearErrorMsg() {
    this.isPasswordError = false;
    this.errorMsg = '';
    this.isProcessing = false;
  }

  submitForm() {
    this.clearErrorMsg();
    if (this.userLogin.password === this.password2) {
      this.changePassword();
    }
  }

  logout() {
    this.authService.logout();
  }

  parseUrlQuery() {
    this.activeRoute.params.subscribe(parms => {
      const tmpToken: string = parms['token'];

      if (tmpToken != null) {
        this.userLogin.token = tmpToken;
        this.getTokenUserName();
      } else {
        this.logout();
      }
    });
  }
}
