import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../shared/core/base.component';
import { DataService, AlertService, AuthService, PatientService } from 'service-lib';
import { APIUrls, CompanyExtraDetails, AlertType, CompanyPatientMedicalHistory, AppMessage, GenericIdValue, CompanyService } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { UserSession } from 'model-lib';

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.scss']
})
export class PatientComponent extends BaseComponent implements OnInit {

  isProcessing: boolean = false;
  constructor(
    private dataService:DataService,
    private alertService: AlertService,
    private authService: AuthService,
    private patientService: PatientService
  ) { 
    super();
  }

  ngOnInit(): void {
    this.getPatientConfigData();
    this.patientService.isPatientRecordChanged$.pipe(takeUntil(this.destroy$))
    .subscribe(val => {
      this.getPatientConfigData()
    });
    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data: UserSession) => {
      if (!!data.companyId) {
        this.getDbPatientExtraDetails();
        this.getDbMedicalHistory();
        this.getDbCompanyServices();
      }
    });
  }


  getPatientConfigData() {
    this.getDbPatientExtraDetails();
    this.getDbMedicalHistory();
    this.getDbCompanyServices();
  }

  getDbPatientExtraDetails() {
    this.isProcessing = true;
    this.alertService.setDisplayExceptionAlertMsg(true);
    const _userSession = this.authService.getUserLoggedIn();
    if (!_userSession) {
      return
    }
     let response: CompanyExtraDetails;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.CompanyExtraDetail
      )
      .finally(() => {
        this.isProcessing = false;
       })
      .subscribe(
        data => {
          this.mapCompanyExtraDetails2DropDown(data);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  getDbMedicalHistory() {
    const _userSession = this.authService.getUserLoggedIn();
    this.alertService.setDisplayExceptionAlertMsg(true);
    if (!_userSession) {
      return
    }
    this.isProcessing = true;
    let response: CompanyPatientMedicalHistory;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.CompanyPatientMedicalHistory
      )
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.patientService.updateCompanyPatientMedicalHistory(data);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  mapCompanyExtraDetails2DropDown(extraDetails: CompanyExtraDetails[]) {
    //Get patient only extra details
    let extraDetailsDropDown: GenericIdValue[] = [];
    extraDetails.filter(x => x.extraDetailEntityId == 1).forEach(item => {
      extraDetailsDropDown.push({ id: item.id, value: item.fieldName });
    });
    if (extraDetailsDropDown.length > 0) {
      this.patientService.updateExtraDetailsDropDown(extraDetailsDropDown);
    }
  }

  mapCompanyServicesDropDown(companyBusServices: CompanyService[]) {
    let companyServiceDropDown: GenericIdValue[] = [];
    companyBusServices.forEach(item => {
      companyServiceDropDown.push({ id: item.id, value: item.serviceName });
    });
    if (companyServiceDropDown.length > 0) {
      this.patientService.updateServiceRequestedDropDown(companyServiceDropDown);
    }
  }


  getDbCompanyServices() {
    const _userSession = this.authService.getUserLoggedIn();
    this.alertService.setDisplayExceptionAlertMsg(true);
    if (!_userSession) {
      return
    }
    this.isProcessing = true;
    let response: CompanyService;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.CompanyServices
      )
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          this.mapCompanyServicesDropDown(data);
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
