import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageProviderSearchComponent } from './manage-provider-search.component';

describe('ManageProviderSearchComponent', () => {
  let component: ManageProviderSearchComponent;
  let fixture: ComponentFixture<ManageProviderSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManageProviderSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageProviderSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
