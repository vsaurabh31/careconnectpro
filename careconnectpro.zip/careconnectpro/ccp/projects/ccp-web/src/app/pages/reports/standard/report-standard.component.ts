import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-standard',
  templateUrl: './report-standard.component.html',
  styleUrls: ['./report-standard.component.scss']
})
export class ReportStandardComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
