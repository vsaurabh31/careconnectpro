import { Component, OnInit } from '@angular/core';
import {
  MatDialog,
} from '@angular/material/dialog';
import { ConfirmDeleteComponent } from '../../../shared/modal/confirm-delete/confirm-delete.component';
import { SecurityRoleComponent } from '../../../shared/modal/security-role/security-role.component';
import { SecurityUserComponent } from '../../../shared/modal/security-user/security-user.component';
import { SecurityPermissionComponent } from '../../../shared/modal/security-permission/security-permission.component';
import { BaseComponent } from '../../../shared/core/base.component';
import { AlertType, APIUrls, AppRole } from 'model-lib';
import { AlertService, CompanyBusinessService, DataService, SecurityService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';
@Component({
  selector: 'app-security',
  templateUrl: './security.component.html',
  styleUrls: ['./security.component.scss'],
})
export class SecurityComponent extends BaseComponent implements OnInit {
  companyRoles: AppRole[] = [];
  isProcessing = false;
  constructor(
    private dataService: DataService,
    private alertService: AlertService,
    private securityService: SecurityService,
    private companyBusinessService: CompanyBusinessService,
    public dialog: MatDialog) {
    super();
  }

  ngOnInit(): void {
    this.initData();
    this.securityService.isAppRoleUpdated$
    .pipe(takeUntil(this.destroy$))
    .subscribe(val => {
      if (val) {
        this.initData();
      }
    })
  }

  initData() {
    this.getCompanyRoles();

  }

  openPermissionDialoag(_role: AppRole) {
        const dialogRef = this.dialog.open(SecurityPermissionComponent, {
          data: { title: _role.name, value: _role },
        });
        dialogRef.afterClosed().subscribe((result) => {}); 
  }

  openDeleteDialog(id: string): void {
    const dialogRef = this.dialog.open(ConfirmDeleteComponent, {});
    dialogRef.afterClosed().subscribe((result) => {
      if ((!!result.response) && (result.response)) {
        this.deleteRole(id);
      }
    });
  }

  deleteRole(id: string){
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .deleteData(id, APIUrls.CompanyRole)
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          this.alertService.displaySuccessMessage(AlertType.Toast, "", "Role Deleted Successfully");
          this.initData();
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  onClickAddRole() {
    const dialogRef = this.dialog.open(SecurityRoleComponent, {
      data: { title: 'Add Role' },
    });
    dialogRef.afterClosed().subscribe((result) => {});
  }

  openEditDialog(role: AppRole) {
    const dialogRef = this.dialog.open(SecurityRoleComponent, {
      data: { title: 'Edit Role', value: role },
    });
    dialogRef.afterClosed().subscribe((result) => {});
  }


  openUserDialog(_role: AppRole) {
    if (_role.assignedUsers == 0) {
      this.alertService.displayWarningMessage(AlertType.Toast, "", "No users are assigned to this role.");
      return;
    }
      const dialogRef = this.dialog.open(SecurityUserComponent, {
        data: { title: _role.name, value: _role },
      });
      dialogRef.afterClosed().subscribe((result) => {});
  }


  getCompanyRoles() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let response: AppRole;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.CompanyRole
      )
      .finally(() => {
       this.alertService.showSpinner(false);
        this.isProcessing = false;
      })
      .subscribe(
        (data: AppRole[]) => {
          if (!!data) {
            this.companyRoles = data;
            this.companyRoles.sort((a,b) => {return a.name.localeCompare(b.name)});
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
