import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from '../../../shared/core/base.component';
import {
  MatDialog,
} from '@angular/material/dialog';
import { Physician, Address, PhysicianSearchResult } from 'model-lib';
import { AlertService, DataService, AppHtmlControlService } from 'service-lib';
import { APIUrls } from 'model-lib';
import { AlertType } from 'model-lib';
import { GenericSearch } from 'model-lib';
import { PhysicianComponent } from '../../../shared/modal/physician/physician.component';
import { MatTooltip } from '@angular/material/tooltip';
import { ConfirmDeleteComponent } from '../../../shared/modal/confirm-delete/confirm-delete.component';
import { LinkedPatientsComponent } from '../../../shared/modal/linked-patients/linked-patients.component';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-physician-search',
  templateUrl: './manage-physician-search.component.html',
  styleUrls: ['./manage-physician-search.component.scss']
})
export class ManagePhysicianSearchComponent extends BaseComponent implements OnInit {
  physicianPhone: string;
  physicianFax: string = "";
  physicianAddress: Address = {};
  isPrimary: boolean;
  physicianSearch: GenericSearch = { searchFilter: "name" };
  physicians: PhysicianSearchResult[] = [];
  showNoRecordFound: boolean = false;
  isProcessing: boolean = false;
  recordExistInPatient: boolean = false;
  isShowAllRec: boolean = false;


  @ViewChild('toolTip1') toolTip1: MatTooltip;

  constructor(
    private dialog: MatDialog,
    private alertService: AlertService,
    private dataService: DataService,
    private appHtmlControlService: AppHtmlControlService,
    private router: Router
  ) {
    super();
  }

  ngOnInit(): void {
    this.physicianSearch.searchFilter = "name";
    this.physicianSearch.searchKeyword = "";
  }

  clearRecordExistError() {
    this.recordExistInPatient = false;
  }

  toggleDisplayAllRecords() {
    if (this.isShowAllRec) {
      this.physicianSearch.searchKeyword = "";
      this.dbSearch();
    } else {
      this.physicianSearch.searchFilter = "name";
    }
  }


  openAddPhysicianDialog(): void {
    const dialogRef = this.dialog.open(PhysicianComponent, {
      data: { name: 'Add Physician', returnData: true, isAdminMode: true},
    });
    dialogRef.afterClosed().subscribe((result) => {    
      if (!!result) {
        if (!this.physicianSearch.searchKeyword) {
          this.physicianSearch.searchFilter = "all";
          this.physicianSearch.searchKeyword = "";
          this.isShowAllRec = true;
        }
        this.dbSearch();
      }
    });
  }

  
  searchPhysician() {
    this.showNoRecordFound = false;
    let x = this.physicianSearch;
    if ((this.physicianSearch.searchKeyword != null) && (this.physicianSearch.searchKeyword != "")) {
      this.dbSearch();
    }
  }

  openLinkedPatientsDialog(val: PhysicianSearchResult) {
    const patientSearch: GenericSearch = {searchFilter: "physician", searchKeyword: val.id };
    if (val.linkedPatients == 0) {
      this.alertService.displayWarningMessage(AlertType.Toast, "", "No patients are linked to this physician.");
      return;
    }
      const dialogRef = this.dialog.open(LinkedPatientsComponent, {
        data: { title: val.name, value: patientSearch },
      });
      dialogRef.afterClosed().subscribe((result) => {});
  }


  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  openEditDialog(vendorId: string) {
    this.router.navigateByUrl(`thirdparty/physician/detail/${vendorId}`)
  }

  offSetToolTipLoc(msg: string, _toolTip: MatTooltip) {
    this.appHtmlControlService.offSetToolTipLoc(msg, _toolTip);
  }


  openDeleteDialog(val: string) {
    const dialogRef = this.dialog.open(ConfirmDeleteComponent, { data: val });
    dialogRef.afterClosed().subscribe(result => {
      if ((!!result.response) && (result.response)) {
        this.deletePhysician(val);
      }
    });
  }

  dbSearchByKeyword() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .postData(this.physicianSearch, APIUrls.SearchPhysicians)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          const response: PhysicianSearchResult[] = data;
          this.physicians = response;
          if (this.physicians.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

 
  deletePhysician(_id: string) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let ret = this.dataService
      .deleteData(_id, APIUrls.Physician)
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          this.alertService.displaySuccessMessage(AlertType.Toast, "", "Physician record deleted successfully!!");
          this.dbSearch();
         },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  } 


  dbSearch() {
    if (this.isShowAllRec) {
      this.physicianSearch.searchFilter = "all";
    } 
    this.dbSearchByKeyword();
  }


}
