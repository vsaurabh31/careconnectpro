import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billing-history',
  templateUrl: './billing-history.component.html',
  styleUrls: ['./billing-history.component.scss']
})
export class BillingHistoryComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
