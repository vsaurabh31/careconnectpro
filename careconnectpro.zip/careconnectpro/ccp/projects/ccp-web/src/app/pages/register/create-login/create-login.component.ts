import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import {
  DataService,
  AlertService,
  AuthService,
  SubscriptionService
} from 'service-lib';
import { BaseComponent } from '../../../shared/core/base.component';
import 'rxjs/add/operator/finally';
import { AlertType, AppMessage, APIUrls } from 'model-lib';
import { UserSignup } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { MessageStatus } from 'model-lib';

@Component({
  selector: 'app-create-login',
  templateUrl: './create-login.component.html',
  styleUrls: ['./create-login.component.scss']
})
export class CreateLoginComponent extends BaseComponent implements OnInit {
  accountToken: string = '';
  isProcessing: boolean = false;
  isTokenValid: boolean = false;
  companyRegistration: UserSignup = {};
  messageStatus: MessageStatus = {};
  isValidating: boolean = false;
  errorMsg = '';

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private dataService: DataService,
    private alertService: AlertService,
    private authService: AuthService,
    private activeRoute: ActivatedRoute,
    private subscriptionService: SubscriptionService
  ) {
    super();
  }

  ngOnInit(): void {
    this.companyRegistration = this.subscriptionService.getCompanyRegistration();
    this.subscriptionService.companyRegistration$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.companyRegistration = val;
      });
    this.parseUrlQuery();
  }

  logout() {
    this.alertService.displayErrorMessage(
      AlertType.Dialog,
      '',
      AppMessage.VerifyAccountConfirmationTokenFailed
    );
    this.authService.logout();
  }

  parseUrlQuery() {
    this.activeRoute.params.subscribe(parms => {
      const tmpToken: string = parms['token'];
      if (tmpToken != null) {
        this.accountToken = tmpToken;
        this.validateRegistrationStage();
      } else {
        this.logout();
      }
    });
  }

  validateAccountConfirmToken() {
    this.isValidating = true;
    this.alertService.showSpinner(true);
    this.isProcessing = true;
    let response: UserSignup;
    let ret = this.dataService
      .getSingleData(
        response,
        this.accountToken,
        APIUrls.ValidateRegistrationToken
      )
      .finally(() => {
        this.alertService.showSpinner(false);
        this.isProcessing = false;
        this.isValidating = false;
      })
      .subscribe(
        data => {
          let ret: UserSignup = data;
          if (ret != '' && ret.email != undefined && ret.email != '') {
            this.companyRegistration = ret;
            this.companyRegistration.userName = this.companyRegistration.email;
            this.companyRegistration.password = '';
            this.companyRegistration.password2 = '';
            this.subscriptionService.setCompanyRegistration(
              this.companyRegistration
            );
          } else {
            this.logout();
          }
        },
        error => {
          this.logout();
        }
      );
  }

  validateRegistrationStage() {
    let _companyRegistration = this.subscriptionService.getCompanyRegistration();
    if (
      !!_companyRegistration.userName &&
      !!_companyRegistration.password &&
      !!_companyRegistration.password2 &&
      _companyRegistration.password == _companyRegistration.password2 &&
      !!_companyRegistration.confirmToken
    ) {
      this.selectPlan();
    } else {
      this.validateAccountConfirmToken();
    }
  }

  submitForm() {
    if (
      this.companyRegistration.password == this.companyRegistration.password2
    ) {
      this.isUserNameExist();
    }
  }

  selectPlan() {
    this.subscriptionService.setCompanyRegistration(this.companyRegistration);
    this.router.navigateByUrl('landing/register/selectplan');
  }

  clearResetError() {
    this.messageStatus.isSuccessful = true;
    this.errorMsg = '';
  }

  isUserNameExist() {
    this.isProcessing = true;
    let request: any;
    let ret = this.dataService
      .getSingleData(
        request,
        this.companyRegistration.userName,
        APIUrls.AccountValidateUsername
      )
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          let ret: boolean = data;
          if (ret) {
            this.messageStatus.isSuccessful = false;
            this.errorMsg = AppMessage.RegisterLoginUserNameExist;
          } else {
            this.selectPlan();
          }
        },
        error => {
          this.messageStatus.isSuccessful = false;
          this.errorMsg = error;
        }
      );
  }
}
