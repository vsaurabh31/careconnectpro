import { Component, Input, OnInit, SimpleChange } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { APIUrls, Episode, TaskSearchResult, GenericSearch, AlertType, UserSession, Status } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, EpisodeService } from 'service-lib';
import { BaseComponent } from '../../../../app/shared/core/base.component';

@Component({
  selector: 'app-agency-task',
  templateUrl: './agency-task.component.html',
  styleUrls: ['./agency-task.component.scss']
})
export class AgencyTaskComponent extends BaseComponent implements OnInit {
  isProcessing: boolean = false;
  showNoRecordFound: boolean = false;
  taskSearch: GenericSearch = { searchFilter: "agencytask" };
  isShowAllRec: boolean = false;
  @Input() isAddMode: boolean;
  @Input() episode: Episode = {};
  @Input() employeeNames: Map<string, string>;
  @Input() companyServices: Map<string, string>;
  tasks: TaskSearchResult[] =[];

  constructor(
    private router: Router,
    private dialog: MatDialog,
    private episodeService: EpisodeService,
    private alertService: AlertService,
    private dataService: DataService,
    private authService: AuthService
  ) { 
    super();
  }

  ngOnInit(): void {
    const userSession = this.authService.getUserLoggedIn();
    if (!!userSession) {
      this.getDbTasks();
    }

    this.authService.userSession$.pipe(takeUntil(this.destroy$))
    .subscribe((data: UserSession) => {
      if (!!data.companyId) {
        this.getDbTasks();
      }
    });
  }

  sortTasks() {
    this.tasks.sort((a, b) => {
      return +new Date(a.dueDate) - +new Date(b.dueDate)
    });
  }

  ngOnChanges(changes: SimpleChange) {}

  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  getDbTasks() {
    this.taskSearch.searchKeyword = "";
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.clearNoRecordError();
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.taskSearch, APIUrls.SearchTasks)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: TaskSearchResult[] = data;
          this.tasks = response;
          this.sortTasks();
          if (this.tasks.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  selectPatient(episodeTask: TaskSearchResult) {
    this.router.navigateByUrl(`patient/detail/${episodeTask.patientId}`);
  }
  openClickAddTask(){}

  getStatusColor(status: string) {
    switch(status) {        
      case Status.IN_PROGRESS:
      case Status.ACTIVE:
          return 'primary';
      case Status.ONHOLD:
          return 'warn';      
    }
  }
}
