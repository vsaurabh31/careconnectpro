import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { DashboardComponent } from './pages/dashboard/dashboard.component';
import { SharedModule } from './../../shared/shared.module';

export const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [{ path: '', component: DashboardComponent }]
  }
];

@NgModule({
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
  declarations: [HomeComponent, DashboardComponent]
})
export class HomeModule {}
