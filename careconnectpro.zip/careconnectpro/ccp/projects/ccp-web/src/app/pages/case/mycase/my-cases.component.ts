import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AlertType, APIUrls, EpisodeSearchResult, GenericSearch, Status } from 'model-lib';
import { AlertService, AuthService, DataService} from 'service-lib';
import { BaseComponent } from '../../../shared/core/base.component';
import { EpisodeVisitListComponent } from '../../episode/modal/visit/episode-visit-list.component';

@Component({
  selector: 'app-my-cases',
  templateUrl: './my-cases.component.html',
  styleUrls: ['./my-cases.component.scss']
})
export class MyCasesComponent extends BaseComponent implements OnInit {

  episodeSearchKeyword: string = "";
  isProcessing: boolean = false;
  episodes: EpisodeSearchResult[] = [];
  showNoRecordFound: boolean = false;
  episodeSearch: GenericSearch = { searchFilter: "casemanagerid" };
  isShowAllRec: boolean = false;

  constructor(
    private dialog: MatDialog,
    private alertService: AlertService,
    private dataService: DataService,
    private authService: AuthService,
    private router: Router
  ) { 
    super();
  }

  ngOnInit(): void {
    const userSession = this.authService.getUserLoggedIn();
    
    if (!userSession || !userSession.employeeId) {
      this.router.navigateByUrl("/dashboard");
      return
    }
    this.episodeSearch.searchKeyword = userSession.employeeId;    
    this.searchEpisode();
  }

 
  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  sortEpisode() {
    this.episodes.sort((a, b) => {
      return +new Date(b.startOfCare) - +new Date(a.startOfCare)
    });
  }
  
  searchEpisode() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.clearNoRecordError();
    this.isProcessing = true;
    const _userSession = this.authService.getUserLoggedIn();
    this.episodeSearch.companyId = _userSession.companyId;
    let ret = this.dataService
      .postData(this.episodeSearch, APIUrls.SearchEpisodes)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: EpisodeSearchResult[] = data;
          this.episodes = response;
          this.sortEpisode();
          if (this.episodes.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

 selectEpisode(_episode: EpisodeSearchResult) {
    this.router.navigateByUrl(`episode/detail/${_episode.id}`);
  }

  openVisitsDialog(val: EpisodeSearchResult) {
    if (val.visits == 0) {
      this.alertService.displayWarningMessage(AlertType.Toast, "", "No visits are scheduled for this episode");
      return;
    }
      const dialogRef = this.dialog.open(EpisodeVisitListComponent, {
        data: { title: val.patientName, value: val.id },
      });
      dialogRef.afterClosed().subscribe((result) => {});
  }

  selectPatient(_episode: EpisodeSearchResult) {
    this.router.navigateByUrl(`patient/detail/${_episode.patientId}`);
  }
  
  getStatusColor(status: string) {
    switch(status) {        
      case Status.IN_PROGRESS:
      case Status.ACTIVE:
          return 'primary';
      case Status.ONHOLD:
          return 'warn';      
    }
  }
}
