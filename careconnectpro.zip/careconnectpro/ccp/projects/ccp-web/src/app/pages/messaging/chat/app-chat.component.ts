import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-chat',
  templateUrl: './app-chat.component.html',
  styleUrls: ['./app-chat.component.scss']
})
export class AppChatComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
