import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-event',
  templateUrl: './personal-event.component.html',
  styleUrls: ['./personal-event.component.scss']
})
export class PersonalEventComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
