import { Component, OnInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { AlertType, APIUrls, AppMessage, Company, CompanyExtraDetails } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, CompanyBusinessService, DataService } from 'service-lib';
import { BaseComponent } from '../../../shared/core/base.component';

@Component({
  selector: 'app-agency',
  templateUrl: './agency.component.html',
  styleUrls: ['./agency.component.scss'],
})
export class AgencyComponent extends BaseComponent implements OnInit {
  agencyData: Company = {};
  inTakeExtraDetail: CompanyExtraDetails[] = [];
  isProcessing = false;
  open:boolean = false;

  constructor(public dialog: MatDialog,
    private dataService: DataService,
    private alertService: AlertService,
    private companyBusinessService: CompanyBusinessService) {
      super();
    }

  ngOnInit(): void {
    this.dbGetAgency();
    this.companyBusinessService.isRecordChanged$
    .pipe(takeUntil(this.destroy$))
    .subscribe(val => {
      this.dbGetAgency();
    });
  }
 
  showSpinner() {    
    this.alertService.showSpinner(true);
  }
  openAgency=()=>{
    this.open = !this.open;
  }

  dbGetAgency() {
    this.isProcessing = true;
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: Company;
    let ret = this.dataService
      .getSingleData(
        response,
        "",
        APIUrls.Company
      )
      .finally(() => {
       this.alertService.showSpinner(false);
        this.isProcessing = false;
      })
      .subscribe(
        (data: Company) => {
          if (!!data.id) {
            this.agencyData = data;
            this.companyBusinessService.updateCompany(data);
            this.filterIntakeExtraDetail();

          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.AgencyInfoNotAvailable);
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  filterIntakeExtraDetail() {
    this.inTakeExtraDetail = this.agencyData.extraDetails.filter(x => x.extraDetailEntityId==1);
  }
}
