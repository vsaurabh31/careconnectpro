import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationDemovideoComponent } from './registration-demovideo.component';

describe('RegistrationDemovideoComponent', () => {
  let component: RegistrationDemovideoComponent;
  let fixture: ComponentFixture<RegistrationDemovideoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RegistrationDemovideoComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationDemovideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
