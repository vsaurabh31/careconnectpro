import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../../shared/shared.module';
import { MyCasesComponent } from './mycase/my-cases.component';
import { RouterModule, Routes } from '@angular/router';


export const routes: Routes = [
  {
    path: '',
    component: MyCasesComponent,
    children: [
      { path: 'mycases', component: MyCasesComponent }
    ]
  }
];

@NgModule({
  declarations: [MyCasesComponent],
  imports: [
    CommonModule, SharedModule, RouterModule.forChild(routes)
  ]
})
export class CaseManagementModule { }
