import { Component, OnInit, ViewChild } from '@angular/core';
import { BaseComponent } from './../../../shared/core/base.component';
import { Patient,GenericIdValue } from 'model-lib';
import { PatientService, NavService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';
import { NgbTabset } from "@ng-bootstrap/ng-bootstrap";

@Component({
  selector: 'app-intake',
  templateUrl: './intake.component.html',
  styleUrls: ['./intake.component.scss']
})
export class IntakeComponent extends BaseComponent implements OnInit {
  extraDetailsDropDown: GenericIdValue[] = [];
  patient: Patient = {};
  IntakeStatus: any[] = [{ 1: false, 2: false, 3: false, 4: false, 5: false, 6: false }];
  disablePrevBtn: boolean = false;
  disableNextBtn: boolean = false;
  inTakeStep: number = 1;
  @ViewChild('intakeTabs') intakeTabs: NgbTabset;

  constructor(
    private patientService: PatientService,
    private navService: NavService
  ) {
    super();
  }

  ngOnInit(): void {
    const patient: Patient = {};
    this.patientService.updateInTakeMode(true);
    this.patientService.updatePatient(patient);
    this.refreshPatientData();

    this.patientService.isPatientRecordChanged$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        if (val) {
          this.patient = this.patientService.getPatient();
          this.validateIntakeProgress();
        }
      });
    this.navService.inTakeStep$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        if (val) {
          this.inTakeStep = val;
          this.validateInTakeStepBtn();
        }
      });
  }

  validateInTakeStepBtn() {
    if (this.inTakeStep == 1) {
      this.disablePrevBtn = true;
    } else {
      this.disablePrevBtn = false;
    }
    if (this.inTakeStep == 7) {
      this.disableNextBtn = true;
    } else {
      this.disableNextBtn = false;
    }
    if (!this.intakeTabs) {
      return;
    }
    switch (this.inTakeStep) {
      case 1:
        this.intakeTabs.select('patientInfo');
        break;
      case 2:
        this.intakeTabs.select('refEntity');
        break;
      case 3:
        this.intakeTabs.select('medHistory');
        break;
      case 4:
        this.intakeTabs.select('medication');
        break;
      case 5:
        this.intakeTabs.select('diagnosis');
        break;
      case 6:
        this.intakeTabs.select('serviceReq');
        break;
      case 7:
        this.intakeTabs.select('billing');
        break;
    }
  }

  setIntakeStep(id: number) {
    this.navService.setInTakeStep(id);
  }

  refreshPatientData() {
    this.validateInTakeStepBtn();
  }

    validateIntakeProgress() {
    if (this.patient.referralPhysicians?.length > 0) {
      this.IntakeStatus[1] = true;
    } else {
      this.IntakeStatus[1] = false;
    }
    if ((!!this.patient?.lastName) && (this.patient.addresses?.length > 0)) {
      this.IntakeStatus[2] = true;
    } else {
      this.IntakeStatus[2] = false;
    }
    if (this.patient.medicalHistory?.length > 0) {
      this.IntakeStatus[3] = true;
    } else {
      this.IntakeStatus[3] = false;
    }
    if (this.patient.medicalHistory?.length > 0) {
      this.IntakeStatus[4] = true;
    } else {
      this.IntakeStatus[4] = false;
    }
    if (this.patient.diagnosis?.length > 0) {
      this.IntakeStatus[5] = true;
    } else {
      this.IntakeStatus[5] = false;
    }
    if (this.patient.servicesRequested?.length > 0) {
      this.IntakeStatus[6] = true;
    } else {
      this.IntakeStatus[6] = false;
    }
    if ((this.patient.privateInsurance?.length > 0) || (this.patient.governmentInsurance?.length > 0)
      || (this.patient.paymentProfiles?.length > 0)) {
      this.IntakeStatus[7] = true;
    } else {
      this.IntakeStatus[7] = false;
    }
  }

  disableCompleteBtn() {
    if (this.IntakeStatus[1] && this.IntakeStatus[2] && this.IntakeStatus[3] && this.IntakeStatus[5]
      && this.IntakeStatus[6] && this.IntakeStatus[7]) {
      return false;
    } else {
      return true;
    }
  }

  prev() {
    this.navService.prevInTakeStep();
  }
  next() {
    this.navService.nextInTakeStep();
  }

}
