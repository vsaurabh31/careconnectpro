import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatientSearchComponent } from './search/patient-search.component';
import { PatientDetailComponent } from './detail/patient-detail.component';
import { RouterModule, Routes } from '@angular/router';
import { IntakeComponent } from './intake/intake.component';
import { SharedModule } from './../../shared/shared.module';
import { HeaderComponent } from './intake/components/header/header.component';
import { IntakeProviderComponent } from './intake/pages/intake-provider/intake-provider.component';
import { IntakePatientComponent } from './intake/pages/intake-patient/intake-patient.component';
import { IntakeMedicalHistoryComponent } from './intake/pages/intake-medical-history/intake-medical-history.component';
import { IntakeMedicationComponent } from './intake/pages/intake-medication/intake-medication.component';
import { IntakeDiagnosisComponent } from './intake/pages/intake-diagnosis/intake-diagnosis.component';
import { IntakeServiceRequestComponent } from './intake/pages/intake-service-request/intake-service-request.component';
import { IntakeBillingComponent } from './intake/pages/intake-billing/intake-billing.component';
import { IntakePatientHeaderComponent } from './intake/pages/intake-patient/intake-patient-header.component';
import { PatientComponent } from './patient.component';
import { PatientDashboardComponent } from './detail/dashboard/patient-dashboard.component';

export const routes: Routes = [
  {
    path: '',
    component: PatientComponent,
    children: [
      { path: 'intake', component: IntakeComponent },
      { path: 'detail/:id', component: PatientDetailComponent },
      { path: 'manage', component: PatientSearchComponent }      
    ]
  }
];

@NgModule({
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
  declarations: [
    PatientSearchComponent, 
    PatientDetailComponent,
    IntakeComponent,
    HeaderComponent,
    IntakeProviderComponent,
    IntakePatientComponent,
    IntakeDiagnosisComponent,
    IntakeMedicalHistoryComponent,
    IntakeMedicationComponent,
    IntakeServiceRequestComponent,
    IntakeBillingComponent,
    IntakePatientHeaderComponent,
    PatientComponent,
    PatientDashboardComponent]
})
export class PatientModule { }
