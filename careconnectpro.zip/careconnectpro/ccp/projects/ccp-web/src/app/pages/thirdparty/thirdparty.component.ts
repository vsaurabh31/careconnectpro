import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../shared/core/base.component';

@Component({
  selector: 'app-thirdparty',
  templateUrl: './thirdparty.component.html',
  styleUrls: ['./thirdparty.component.scss']
})
export class ThirdpartyComponent extends BaseComponent implements OnInit {

  constructor() { 
    super();
  }

  ngOnInit(): void {
  }

}
