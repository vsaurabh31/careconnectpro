import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../../shared/core/base.component';
import { Contact, AlertType, APIUrls, Patient, PatientSearchKeys, GenericSearch } from 'model-lib';
import { HelperService, AlertService, DataService, AuthService, PatientService } from 'service-lib';
import { Router } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { PatientSearchResult } from 'projects/model-lib/src/lib/models';

@Component({
  selector: 'app-patient-search',
  templateUrl: './patient-search.component.html',
  styleUrls: ['./patient-search.component.scss']
})
export class PatientSearchComponent extends BaseComponent implements OnInit {
  patSearchKeyword: string = "";
  isProcessing: boolean = false;
  patients: PatientSearchResult[] = [];
  showNoRecordFound: boolean = false;
  patientSearch: GenericSearch = { searchFilter: "name" };
  isShowAllRec: boolean = false;

  constructor(
    private helperService: HelperService,
    private alertService: AlertService,
    private dataService: DataService,
    private authService: AuthService,
    private patientService: PatientService,
    private router: Router
  ) { 
    super();
  }

  ngOnInit(): void {
    this.patientSearch.searchFilter = "name";
    this.patientSearch = {};
    this.patientService.executePatientSearch$.pipe(takeUntil(this.destroy$))
    .subscribe(val => {
      const isHeaderSearch= this.patientService.getTriggerHeaderSearch();
      if (val &&  isHeaderSearch) {
        const isHeaderSearch = this.patientService.getTriggerHeaderSearch();
        this.patientSearch = this.patientService.getSearchKeyword();
        this.patientSearch.searchFilter = "name";
        this.patientService.updateTriggerHeaderSearch(false);
        if (!!this.patientSearch.searchKeyword) {
          this.isShowAllRec = false;
          this.searchPatient();
        }
      }
    });
    this.patientSearch = this.patientService.getSearchKeyword();
    const isHeaderSearch= this.patientService.getTriggerHeaderSearch();
    if (!!this.patientSearch && isHeaderSearch) {
      this.patientSearch.searchFilter = "name";
      this.patientService.updateTriggerHeaderSearch(false);
      if (!!this.patientSearch.searchKeyword) {
        this.searchPatient();
      }
    }
  }

  toggleDisplayAllRecords() {
    if (this.isShowAllRec) {
      this.patientSearch.searchKeyword = "";
      this.patientSearch.searchFilter ="all";
      this.searchPatient();
    } else {
      this.patientSearch.searchFilter = "name";
    }
  }


  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  
  searchPatient() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.clearNoRecordError();
    this.isProcessing = true;
    const _userSession = this.authService.getUserLoggedIn();
    this.patientSearch.companyId = _userSession.companyId;
    let ret = this.dataService
      .postData(this.patientSearch, APIUrls.SearchPatients)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: PatientSearchResult[] = data;
          this.patients = response;
          if (this.patients.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );

  }

  getContactById(contactTypeVal: string, contacts: Contact[]): string {
    return this.helperService.getContactById(contactTypeVal, contacts);
  }

  getCombinedAddress(_data: any) {
    return this.helperService.getCombinedAddress(_data);
  }

  selectPatient(patient: PatientSearchResult) {
    this.router.navigateByUrl(`patient/detail/${patient.id}`);
  }
}
