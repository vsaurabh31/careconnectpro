import { Component, OnInit } from '@angular/core';
import { BaseComponent } from '../../../shared/core/base.component';
import { ActivatedRoute, Router } from '@angular/router';
import { DataService, AlertService, AuthService, PatientService } from 'service-lib';
import { UserSession, AlertType, Patient, APIUrls, WindowSize } from 'model-lib';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: 'app-patient-detail',
  templateUrl: './patient-detail.component.html',
  styleUrls: ['./patient-detail.component.scss']
})
export class PatientDetailComponent extends BaseComponent implements OnInit {
  userSession: UserSession = {};
  isProcessing = false;
  patient: Patient = {};
  windowSize: WindowSize = {};

  constructor(
    private router: Router,
    private activeRoute: ActivatedRoute,
    private dataService: DataService,
    private alertService: AlertService,
    private authService: AuthService,
    private patientService: PatientService
  ) {
    super();
  }

  ngOnInit(): void {
    this.windowSize.screenType = "Desktop";

    this.alertService.windowSize$.pipe(takeUntil(this.destroy$)).
    subscribe(val => {
      this.windowSize = val;
    });
    this.patient = {};
    this.patientService.updatePatient(this.patient);
    this.userSession = this.authService.getUserLoggedIn();
    this.parseUrlQuery();
  }

  isScreenSize(screenType: string) {
    return screenType==this.windowSize.screenType;
  }


  parseUrlQuery() {
    this.activeRoute.params.subscribe(parms => {
      const patientId: string = parms['id'];

      if (patientId != null) {
        this.dbGetPatient(patientId);
      } else {
        this.returnPatientSearch();
      }
    });
  }

  onTabClick(evt: any) {
    alert("got it");
  }
  returnPatientSearch() {
    this.alertService.displayErrorMessage(AlertType.Toast, '',
      "Patient record doesn't exist.");
    this.router.navigateByUrl("patient/manage");
  }

  dbGetPatient(patientId: string) {
    this.isProcessing = true;
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: Patient;
    let ret = this.dataService
      .getSingleData(
        response,
        patientId,
        APIUrls.Patient
      )
      .finally(() => {
       this.alertService.showSpinner(false);
        this.isProcessing = false;
      })
      .subscribe(
        (data: Patient) => {
          if (!!data.id) {
            this.patient = data;
            this.patientService.updateInTakeMode(false);
            this.patientService.updatePatient(this.patient);
          } else {
            this.returnPatientSearch();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
          this.returnPatientSearch();
        }
      );
  }

}
