import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BillingSetupComponent } from './setup/billing-setup.component';
import { BillingHistoryComponent } from './history/billing-history.component';
import { BillingProcessComponent } from './process/billing-process.component';
import { RouterModule, Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    component: BillingHistoryComponent,
    children: [
      { path: 'history', component: BillingHistoryComponent },
      { path: 'setup', component: BillingSetupComponent },
      { path: 'process', component: BillingProcessComponent }
    ]
  }
];

@NgModule({
  declarations: [BillingSetupComponent, BillingHistoryComponent, BillingProcessComponent],
  imports: [
    CommonModule, RouterModule.forChild(routes)
  ]
})
export class BillingModule { }
