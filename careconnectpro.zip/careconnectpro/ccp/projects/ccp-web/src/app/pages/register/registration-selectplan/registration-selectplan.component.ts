import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BaseComponent } from '../../../shared/core/base.component';
import { CompanySubscription, SubscriptionPackage } from 'model-lib';
import { SubscriptionService } from 'service-lib';

@Component({
  selector: 'app-registration-selectplan',
  templateUrl: './registration-selectplan.component.html',
  styleUrls: ['./registration-selectplan.component.scss']
})
export class RegistrationSelectPlanComponent extends BaseComponent
  implements OnInit {
  companySubscription: CompanySubscription = {};
  subscriptionPackages: SubscriptionPackage[] = [];

  constructor(
    private router: Router,
    private subscriptionService: SubscriptionService
  ) {
    super();
  }

  ngOnInit(): void {
    this.validateRegistrationStage();
    this.subscriptionPackages = this.subscriptionService.getSubscriptionPackages();
  }

  getSubscriptionPackagePrice(pkgName: string) {
    return this.subscriptionService.getSubscriptionPackagePrice(pkgName);
  }

  selectSubscriptionPackage(pkgName: string) {
    if (!!pkgName) {
      let _package = this.subscriptionPackages.filter(
        x => x.packageName.toLowerCase() == pkgName.toLowerCase()
      );
      if (_package.length > 0) {
        this.companySubscription.packageId = _package[0].packageName;
        this.subscriptionService.setCompanySubscription(
          this.companySubscription
        );
      }
    }
    this.showPayment();
  }

  validateRegistrationStage() {
    let _isContinue: boolean = false;
    let _companyRegistration = this.subscriptionService.getCompanyRegistration();
    if (
      !!_companyRegistration.userName &&
      !!_companyRegistration.password &&
      !!_companyRegistration.password2 &&
      _companyRegistration.password == _companyRegistration.password2 &&
      !!_companyRegistration.confirmToken
    ) {
      _isContinue = true;
    }

    if (!_isContinue) {
      this.redirectRegistration();
    }
  }

  redirectRegistration() {
    this.router.navigateByUrl('landing/register/');
  }

  showPayment() {
    this.router.navigateByUrl('landing/register/payment');
  }
}
