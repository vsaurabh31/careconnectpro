import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { OasisFormComponent } from './oasis/c2/oasis-form.component';
import { TaskManagementComponent } from './task-management.component';
import { TaskManagementHeaderComponent } from './header/task-management-header.component';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from '../../shared/shared.module';
import { Cms485PlanOfCareComponent } from './planofcare/cms485/cms485-plan-of-care.component';
import { SkilledNurseNoteComponent } from './visit-notes/skilled-nurse/skilled-nurse-note.component';
import { MytaskComponent } from './mytask/mytask.component';
import { AgencyTaskComponent } from './agencytask/agency-task.component';
import { EpisodeTaskModalComponent } from './modal/task/episode-task-modal.component';

export const routes: Routes = [
  {
    path: '',
    component: TaskManagementComponent,
    children: [
      { path: 'oasis/:id', component: OasisFormComponent },
      { path: 'oasis', component: OasisFormComponent },
      { path: 'planofcare', component: Cms485PlanOfCareComponent },
      { path: 'planofcare/:id', component: Cms485PlanOfCareComponent },
      { path: 'snnote', component: SkilledNurseNoteComponent },
      { path: 'snnote/:id', component: SkilledNurseNoteComponent },
      { path: 'mytasks', component: MytaskComponent },
      { path: 'agencytasks', component: AgencyTaskComponent }
    ]
  }
];

@NgModule({
  imports: [CommonModule, SharedModule, RouterModule.forChild(routes)],
  declarations: [OasisFormComponent, TaskManagementComponent, TaskManagementHeaderComponent, 
    Cms485PlanOfCareComponent, SkilledNurseNoteComponent, MytaskComponent, AgencyTaskComponent, EpisodeTaskModalComponent],

})
export class TaskManagementModule { }
