import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AlertType, APIUrls, EpisodeSearchResult, GenericSearch, Status } from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, EpisodeService } from 'service-lib';
import { BaseComponent } from '../../../shared/core/base.component';
import { EpisodeVisitListComponent } from '../modal/visit/episode-visit-list.component';

@Component({
  selector: 'app-episode-search',
  templateUrl: './episode-search.component.html',
  styleUrls: ['./episode-search.component.scss']
})
export class EpisodeSearchComponent extends BaseComponent implements OnInit {
  episodeSearchKeyword: string = "";
  isProcessing: boolean = false;
  episodes: EpisodeSearchResult[] = [];
  showNoRecordFound: boolean = false;
  episodeSearch: GenericSearch = { searchFilter: "patientname" };
  isShowAllRec: boolean = false;

  constructor(
    private dialog: MatDialog,
    private alertService: AlertService,
    private dataService: DataService,
    private authService: AuthService,
    private episodeService: EpisodeService,
    private router: Router
  ) { 
    super();
  }

  ngOnInit(): void {
    this.episodeSearch.searchFilter = "patientname";
    this.episodeService.executeEpisodeSearch$.pipe(takeUntil(this.destroy$))
    .subscribe(val => {
      const isHeaderSearch= this.episodeService.getTriggerHeaderSearch();
      if (val &&  isHeaderSearch) {
        const isHeaderSearch = this.episodeService.getTriggerHeaderSearch();
        this.episodeSearch = this.episodeService.getSearchKeyword();
        this.episodeSearch.searchFilter = "mrn";
        this.episodeService.updateTriggerHeaderSearch(false);
        if (!!this.episodeSearch.searchKeyword) {
          this.isShowAllRec = false;
          this.searchEpisode();
        }
      }
    });
    this.episodeSearch = this.episodeService.getSearchKeyword();
    const isHeaderSearch= this.episodeService.getTriggerHeaderSearch();
    if (!!this.episodeSearch && isHeaderSearch) {
      this.episodeSearch.searchFilter = "mrn";
      this.episodeService.updateTriggerHeaderSearch(false);
      if (!!this.episodeSearch.searchKeyword) {
        this.searchEpisode();
      }
    }
  }

  toggleDisplayAllRecords() {
    if (this.isShowAllRec) {
      this.episodeSearch.searchKeyword = "";
      this.episodeSearch.searchFilter ="all";
      this.searchEpisode();
    } else {
      this.episodeSearch.searchFilter = "patientname";
    }
  }


  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  sortEpisode() {
    this.episodes.sort((a, b) => {
      return +new Date(b.startOfCare) - +new Date(a.startOfCare)
    });
  }
  
  searchEpisode() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.clearNoRecordError();
    this.isProcessing = true;
    const _userSession = this.authService.getUserLoggedIn();
    this.episodeSearch.companyId = _userSession.companyId;
    let ret = this.dataService
      .postData(this.episodeSearch, APIUrls.SearchEpisodes)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: EpisodeSearchResult[] = data;
          this.episodes = response;
          this.sortEpisode();
          if (this.episodes.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

 selectEpisode(_episode: EpisodeSearchResult) {
    this.router.navigateByUrl(`episode/detail/${_episode.id}`);
  }

  openVisitsDialog(val: EpisodeSearchResult) {
    if (val.visits == 0) {
      this.alertService.displayWarningMessage(AlertType.Toast, "", "No visits are scheduled for this episode");
      return;
    }
      const dialogRef = this.dialog.open(EpisodeVisitListComponent, {
        data: { title: val.patientName, value: val.id },
      });
      dialogRef.afterClosed().subscribe((result) => {});
  }

  selectPatient(_episode: EpisodeSearchResult) {
    this.router.navigateByUrl(`patient/detail/${_episode.patientId}`);
  }
  
  getStatusColor(status: string) {
    switch(status) {        
      case Status.IN_PROGRESS:
      case Status.ACTIVE:
          return 'primary';
      case Status.ONHOLD:
          return 'warn';      
    }
  }
}
