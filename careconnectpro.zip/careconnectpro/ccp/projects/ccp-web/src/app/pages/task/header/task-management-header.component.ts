import { Component, Input, OnInit, SimpleChange } from '@angular/core';
import { Router } from '@angular/router';
import { CompanyTask, Episode, Patient, Status, GenericIdValue, TaskType, DocumentTypeConstants, TaskDocumentSections, OasisWorkflowDocumentType, GenericWorkflowDocumentType, TaskDocument } from 'model-lib';
import { HelperService, TaskManagementService } from 'service-lib';
import { BaseComponent } from '../../../../app/shared/core/base.component';

@Component({
  selector: 'app-task-management-header',
  templateUrl: './task-management-header.component.html',
  styleUrls: ['./task-management-header.component.scss']
})
export class TaskManagementHeaderComponent extends BaseComponent implements OnInit {
  patientName: string = "";
  @Input() episode: Episode = {};
  @Input() patient: Patient = {};
  @Input() companyTask: CompanyTask = {};
  documentSection: string;
  isDocumentComplete: boolean = false;
  documentCategories: GenericIdValue[] = [];
  documentName: string;
  taskDocument: TaskDocument = {};

  constructor(
    private helperService: HelperService,
    private router: Router,
    private taskManagementService: TaskManagementService
  ) {
    super();
  }

  ngOnInit(): void {
    this.documentName = this.taskManagementService.getActiveWorkflowDocument();
    this.getPatientFullName();
    if (!this.companyTask.id) {
      this.companyTask.status = Status.OPEN;
    }
    this.getDocumentCategories();
  }

  getPatientFullName() {
    this.patientName = this.helperService.getPersonCombinedFullName(this.patient);
  }

  ngOnChanges(change: SimpleChange) {
    this.getPatientFullName();
  }

  openPatientRecord() {
    this.router.navigateByUrl(`patient/detail/${this.patient.id}`);
  }

  openEpisodeRecord() {
    this.router.navigateByUrl(`episode/detail/${this.episode.id}`);
  }

  getStatusColor(status: string) {
    switch (status) {
      case Status.IN_PROGRESS:
      case Status.ACTIVE:
        return 'primary';
      case Status.ONHOLD:
        return 'warn';
    }
  }

  getDocumentCategories() {
    switch (this.documentName) {
      case GenericWorkflowDocumentType.VISITATION_NOTE_SKILLED_NURSE:
        this.documentCategories = TaskDocumentSections.SKILLED_NURSE_VISITATION_NOTE.map(x => {
          return { id: x.id, value: x.name }
        });
        break;
      case GenericWorkflowDocumentType.EPISODE_PLAN_OF_CARE:
        this.documentCategories = TaskDocumentSections.PLAN_OF_CARE.map(x => {
          return { id: x.id, value: x.name }
        });
        break;
      case OasisWorkflowDocumentType.DISCHARGE_FROM_AGENCY_DEATH:
      case OasisWorkflowDocumentType.DISCHARGE_FROM_AGENCY:
        this.documentCategories = TaskDocumentSections.OASIS_DISCHARGE.map(x => {
          return { id: x.id, value: x.name }
        });
        break;
      case OasisWorkflowDocumentType.TRANSFER_IN_PATIENT_FACILITY:
        this.documentCategories = TaskDocumentSections.OASIS_TRANSFER.map(x => {
          return { id: x.id, value: x.name }
        });
        break;
      case OasisWorkflowDocumentType.START_OF_CARE:
        this.documentCategories = TaskDocumentSections.OASIS_START_OF_CARE.map(x => {
         return { id: x.id, value: x.name }
        });
        break;
      case OasisWorkflowDocumentType.RESUMPTION_OF_CARE:
        this.documentCategories = TaskDocumentSections.OASIS_RESUMPTION_OF_CARE.map(x => {
         return { id: x.id, value: x.name }
        });
        break;
      case OasisWorkflowDocumentType.RECERTIFICATION_FOLLOWUP:
        this.documentCategories = TaskDocumentSections.OASIS_FOLLOW_UP.map(x => {
         return { id: x.id, value: x.name }
        });
        break;
    }
  }

  jumpToSection() {
    this.taskManagementService.updateDocumentSection(this.documentSection);
  }

  saveDraft() {
    this.taskManagementService.saveDocumentDraft();
  }

  completeDocument() {
    this.taskManagementService.CompleteDocument();
  }
}
