import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CompanyEventComponent } from './company-event.component';

describe('CompanyEventComponent', () => {
  let component: CompanyEventComponent;
  let fixture: ComponentFixture<CompanyEventComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CompanyEventComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CompanyEventComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
