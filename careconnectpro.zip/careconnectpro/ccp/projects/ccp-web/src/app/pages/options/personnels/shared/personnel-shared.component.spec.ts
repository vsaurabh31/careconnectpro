import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonnelSharedComponent } from './personnel-shared.component';

describe('PersonnelSharedComponent', () => {
  let component: PersonnelSharedComponent;
  let fixture: ComponentFixture<PersonnelSharedComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonnelSharedComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonnelSharedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
