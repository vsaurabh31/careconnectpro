import { Component, OnInit } from '@angular/core';
import {
  MatDialog,
  MatDialogRef,
  MAT_DIALOG_DATA,
} from '@angular/material/dialog';
import { ConfirmDeleteComponent } from '../../../shared/modal/confirm-delete/confirm-delete.component';
import { BroadcastMessageComponent } from '../../../shared/modal/broadcast-message/broadcast-message.component';
import { BroadcastComposeComponent } from '../../../shared/modal/broadcast-compose/broadcast-compose.component';
import { BaseComponent } from '../../../shared/core/base.component';
import { AlertType, APIUrls, EmployeeName, SystemBroadcastDetail, SystemBroadcastHeader, UserSession } from 'model-lib';
import { AlertService, AppMessageService, AuthService, DataService, HelperService, MediaService } from 'service-lib';
import { takeUntil } from 'rxjs/operators';
@Component({
  selector: 'app-broadcast',
  templateUrl: './broadcast.component.html',
  styleUrls: ['./broadcast.component.scss'],
})
export class BroadcastComponent extends BaseComponent implements OnInit {
  broadcasts: SystemBroadcastHeader[] = [];
  selectedBroadcast: SystemBroadcastHeader[] = [];
  userSession: UserSession;
  cols: any[];
  employeeNames: EmployeeName[] = [];
  constructor(
    private helperService: HelperService,
    private alertService: AlertService,
    private dataService: DataService,
    private authService: AuthService,
    private mediaSvc: MediaService,
    private appMessageServie: AppMessageService,
    public dialog: MatDialog) {
    super();
  }

  ngOnInit() {
    this.appMessageServie.broadcastMessageSent$.pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        if (val) {
          this.initData();
        }
      })
    this.initData();
  }

  initData() {
    this.dbGetAllEmployeeNames();
  }

  openComposeDialog() {
    const dialogRef = this.dialog.open(BroadcastComposeComponent, {});
  }

  openMesssageDetailDialog(broadcastMessage: SystemBroadcastDetail) {
    const dialogRef = this.dialog.open(BroadcastMessageComponent, {
      data: broadcastMessage,
    });    
  }


  openDeleteDialog(id): void {
    const dialogRef = this.dialog.open(ConfirmDeleteComponent, { data: id });
    dialogRef.afterClosed().subscribe((result) => { 
      if ((!!result.response) && (result.response)) {
        this.dbDeleteBroadcastMessage(id);
      }
    });
  }

  dbGetSingleMessage(messageId: string) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: SystemBroadcastDetail;
    let ret = this.dataService
      .getSingleData(
        response,
        messageId,
        APIUrls.SystemBroadcast
      )
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (data: SystemBroadcastDetail) => {
          if (!!data) {
            this.openMesssageDetailDialog(data);
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  dbDeleteBroadcastMessage(messageId: string) {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: SystemBroadcastDetail;
    let ret = this.dataService
      .deleteData(
        messageId,
        APIUrls.SystemBroadcast
      )
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (data) => {
          if (!!data) {
            this.initData();
            this.alertService.displaySuccessMessage(AlertType.Toast, "", "Broadcast Message deleted successfully")
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }


  dbGetAllBroadcast() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: SystemBroadcastHeader;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.SystemBroadcast
      )
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (data: SystemBroadcastHeader[]) => {
          if (!!data) {
            this.broadcasts = [...data];
            this.broadcasts.sort((a,b) => {
              return +new Date(b.dateCreated) - +new Date(a.dateCreated)
            })
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }

  getEmployeeImage(employeeId) {
    const photoName: string = this.getEmployeePhoto(employeeId);
    let imgSrc: string = "";
    if (photoName != "") {
      imgSrc = APIUrls.GetImageEmployee + "/" + photoName;
    } else {
      imgSrc = this.mediaSvc.defaultUserImage;
    }
    return imgSrc;
  }

  getEmployeePhoto(employeeId: string) {
    let ret: string = "";
    const x = this.employeeNames.findIndex(
      y => y.id === employeeId
    );
    if (x > -1) {
      ret = this.employeeNames[x].photoName;
    }
    return ret;
  }

  // formatDate(dateIn: Date) {
  //   let dateFormat = require("dateformat");
  //   return dateFormat(dateIn, "dddd, mmmm dS, yyyy, h:MM:ss TT");
  // }

  getEmployeeFullName(employeeId: string) {
    let ret: string = "";
    const x = this.employeeNames.findIndex(
      y => y.id === employeeId
    );
    if (x > -1) {
      ret = this.employeeNames[x].name;
    }
    return ret;
  }

  dbGetAllEmployeeNames() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.alertService.showSpinner(true);
    let response: SystemBroadcastHeader;
    let ret = this.dataService
      .getAllData(
        response,
        "",
        APIUrls.EmployeeGetAllEmployeeNamesByCompanyId
      )
      .finally(() => {
        this.alertService.showSpinner(false);
      })
      .subscribe(
        (data: EmployeeName[]) => {
          if (!!data) {
            this.employeeNames = [...data];
            this.dbGetAllBroadcast();
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
}
