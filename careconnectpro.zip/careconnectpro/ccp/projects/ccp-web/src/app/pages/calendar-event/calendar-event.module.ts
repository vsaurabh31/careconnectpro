import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CompanyEventComponent } from './company/company-event.component';
import { PersonalEventComponent } from './personal/personal-event.component';
import { Routes, RouterModule } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    component: CompanyEventComponent,
    children: [
      { path: 'company', component: CompanyEventComponent },
      { path: 'personal', component: PersonalEventComponent }
    ]
  }
];

@NgModule({
  declarations: [CompanyEventComponent, PersonalEventComponent],
  imports: [
    CommonModule, RouterModule.forChild(routes)
  ]
})
export class CalendarEventModule { }
