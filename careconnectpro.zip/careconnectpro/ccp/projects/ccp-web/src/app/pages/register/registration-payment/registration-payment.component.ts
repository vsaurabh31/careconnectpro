import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { PaymentConfirmComponent } from '../../../shared/modal/payment-confirm/payment-confirm.component';
import { BaseComponent } from '../../../shared/core/base.component';
import {
  SubscriptionService,
  DataService,
  BillingService,
  AlertService,
  AppHtmlControlService,
  CareConnectLocalStorage,
  NotificationsService
} from 'service-lib';
import {
  CompanySubscription,
  SubscriptionPackage,
  UserPaymentInfo,
  APIUrls,
  GenericEmailMessage,
  AlertType,
  AppMessage,
  UserSignup,
  AppConstants,
  BaseApiResponse,
  UserLogin
} from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import 'rxjs/add/operator/finally';

@Component({
  selector: 'app-registration-payment',
  templateUrl: './registration-payment.component.html',
  styleUrls: ['./registration-payment.component.scss']
})
export class RegistrationCompleteComponent extends BaseComponent
  implements OnInit {
  companySubscription: CompanySubscription = {};
  subscriptionPackages: SubscriptionPackage[] = [];
  taxAmount: number = 0;
  packageUnitAmount: number = 0;
  paymentInformation: UserPaymentInfo = { totalMonths: 1 };
  ccMonthYear: string = '';
  webServerUrl: string = APIUrls.GetWebAppRootUrl;
  activationEmail: GenericEmailMessage = {};
  isProcessing: boolean = false;
  paymentComplete: boolean = false;
  userLogin: UserLogin = {};

  constructor(
    private router: Router,
    public dialog: MatDialog,
    private subscriptionService: SubscriptionService,
    private dataService: DataService,
    private billingService: BillingService,
    private alertService: AlertService,
    private appHtmlControl: AppHtmlControlService,
    private localStore: CareConnectLocalStorage,
    private notifyService: NotificationsService
  ) {
    super();
    this.paymentInformation.totalMonths = 1;
  }

  ngOnInit(): void {
    this.validateRegistrationStage();
    this.companySubscription = this.subscriptionService.getCompanySubscription();
    this.subscriptionPackages = this.subscriptionService.getSubscriptionPackages();
    this.calculateTotalPkgAmount();
    this.subscriptionService.companySubscription$
      .pipe(takeUntil(this.destroy$))
      .subscribe(val => {
        this.paymentInformation.totalMonths = 1;
        this.companySubscription = val;
        this.calculateTotalPkgAmount();
      });
  }

  displayConfirmationOpenApp() {
    this.isProcessing = false;
    this.paymentComplete = true;
    this.dialog.open(PaymentConfirmComponent);
  }

  validateRegistrationStage() {
    let _isContinue: boolean = false;
    let _companyRegistration = this.subscriptionService.getCompanyRegistration();
    if (
      !!_companyRegistration.userName &&
      !!_companyRegistration.password &&
      !!_companyRegistration.password2 &&
      _companyRegistration.password == _companyRegistration.password2 &&
      !!_companyRegistration.confirmToken
    ) {
      _isContinue = true;
    }

    if (!_isContinue) {
      this.redirectRegistration();
    }
  }

  redirectRegistration() {
    this.router.navigateByUrl('landing/register/');
  }

  getPackageUnitAmount() {
    return this.subscriptionService.getSubscriptionPackagePrice(
      this.companySubscription.packageId
    );
  }

  calculateTotalPkgAmount() {
    if (this.paymentInformation.totalMonths < 1) {
      this.paymentInformation.totalMonths = 1;
    }
    this.companySubscription.totalAmount =
      this.getPackageUnitAmount() *
      this.paymentInformation.totalMonths *
      (1 + AppConstants.DefaultTaxRate);
    this.paymentInformation.totalAmount = this.companySubscription.totalAmount;
    this.companySubscription.startDate = new Date();
    let _endDate = new Date();
    let _months: number = +this.paymentInformation.totalMonths;
    if (this.getPackageUnitAmount() == 0) {
      _endDate.setMonth(this.companySubscription.startDate.getMonth() + 1);
    } else {
      _endDate.setMonth(
        this.companySubscription.startDate.getMonth() + _months
      );
    }
    this.companySubscription.endDate = _endDate;
  }

  getTaxAmount(): number {
    if (!this.companySubscription) {
      return 0;
    }
    return (
      this.getPackageUnitAmount() *
      this.paymentInformation.totalMonths *
      AppConstants.DefaultTaxRate
    );
  }

  submitForm() {
    this.isUserNameExist();
  }

  formatCcNumber(keyPressed: any): void {
    this.paymentInformation.cardNumber = this.appHtmlControl.formatCcNumber(
      this.paymentInformation.cardNumber
    );
  }

  showCreditCard(): boolean {
    if (
      !!this.companySubscription.packageId &&
      this.companySubscription.packageId.toLocaleLowerCase() == 'trial'
    ) {
      return false;
    } else {
      return true;
    }
  }

  submitPayment(): void {
    this.paymentInformation = this.billingService.processPayment(
      this.paymentInformation
    );
    this.subscriptionService.setPaymentInfo(this.paymentInformation);
    this.alertService.displaySuccessMessage(
      AlertType.Toast,
      'Payment',
      'Processed successfully!'
    );
    this.registerCompany();
  }

  isUserNameExist() {
    this.isProcessing = true;
    let _companyRegistration = this.subscriptionService.getCompanyRegistration();
    let request: any;
    let ret = this.dataService
      .getSingleData(
        request,
        _companyRegistration.userName,
        APIUrls.AccountValidateUsername
      )
      .finally(() => {})
      .subscribe(
        data => {
          let ret: boolean = data;
          if (ret) {
            this.isProcessing = false;
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.RegisterLoginUserNameExist
            );
          } else {
            this.submitPayment();
          }
        },
        error => {
          this.isProcessing = false;
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
      );
  }

  GetLoginToken(_companyId: string) {
    const companyRegistration = this.subscriptionService.getCompanyRegistration();
    this.userLogin.userName = companyRegistration.userName;
    this.userLogin.password = companyRegistration.password;
    this.isProcessing = true;
    this.alertService.showSpinner(true);
    const apiResponse: BaseApiResponse = {};
    let ret = this.dataService
      .getSingleDataUsingUrlParams(apiResponse, APIUrls.AccountLoginUser, this.userLogin)
      .finally(() => {
        this.isProcessing = false;
        this.alertService.showSpinner(false);
      })
      .subscribe(
        data => {
          const response: BaseApiResponse = data;
          if (response.isSucceeded) {
            this.localStore.storeAuthToken(response.responseMessage);
            this.notifyService.clearNotificationLocalStorage();
            this.SaveSubscription(_companyId);
          } else {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              AppMessage.LoginFailedUserOrPasswordIncorrect
            );
          }
        },
        error => {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
      );
  }


  registerCompany() {
    this.isProcessing = true;
    let request: UserSignup = {};
    let _companyRegistration = this.subscriptionService.getCompanyRegistration();
    let ret = this.dataService
      .postData(_companyRegistration, APIUrls.AccountRegisterCompany)
      .finally(() => {})
      .subscribe(
        data => {
          if (data != undefined) {
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              'Account',
              'Created successfully!'
            );
            let _companyId = data.companyId;
            this.GetLoginToken(_companyId);
          }
        },
        error => {
          this.isProcessing = false;
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
      );
  }

  SaveSubscription(companyId: string) {
    this.isProcessing = true;
    let _companySubscription = this.subscriptionService.getCompanySubscription();
    _companySubscription.companyId = companyId;
    let ret = this.dataService
      .postData(_companySubscription, APIUrls.CompanySubscriptionsApi)
      .finally(() => {})
      .subscribe(
        data => {
          if (data != undefined) {
            _companySubscription.id = data.id;
            this.subscriptionService.setCompanySubscription(
              _companySubscription
            );
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              'Subscription',
              'Added successfully!'
            );
            this.SendActivationEmail();
          }
        },
        error => {
          this.isProcessing = false;
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
      );
  }

  GetMessageTemplate(): string {
    let _company = this.subscriptionService.getCompanySubscription();
    let _companyRegistration = this.subscriptionService.getCompanyRegistration();
    const msg = `<div class="PlainText">Congratulations! - Welcome to Care Connect Pro.<br><br>
      Company name: ${_companyRegistration.companyName} <br>
      Administrator Username: ${_companyRegistration.userName} <br>
      Subscription Type: ${_company.packageId} <br>
      Subscription Number: ${_company.id} <br>
      Amount charged:$${_company.totalAmount} <br>
      Start Date: ${_company.startDate} <br>
      End Date: ${_company.endDate} <br><br>
     
      <br>
      Thank you, <br>
      <br>
      Care Connect Pro Support
      <br>
      1-(800) 771-3642
      <br>
      info@careconnectpro.com
      <br>
    </div>`;
    return msg;
  }

  SendActivationEmail() {
    this.isProcessing = true;
    let _company = this.subscriptionService.getCompanyRegistration();
    let _companySubscription = this.subscriptionService.getCompanySubscription();
    this.activationEmail.email = _company.email;
    this.activationEmail.msgContent = this.GetMessageTemplate();
    this.activationEmail.subject =
      'Care Connect Pro - New Account Registration Completed';
    this.activationEmail.token = _companySubscription.companyId;
    this.activationEmail.authCode = APIUrls.EmailAuthCode;

    let ret = this.dataService
      .postData(this.activationEmail, APIUrls.SendEmailApi)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          if (data != undefined) {
            this.alertService.displaySuccessMessage(
              AlertType.Toast,
              'Registration email',
              'sent successfully!'
            );
            this.displayConfirmationOpenApp();
          }
        },
        error => {
          this.alertService.displayErrorMessage(
            AlertType.Dialog,
            '',
            error
          );
        }
      );
  }
}
