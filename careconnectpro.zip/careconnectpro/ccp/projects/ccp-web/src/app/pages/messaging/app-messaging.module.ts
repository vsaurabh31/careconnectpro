import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppChatComponent } from './chat/app-chat.component';
import { NewMailComponent } from './mail/new-mail/new-mail.component';
import { ViewMailComponent } from './mail/view-mail/view-mail.component';
import { Routes, RouterModule } from '@angular/router';


export const routes: Routes = [
  {
    path: '',
    component: NewMailComponent,
    children: [
      { path: 'email', component: NewMailComponent},
      { path: 'view', component: ViewMailComponent },
      { path: 'chat', component: AppChatComponent }
    ]
  }
];


@NgModule({
  declarations: [AppChatComponent, NewMailComponent, ViewMailComponent],
  imports: [
    CommonModule, RouterModule.forChild(routes)
  ]
})
export class AppMessagingModule { }
