import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billing-process',
  templateUrl: './billing-process.component.html',
  styleUrls: ['./billing-process.component.scss']
})
export class BillingProcessComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
