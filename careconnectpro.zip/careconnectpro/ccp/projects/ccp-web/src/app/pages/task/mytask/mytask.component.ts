import { Component, Input, OnInit, SimpleChange } from '@angular/core';
import { Router } from '@angular/router';
import {
  APIUrls, Episode, TaskSearchResult, GenericSearch, AlertType, UserSession,
  DocumentTypeConstants, GenericWorkflowDocumentType, OasisWorkflowDocumentType, DocumentType, Status
} from 'model-lib';
import { takeUntil } from 'rxjs/operators';
import { AlertService, AuthService, DataService, EpisodeService, TaskManagementService } from 'service-lib';
import { BaseComponent } from '../../../../app/shared/core/base.component';

@Component({
  selector: 'app-mytask',
  templateUrl: './mytask.component.html',
  styleUrls: ['./mytask.component.scss']
})
export class MytaskComponent extends BaseComponent implements OnInit {

  isProcessing: boolean = false;
  showNoRecordFound: boolean = false;
  taskSearch: GenericSearch = { searchFilter: "mytask" };
  isShowAllRec: boolean = false;
  @Input() isAddMode: boolean;
  @Input() episode: Episode = {};
  @Input() employeeNames: Map<string, string>;
  @Input() companyServices: Map<string, string>;
  tasks: TaskSearchResult[] = [];
  docTypes: DocumentType[] = [];

  constructor(
    private router: Router,
    private alertService: AlertService,
    private dataService: DataService,
    private authService: AuthService,
    private taskManagementService: TaskManagementService
  ) {
    super();
  }

  ngOnInit(): void {
    const userSession = this.authService.getUserLoggedIn();
    if (!!userSession) {
      this.taskSearch.searchKeyword = userSession.employeeId;
      this.getDbTasks();
    }

    this.authService.userSession$.pipe(takeUntil(this.destroy$))
      .subscribe((data: UserSession) => {
        if (!!data.companyId) {
          this.taskSearch.searchKeyword = data.employeeId;
          this.getDbTasks();
        }
      });
    this.dbGetDocumentTypes();
  }


  ngOnChanges(changes: SimpleChange) { }

  clearNoRecordError() {
    this.showNoRecordFound = false;
  }

  sortTasks() {
    this.tasks.sort((a, b) => {
      return +new Date(a.dueDate) - +new Date(b.dueDate)
    });
  }

  getDbTasks() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.clearNoRecordError();
    this.isProcessing = true;
    let ret = this.dataService
      .postData(this.taskSearch, APIUrls.SearchTasks)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: TaskSearchResult[] = data;
          this.tasks = response;
          this.sortTasks();
          if (this.tasks.length == 0) {
            this.showNoRecordFound = true;
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
  selectPatient(episodeTask: TaskSearchResult) {
    this.router.navigateByUrl(`patient/detail/${episodeTask.patientId}`);
  }
  openClickAddTask() { }

  openTask(_task: TaskSearchResult) {
    const docType = this.docTypes.filter(x => x.id == _task.documentTypeId);
    if (!docType) {
      return
    }
    switch (docType[0].name) {
      case DocumentTypeConstants.SKILLED_NURSE_VISIT_NOTE:
        this.taskManagementService.updateActiveWorkflowDocument(GenericWorkflowDocumentType.VISITATION_NOTE_SKILLED_NURSE);
        this.taskManagementService.updateActivePatient(_task.patientId);
        this.taskManagementService.updateActiveEpisode(_task.episodeId);
        this.router.navigateByUrl(`task/snnote/${_task.id}`);
        break;
      case DocumentTypeConstants.EPISODE_PLAN_OF_CARE:
        this.taskManagementService.updateActiveWorkflowDocument(GenericWorkflowDocumentType.EPISODE_PLAN_OF_CARE);
        this.taskManagementService.updateActivePatient(_task.patientId);
        this.taskManagementService.updateActiveEpisode(_task.episodeId);
        this.router.navigateByUrl(`task/planofcare/${_task.id}`);
        break;
      case DocumentTypeConstants.OASIS_START_OF_CARE:
        this.taskManagementService.updateActiveWorkflowDocument(OasisWorkflowDocumentType.START_OF_CARE);
        this.taskManagementService.updateActivePatient(_task.patientId);
        this.taskManagementService.updateActiveEpisode(_task.episodeId);
        this.router.navigateByUrl(`task/oasis/${_task.id}`);
        break;
      case DocumentTypeConstants.OASIS_RECERTIFICATION_FOLLOWUP:
        this.taskManagementService.updateActiveWorkflowDocument(OasisWorkflowDocumentType.RECERTIFICATION_FOLLOWUP);
        this.taskManagementService.updateActivePatient(_task.patientId);
        this.taskManagementService.updateActiveEpisode(_task.episodeId);
        this.router.navigateByUrl(`task/oasis/${_task.id}`);
        break;
      default:
        break;
    }
  }

  dbGetDocumentTypes() {
    this.alertService.setDisplayExceptionAlertMsg(true);
    this.isProcessing = true;
    const docType: DocumentType = {};
    let ret = this.dataService
      .getAllData(docType, "", APIUrls.DocumentTypes)
      .finally(() => {
        this.isProcessing = false;
      })
      .subscribe(
        data => {
          const response: DocumentType[] = data;
          if (response.length > 0) {
            this.docTypes = response;
            this.taskManagementService.updateDocumentTypes(response);
          }
        },
        error => {
          if (this.alertService.getDisplayExceptionAlertMsg()) {
            this.alertService.displayErrorMessage(
              AlertType.Dialog,
              '',
              error
            );
          }
          this.alertService.setDisplayExceptionAlertMsg(false);
        }
      );
  }
  
  getStatusColor(status: string) {
    switch(status) {        
      case Status.IN_PROGRESS:
      case Status.ACTIVE:
          return 'primary';
      case Status.ONHOLD:
          return 'warn';      
    }
  }
}
