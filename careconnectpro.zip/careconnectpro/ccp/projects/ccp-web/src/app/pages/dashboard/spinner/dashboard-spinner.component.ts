import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-spinner',
  templateUrl: './dashboard-spinner.component.html',
  styleUrls: ['./dashboard-spinner.component.scss']
})
export class DashboardSpinnerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
