import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationSelectPlanComponent } from './registration-selectplan.component';

describe('RegistrationSubscribe2Component', () => {
  let component: RegistrationSelectPlanComponent;
  let fixture: ComponentFixture<RegistrationSelectPlanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RegistrationSelectPlanComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistrationSelectPlanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
