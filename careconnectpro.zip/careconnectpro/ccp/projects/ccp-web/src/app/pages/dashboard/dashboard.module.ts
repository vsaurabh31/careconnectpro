import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { DashboardCardComponent } from './card/dashboard-card.component';
import { Routes, RouterModule } from '@angular/router';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatCardModule } from '@angular/material/card';
import { MatMenuModule } from '@angular/material/menu';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { LayoutModule } from '@angular/cdk/layout';
import { IntakeSourceChartComponent } from './charts/intake-source-chart/intake-source-chart.component';
import { IntakeRegionChartComponent } from './charts/intake-region-chart/intake-region-chart.component';
import { AnnualIntakeChartComponent } from './charts/annual-intake-chart/annual-intake-chart.component';
import { IntakeServicesChartComponent } from './charts/intake-services-chart/intake-services-chart.component';
import { ChartsModule } from 'ng2-charts';
import { IntakeCasesTableComponent } from './tables/intake-cases-table/intake-cases-table.component';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSortModule } from '@angular/material/sort';
import { MatChipsModule }  from "@angular/material/chips";
import { MiniCardComponent } from './minicards/mini-card.component';
import {MatProgressSpinnerModule} from '@angular/material/progress-spinner';
import { DashboardSpinnerComponent } from './spinner/dashboard-spinner.component';

export const routes: Routes = [
  {
    path: '',
    component: DashboardComponent
  }
];


@NgModule({
  declarations: [
    DashboardComponent, 
    DashboardCardComponent,
    IntakeSourceChartComponent,
    IntakeRegionChartComponent,
    AnnualIntakeChartComponent,
    IntakeServicesChartComponent,
    IntakeCasesTableComponent,
    MiniCardComponent,
    DashboardSpinnerComponent
  ],
  imports: [
    CommonModule, 
    RouterModule.forChild(routes), 
    MatGridListModule, 
    MatCardModule, 
    MatMenuModule, 
    MatIconModule, 
    MatButtonModule, 
    LayoutModule,
    ChartsModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatChipsModule,
    MatProgressSpinnerModule
  ]
})
export class DashboardModule { }
