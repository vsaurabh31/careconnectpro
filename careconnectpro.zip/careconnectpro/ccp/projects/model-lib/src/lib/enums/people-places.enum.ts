export enum AddressType {
  mailingAddress,
  permanentAddress,
  alternateAddress,
  billingAddress
}

export enum ContactType {
  homePhone,
  workPhone,
  cellPhone,
  email,
  fax,
  url
}

export enum EmploymentType {
  fullTime,
  contract,
  partTime
}

export enum IdType {
  driversLicense,
  ssn,
  mrn,
  hrn,
  evvid,
  medicalLicenseId,
  npi,
  fedTaxId,
  hicn,
  medicareId,
  medicaidId,
  sandataAccountId,
  stateAccountId
}

export enum IdTypeEntity {
employee,
patient,
agency
}


export enum RaceType {
  AmericanIndianOrAlaskaNative,
  Asian,
  BlackOrAfricanAmerican,
  NativeHawaiianOrOtherPacificIslander,
  White,
  NotApplicable
}


