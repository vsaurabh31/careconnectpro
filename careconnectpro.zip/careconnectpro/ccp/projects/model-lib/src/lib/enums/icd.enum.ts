export enum IcdSearchType {
  Description,
  Icd
}
