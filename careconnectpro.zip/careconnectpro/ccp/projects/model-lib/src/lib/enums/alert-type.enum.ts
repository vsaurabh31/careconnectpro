export enum AlertSeverityType {
  Success,
  Error,
  Info,
  Warning
}

export enum AlertType {
  Toast,
  Message,
  Dialog
}
