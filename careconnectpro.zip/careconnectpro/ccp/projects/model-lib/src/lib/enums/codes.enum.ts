export enum CodesDefinition {
  AddrStates,
  ZipCodes,
  CCTypes,
  CCYear,
  AppAssets,
  AppUserType,
  GenderCode,
  PrefixCode,
  SalaryCode,
  SuffixCode,
  PracticeCode,
  ServiceCode
}
