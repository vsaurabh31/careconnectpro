export enum CreditCardType {
  Visa,
  MasterCard,
  AMEX,
  Discover
}
