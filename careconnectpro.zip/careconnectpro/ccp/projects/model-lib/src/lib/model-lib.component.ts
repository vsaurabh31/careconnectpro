import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-model-lib',
  template: `
    <p>
      model-lib works!
    </p>
  `,
  styles: []
})
export class ModelLibComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
