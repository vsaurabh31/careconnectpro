import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModelLibComponent } from './model-lib.component';

describe('ModelLibComponent', () => {
  let component: ModelLibComponent;
  let fixture: ComponentFixture<ModelLibComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ModelLibComponent]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModelLibComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
