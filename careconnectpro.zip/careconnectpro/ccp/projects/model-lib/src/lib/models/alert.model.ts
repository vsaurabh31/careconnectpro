import { AlertType, AlertSeverityType } from '../enums/alert-type.enum';

export interface Alert {
  type?: AlertSeverityType;
  message?: string;
}

export interface AppNotificationMessage {
  messageType?: AlertSeverityType;
  summary?: String;
  detail?: String;
}

export interface WindowSize {
  height?: number,
  width?: number,
  screenType?: string
}

