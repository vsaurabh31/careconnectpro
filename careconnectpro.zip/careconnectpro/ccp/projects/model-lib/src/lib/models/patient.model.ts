﻿import {
  People,
  Place,
  Address,
  Contact,
  Identification
} from './peopleplace.model';
import {
  PatientRelationshipType,
  AllergyType,
  InsuranceNetworkStatus,
  EmploymentType
} from '../enums';
import { BaseModel } from './base.model';
import { DecimalPipe } from '@angular/common';

export interface Patient extends People {
  id?: string;
  normalizedId?: string;
  companyId?: string;
  status?: string;
  primaryLocationId?: string;
  isActive?: boolean;
  isPatientGuarantor?: boolean;
  medPrograms?: MedProgram[];
  guarantors?:PatientGuarantor[];
  relatives?: PatientRelative[];
  employers?: PatientEmployer[];
  allergies?: PatientAllergy[];
  billingPreferenceId?: string;
  medications?: PatientMedication[];
  diagnosis?: PatientDiagnosis[];
  paymentProfiles?: PaymentProfile[];
  paymentTransactions?: PatientPaymentTransaction[];
  identifications?: PatientIdentification[];
  contacts?: PatientContact[];
  addresses?: PatientAddress[];
  extraDetails?: PatientExtraDetails[];
  governmentInsurance?: PatientGovernmentInsurance[];
  privateInsurance?: PatientMedicalInsurance[];
  referralProviders?: PatientReferralProvider[];
  referralPhysicians?: PatientReferralPhysician[];
  medicalHistory?: PatientMedicalHistory[];
  servicesRequested?: PatientServiceRequested[];
}

export interface PatientGovernmentInsurance extends BaseModel {
  id?: string;
  patientId?: string;
  insuranceTypeId?: string;
  memberId?: string;
  groupNumber?: string;
  effectiveDate?: Date;
  physicianId?: string;
  partA?: boolean;
  partB?: boolean;
  partC?: boolean;
  partD?: boolean;
}

export interface PatientMedicalHistory extends BaseModel {
  id?: string;
  patientId?: string;
  medicalHistoryTypeId?: string;
  icdId?: string;
  name?: string;
  value?: boolean;
  notes?: string;
}

export interface PatientReferralProvider extends BaseModel {
  id?: string;
  patientId?: string;
  providerId?: string;
  isPrimary?: boolean;
}

export interface PatientReferralPhysician extends BaseModel {
    id?: string;
    patientId?: string;
    physicianId?: string;
    isPrimary?: boolean;
}

export interface PatientDiagnosis extends BaseModel {
  id?: string;
  patientId?: string;
  icdId?: string;
  notes?: string;
  medProviderId?: string;
  physicianId?: string;
  condition?: string;
}

export interface PatientIdentification extends Identification {
  patientId?: string;
}

export interface PatientContact extends Contact {
  patientId?: string;
}

export interface PatientAddress extends Address {
  patientId?: string;
}

export interface PatientHeader {
  id?: string;
  normalizedId?: number;
  prefix?: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  suffix?: string;
  photoName?: string;
}

export interface PatientExtraDetails extends BaseModel {
    id?: string;
    patientId?: string;
    extraDetailId?: string;
    value?: string;
}

export interface PaymentProfile extends BaseModel {
  id?: string;
  patientId?: string;
  isPrimary?: boolean;
  paymentTypeId?: string;
  cardNumber?: string;
  cardTypeId?: string;
  cardCvv?: string;
  cardExpDate?: Date;
  bankRoutingNumber?: string;
  bankAccountNumber?: string;
  bankName?: string;
  notes?: string;
  billingFirstName?: string;
  billingLastName?: string;
  billingAddress1?: string;
  billingAddress2?: string;
  billingAddress3?: string;
  billingCity?: string;
  billingState?: string;
  billingZipCode?: string;
  billingCountry?: string;
}

export interface PatientServiceRequested extends BaseModel {
  id?: string;
  patientId?: string;
  serviceId?: string;
  notes?: string;
}


export interface MedProgram extends BaseModel {
  id?: string;
  patientId?: string;
  programId?: string;
  notes?: string;
}

export interface PatientGuarantor extends People {
  id?: string;
  patientId?: string;
  companyName?: string;
  taxId?: string;
  contacts?: PatientGuarantorContact[];
  addresses?: PatientGuarantorAddress[];
}

export interface PatientRelative extends People {
  id?: string;
  patientId?: string;
  relationshipId?: PatientRelationshipType;
  contacts?: PatientRelativeContact[];
  addresses?: PatientRelativeAddress[];
}

export interface PatientGuarantorContact extends Contact {
  guarantorId?: string;
}

export interface PatientGuarantorAddress extends Address {
  guarantorId?: string;
}

export interface PatientRelativeContact extends Contact {
  PatientRelativeId?: string;
}

export interface PatientRelativeAddress extends Address {
  PatientRelativeId?: string;
}

export interface PatientEmployer extends BaseModel {
  id?: string;
  companyName?: string;
  patientId?: string;
  employmentTypeId?: EmploymentType;
  name?: string;
  addresses?: PatientEmployerAddress[];
  contacts?: PatientEmployerContact[];
}

export interface PatientEmployerAddress extends Address {
  patientId?: string;
}

export interface PatientEmployerContact extends Contact {
  patientId?: string;
}

export interface PatientBillingPreference {
  patientId?: string;
  medicare?: boolean;
  selfPay?: boolean;
  insurance?: boolean;
  cardUpload?: boolean;
}

export interface PatientMedicalInsurance extends BaseModel {
  id?: string;
  patientId?: string;
  networkStatusId?: string;
  deductibleAmount?: number;
  referralRequired?: boolean;
  authorizationRequired?: boolean;
  effectiveDate?: Date;
  rx?: boolean;
  rxPcn?: string;
  authorizationCode?: string;
  rxBin?: string;
  subscriberName?: string;
  groupNumber?: string;
  memberId?: string;
  insuranceProviderId?: string;
  authorizationReceived?: boolean;
}

export interface PatientMedication extends BaseModel {
  id?: string;
  patientId?: string;
  icdId?: string;
  medName?: string;
  physicianId?: string;
  dosage?: string;
  frequency?: string;
  refills?: number;
  notes?: string;
}

export interface PatientPaymentTransaction extends BaseModel {
  id?: string;
  paymentProfileId?: string;
  patientId?: string;
  amount?: number;
  approvalCode?: string;
}

export interface PatientAllergy extends BaseModel {
  id?: string;
  patientId?: string;
  icdId?: string;
  allergyName?: string;
  value?: boolean;
  notes?: string;
}

export interface Allergies {
  id?: string;
  icdCode?: string;
  type?: AllergyType;
  description?: string;
}

export interface AppAllergies extends Allergies {
  isSelected?: boolean;
}

export interface PatientProvider extends Place {
  id?: string;
  patientId?: string;
}

export interface PatientReferralDoctor extends BaseModel {
  id?: string;
  patientId?: string;
  physicianId?: string;
}

export interface PatientSearchResult {
  id?: string;
  mrn?: number;
  companyId?: string;
  name?: string;
  address?: string;
  phone?: string;
  email?: string;
  ssn?: string;
  dateCreated?: Date;
 }