import { BaseAddress, BaseModel } from './base.model';
import { People, Address, Contact, Identification } from './peopleplace.model';
import { IdentityAppUser } from './user-login.model';

export interface Employee extends People {
  id?: string;
  normalizedId?: number;
  companyId?: string;
  departmentId?: string;
  roleId?: string;
  salary?: number;
  salaryType?: string;
  codeId?: string;
  reportToId?: string;
  jobTitle?: string;
  dateHired?: Date;
  dateTerminated?: Date;
  isActive?: boolean;
  profile?: EmployeeProfile;
  loginInfo?: IdentityAppUser;
  identifications?: EmployeeIdentification[];
  contacts?: EmployeeContact[];
  addresses?: EmployeeAddress[];
}

export interface EmployeeIdentification extends Identification {
  employeeId?: string;
}

export interface EmployeeContact extends Contact {
  employeeId?: string;
}

export interface EmployeeAddress extends Address {
  employeeId?: string;
}

export interface EmployeeProfile extends BaseModel {
  id?: string;
  employeeId?: string;
  isSysAdmin?: boolean;
  defaultTheme?: string;
  biography?: string;
  photoName?: string;
  photo?: string;
}

export interface EmployeeSummary extends BaseAddress {
  employeeId?: string;
  normalizedEmployeeId?: number;
  companyId?: string;
  departmentId?: string;
  roleId?: string;
  prefix?: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  suffix?: string;
  dateOfBirth?: Date;
  gender?: string;
  evvId?: string;
  ssn?: string;
  salary?: number;
  salaryType?: string;
  codeId?: string;
  reportToId?: string;
  jobTitle?: string;
  dateHired?: Date;
  dateTerminated?: Date;
  employeeAddressId?: string;
  employeeProfileId?: string;
  defaultTheme?: string;
  biography?: string;
  photoName?: string;
  photo?: string;
  identityAppUserId?: string;
  userName?: string;
  userTypeId?: string;
  email?: string;
  phoneNumber?: string;
  isSysAdmin?: boolean;
  isActive?: boolean;
  password?: string;
  lastUpdatedUserId?: string;
  isPasswordChange?: boolean;
}

export interface EmployeeName {
  id?: string;
  name?: string;
  companyId?: string;
  photoName?: string;
}
