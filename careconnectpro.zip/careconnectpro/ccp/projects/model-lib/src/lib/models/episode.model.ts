import { CalendarEvent } from "angular-calendar";
import { BaseModel } from "../models/base.model";
import { TimeSheet, WorkflowNote, WorkflowTask } from "./task-management.model";

export interface Episode extends BaseModel {
    id?: string,
    normalizedId?: number,
    patientId?: string,
    status?: string,
    billingMode?: number,
    startOfCareDate?: Date,
    startDate?: Date,
    endDate?: Date,
    recertificationDate?: Date,
    caseManager?: string,
    visits?: EpisodeVisit[],
    tasks?: EpisodeTask[],
    notes?: EpisodeNote[]
}

export interface EpisodeVisit extends BaseModel {
    id?: string,
    episodeId?: string,
    isSingleVisit?: boolean,
    frequency?: string,
    includeWeekend?: boolean,
    serviceId?: string,
    assignedTo?: string,
    serviceStartDate?: Date,
    serviceEndDate?: Date,
    status?: string,
    tasks?: EpisodeVisitTask[],
    notes?: EpisodeVisitNote[],
    timesheets?: EpisodeVisitTimeSheet
}

export interface EpisodeVisitTask extends WorkflowTask {
    visitId?: string
}
export interface EpisodeTask extends WorkflowTask {
    episodeId?: string
}
export interface EpisodeNote extends WorkflowNote {
    episodeId?: string
}
export interface EpisodeVisitNote extends WorkflowNote {
    visitId?: string
}
export interface EpisodeCalendarEvent extends CalendarEvent {
    episodeVisit?: EpisodeVisit; 
}
export interface EpisodeVisitTimeSheet extends TimeSheet {
    visitId?: string    
}
export interface EpisodeSearchResult {
    id?: string;
    normalizedId?: number,
    mrn?: number;
    patientId?: string;
    patientName?: string;
    startOfCare?: Date,
    startDate?: Date;
    endDate?: Date;
    caseManagerName?: string;
    visits?: number;
    status?: string;
   }



