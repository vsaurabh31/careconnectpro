﻿export interface UserSignup {
  firstName?: string;
  lastName?: string;
  email?: string;
  phone?: string;
  companyName?: string;
  jobTitle?: string;
  userName?: string;
  password?: string;
  password2?: string;
  subscriptionId?: string;
  confirmToken?: string;
}

export interface SignupResponse {
  userId?: string;
  companyId?: string;
  message?: string;
  rowsAffected?: number;
}

export interface SignupWorkflow {
  enableCompany?: boolean;
  enablePackageSelection?: boolean;
  enableLogin?: boolean;
  enablePayment?: boolean;
  enableConfirmation?: boolean;
}
