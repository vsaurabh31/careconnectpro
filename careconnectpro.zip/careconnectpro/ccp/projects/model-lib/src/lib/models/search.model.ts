export interface PatientSearchKeys {
  all?: boolean;
  name?: boolean;
  id?: boolean;
  ssn?: boolean;
  phone?: boolean;
  email?: boolean;
  address?: boolean;
  searchKeyword?: string;
  companyId?: string;
}

export interface GenericSearch {
  companyId?: string;
  searchKeyword?: string;
  searchFilter?: string;
}