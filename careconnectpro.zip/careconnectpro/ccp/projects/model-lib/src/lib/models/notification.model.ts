export interface Notification {
  id?: number;
  title?: string;
  message?: string;
  type?: string;
  date?: string;
  path?: string;
}

