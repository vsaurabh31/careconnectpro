import { BaseModel } from './base.model';
import { Contact, Address, Identification } from './peopleplace.model';

export interface Company extends BaseModel {
  id?: string;
  normalizedId?: number;
  name?: string;
  companyName?: string;
  longName?: string;
  administratorUserId?: string;
  departments?: Department[];
  companySettings?: CompanySystemSettings[];
  subscriptions?: CompanySubscription[];
  addresses?: CompanyAddress[];
  contacts?: CompanyContact[];
  identifications?: CompanyIdentification[];
  extraDetails?: CompanyExtraDetails[];
  patientMedicalHistory?: CompanyPatientMedicalHistory[];
  services?: CompanyService[];
  tasks?: CompanyTask[]
}

export interface CompanyAddress extends Address {
  companyId?: string;
}

export interface CompanyContact extends Contact {
  companyId?: string;
}

export interface CompanyIdentification extends Identification {
  companyId?: string;
}

export interface CompanySubscription extends BaseModel {
  id?: string;
  companyId?: string;
  normalizedId?: number;
  packageId?: string;
  totalAmount?: number;
  isActive?: boolean;
  startDate?: Date;
  endDate?: Date;
}

export interface CompanySystemSettings extends BaseModel {
  id?: string;
  companyId?: string;
  defaultTheme?: string;
  enableChat?: boolean;
  enableUserTheme?: boolean;
  enableMessages?: boolean;
  enableBroadcastMsgs?: boolean;
  logoName?: string;
  logo?: string;
}

export interface Department extends BaseModel {
  id?: string;
  companyId?: string;
  name?: string;
  description?: string;
  parentId?: string;
}

export interface CompanyExtraDetails extends BaseModel {
  id?: string;
  companyId?: string;
  extraDetailEntityId?: number;
  fieldName?: string;
  fieldType?: number;
}
export interface CompanyService extends BaseModel {
  id?: string;
  companyId?: string;
  serviceName?: string;
}


export interface CompanyPatientMedicalHistory extends BaseModel {
  id?: string;
  companyId?: string;
  historyType?: string;
  value?: string;
}

export interface CompanyTask extends BaseModel {
  id?: string;
  companyId?: string;
  taskTypeId?: string;
  patientId?: string;
  episodeId?: string;
  episodeVisitId?: string;
  taskName?: string;
  documentTypeId?: string;
  taskDescription?: string;
  status?: string;
  assignedTo?: string;
  dueDate?: Date;
  serviceId?: string;
}