export interface File {
  id?: number;
  path?: string;
}
