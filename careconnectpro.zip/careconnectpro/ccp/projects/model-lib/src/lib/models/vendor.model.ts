﻿import { BaseAddress, BaseModel } from './base.model';
import { People, Identification, Contact, Address } from './peopleplace.model';

export interface Vendor extends People {
  id?: string;
  normalizedId?: number;
  companyId?: string;
  companyName?: string;
  isActive?: boolean;
  notes?: string;
  services?: VendorBusinessService[];
  identifications?: VendorIdentification[];
  contacts?: VendorContact[];
  addresses?: VendorAddress[];
}

export interface VendorIdentification extends Identification {
  vendorId?: string;
}

export interface VendorContact extends Contact {
  vendorId?: string;
}

export interface VendorAddress extends Address {
  vendorId?: string;
}

export interface VendorBusinessService extends BaseModel {
  id?: string;
  vendorId?: string;
  vendorServiceCodeId?: string;
}

export interface VendorSearchResult {
  id?: string;
  companyId?: string;
  companyName?: string;
  contactPerson?: string;
  address?: string;
  phone?: string;
  fax?: string;
  email?: string;
  website?: string;
  dateCreated?: Date;
 }

