﻿export interface MediaFile {
  fileName?: string;
  filePath?: string;
  companyFile?: string;
  employeeFile?: string;
  physicianFile?: string;
  vendorFile?: string;
}
