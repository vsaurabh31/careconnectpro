export interface UserLogin {
  userName?: string;
  password?: string;
  resetPasswordEmail?: string;
  token?: string;
  rememberMe?: boolean;
}

export interface UserSession {
  companyId?: string;
  employeeId?: string;
  userName?: string;
  email?: string;
  firstName?: string;
  lastName?: string;
  fullName?: string;
  sessionId?: string;
  isAuthenticated?: boolean;
  roleId?: string;
  errorMsg?: string;
  isSysAdmin?: boolean;
  userTypeId?: string;
  employeePhotoName?: string;
  companyLogoName?: string;
  theme?: string;
  primaryLocationId?: string;
}

export interface ResetPassword {
  resetemail?: string;
}

export interface IdentityAppUser {
  id?: string;
  userName?: string;
  companyId?: string;
  appUserTypeCode?: string;
  email?: string;
  phoneNumber?: string;
  isSysAdmin?: boolean;
  isEnabled?: boolean;
  passwordHash?: string;
  isPasswordChanged?: boolean;
}
