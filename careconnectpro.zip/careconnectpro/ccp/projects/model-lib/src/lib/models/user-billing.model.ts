﻿import { CreditCardType } from '../enums';
import { BaseAddress } from './base.model';

export interface UserBillingInfo extends BaseAddress {
  firstName?: string;
  lastName?: string;
  companyId?: string;
}

export interface UserPaymentInfo extends BaseAddress {
  companyId?: string;
  firstName?: string;
  lastName?: string;
  cardType?: CreditCardType;
  cardNumber?: string;
  expirationYear?: number;
  expirationMonth?: number;
  paymentStatus?: string;
  storeCard?: boolean;
  totalAmount?: number;
  totalMonths?: number;
  approvalCode?: string;
  cardCvv?: number;
}
