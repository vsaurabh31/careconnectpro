export interface DashboardMiniCardData {
    title: string, 
    value: string,
    isIncrease: boolean,
    color: string,
    percentValue: string,
    icon: string,
    isCurrency: boolean
}

export interface DashboardMonthlyIntake {
    month: string,
    total: number
}

export interface DashboardMyCases {
    normalizedId: number,
    name: string,
    status: string
}

export interface DashboardRegionalMarket {
    region: string,
    total: number
}

export interface DashboardServicesByReferral {
    serviceName: string,
    medicalProvider: number,
    physician: number
}

export interface DashboardServicesRequested {
    serviceName: string,
    total: number
}