import { BaseModel } from "./base.model";

export interface WorkflowTask extends BaseModel {
    id?: string,
    assignedTo?: string,
    taskName?: string,
    taskDescription?: string,
    status?: string
}

export interface WorkflowNote extends BaseModel {
    id?: string,
    noteType?: string,
    detail?: string,
    createdBy?: string
}
export interface TimeSheet extends BaseModel {
    id?: string,
    userId?: string,
    startTime?: Date,
    endTime?: Date
}

export interface TaskSearchResult {
    id?: string;
    taskTypeId?: string;
    mrn?: number;
    patientId?: string;
    patientName?: string;
    episodeId?: string;
    episodeNormalizedId?: number;
    episodeVisitId?: string;
    taskName?: string;
    taskDescription?: string;
    serviceName?: string;
    documentTypeId?: string;
    status?: string;
    assignedToName?: string;
    assignedTo?: string;
    dueDate?: Date;
    lastUpdatedDate?: Date;
}

export interface DocumentType extends BaseModel {
    id?: string;
    category?: string;
    name?: string;
    value?: string;
}

export interface DocumentSection {
    id?: string;
    name?: string;
}

export interface TaskDocument extends BaseModel {
    id?: string;
    taskId?: string;
    documentId?: string; 
}

export interface DocumentOasisForm extends BaseModel {
    id?: string;
}

export interface DocumentOasisForm extends BaseModel {
    id?: string;
}

export interface DocumentPlanOfCare extends BaseModel {
    id?: string;
}

export interface DocumentPlanOfCare extends BaseModel {
    id?: string;
}

export interface FormDocumentLabel extends BaseModel {
    id?: string;
    documentType?: string;
    label?: string;
}

export interface DocumentSkilledNurseNoteWoundAssessment extends BaseModel {
    id?: string;
    documentSkilledNurseNoteId?: string;
    seqNo?: number;
    length?: string;
    width?: string;
    depth?: string;
    drainage?: string;
    tunneling?: string;
    odor?: string;
    surgicalTissue?: string;
    edema?: string;
    stoma?: string;
}

export interface DocumentSkilledNurseNote extends BaseModel {
    id?: string;
    homeBoundReasons?: string;
    homeBoundReasonOther?: string;
    typeOfVisits?: string;
    typeOfVisitOther?: string;
    vitalSignsFactorTemperature?: number;
    vitalSignsFactorTemperatureOral?: number;
    vitalSignsFactorTemperatureRectal?: number;
    vitalSignsFactorTemperatureAxillary?: number;
    vitalSignsFactorRespiration?: number;
    vitalSignsFactorRespirationIsRegular?: boolean;
    vitalSignsFactorPulseApical?: number;
    vitalSignsFactorPulseRadial?: number;
    vitalSignsFactorPulseIsRegular?: boolean;
    vitalSignsFactorBprightLying?: number;
    vitalSignsFactorBprightSitting?: number;
    vitalSignsFactorBprightStanding?: number;
    vitalSignsFactorBpleftLying?: number;
    vitalSignsFactorBpleftSitting?: number;
    vitalSignsFactorBpleftStanding?: number;
    vitalSignsFactorFastingBloodSugar?: number;
    vitalSignsFactorRandomBloodSugar?: number;
    vitalSignsFactorHeight?: string;
    vitalSignsFactorWeight?: string;
    changeInPatientCondition?: boolean;
    notifiedPhysicianId?: string;
    notifiedSupervisorId?: string;
    isNewOrder?: boolean;
    newOrderNotes?: string;
    supervisoryVisits?: string;
    supervisoryVisitIsFollowCarePlan?: boolean;
    supervisoryVisitIsPatientNeedMet?: boolean;
    supervisoryVisitIsAssignnmentUpdated?: boolean;
    supervisoryVisitIsServiceChangeRequest?: boolean;
    supervisoryVisitIsSafetyPrecFollowed?: boolean;
    supervisoryVisitIsEmployeePresent?: boolean;
    supervisoryVisitIsPatientSatisfied?: boolean;
    supervisoryVisitNotes?: string;
    cardiovascularFactors?: string;
    cardiovascularFactorOther?: string;
    pulmonaryFactors?: string;
    pulmonaryFactorOther?: string;
    integumentaryFactors?: string;
    integumentaryFactorOther?: string;
    musculoskeletalFactors?: string;
    musculoskeletalFactorOther?: string;
    musculoskeletalFactorWalksWith?: string;
    gastrointestinalFactors?: string;
    gastrointestinalFactorOther?: string;
    genitourinaryFactors?: string;
    genitourinaryFactorOther?: string;
    genitourinaryFactorColor?: string;
    genitourinaryFactorCatheter?: string;
    genitourinaryFactorFr?: string;
    genitourinaryFactorCc?: string;
    genitourinaryFactorLastChanged?: Date;
    neurologicalFactors?: string;
    neurologicalFactorOther?: string;
    neurologicalFactorMovement?: string;
    mentalFactors?: string;
    mentalFactorOther?: string;
    mentalFactorFactorOrientedX?: string;
    painFactors?: string;
    painFactorOther?: string;
    interventionsFactors?: string;
    interventionsFactorOther?: string;
    techniqueUsedFactors?: string;
    techniqueUsedFactorOther?: string;
    infusionIvsiteFactors?: string;
    infusionIvsiteFactorOther?: string;
    infusionIvsiteFactorFromDate?: Date;
    infusionIvsiteFactorToDate?: Date;
    skilledInterventionTeachingNotes?: Date;
    snadministeredBy?: string;
    imsqfactor?: string;
    continueVisitForFactors?: string;
    continueVisitForFactorOther?: string;
    qualityControlGlucoseSolutionFactorNa?: boolean;
    qualityControlGlucoseSolutionFactorHighRange?: number;
    qualityControlGlucoseSolutionFactorLowRange?: number;
    qualityControlFactorExpirationDate?: Date;
    qualityControlFactorDateOpen?: Date;
    qualityControlFactorIndicator?: string;
    qualityControlFactors?: string;
    qualityControlFactorOther?: string;
    qualityControlFactorDischargeNote?: string;
    qualityControlFactorNoCgadminInjectReason?: string;
    qualityControlFactorNoPtadminInjectReason?: string;
    qualityControlFactorNoAbleCgassistReason?: string;
    nurseSignature?: any;
    timeIn?: Date;
    timeOut?: Date;
    documentSkilledNurseNoteWoundAssessment?: DocumentSkilledNurseNoteWoundAssessment[];
}


