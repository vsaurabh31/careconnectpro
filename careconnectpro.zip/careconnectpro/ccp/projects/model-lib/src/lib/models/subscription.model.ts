export interface SubscriptionPackage {
  id?: string;
  packageName?: string;
  packageType?: string;
  amount?: number;
}
