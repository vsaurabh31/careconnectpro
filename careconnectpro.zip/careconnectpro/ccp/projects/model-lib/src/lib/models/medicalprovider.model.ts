import { Address, Contact, Identification } from './peopleplace.model';
import { BaseModel } from './base.model';

export interface MedicalProvider extends BaseModel {
    id?: string;
    normalizedId?: number;
    companyId?: string;
    longName?: string;
    name?: string;
    identifications?: ProviderIdentification[];
    addresses?: ProviderAddress[];
    contacts?: ProviderContact[];
  }

  export interface ProviderAddress extends Address {
    providerId?: string;
  }
  
  export interface ProviderIdentification extends Identification {
    medProviderId?: string;
  }
  
  export interface ProviderContact extends Contact {
    medProviderId?: string;
  }

  export interface ProviderSearch {
    companyId?: string;
    searchKeyword?: string;
    searchFilter?: string;
  }

  export interface MedicalProviderSearchResult {
    id?: string;
    companyId?: string;
    name?: string;
    address?: string;
    phone?: string;
    fax?: string;
    email?: string;
    website?: string;
    npi?: string;
    linkedPatients?: number;
    dateCreated?: Date;
   }