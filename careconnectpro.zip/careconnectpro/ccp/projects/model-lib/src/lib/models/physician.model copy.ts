﻿import { BaseModel } from './base.model';
import { People, Identification, Contact, Address } from './peopleplace.model';

export interface Physician extends People {
  id?: string;
  normalizedId?: number;
  companyId?: string;
  jobTitle?: string;
  isActive?: boolean;
  notes?: string;
  practices?: PhysicianPracticeArea[];
  identifications?: PhysicianIdentification[];
  contacts?: PhysicianContact[];
  addresses?: PhysicianAddress[];
}

export interface PhysicianIdentification extends Identification {
  physicianId?: string;
}

export interface PhysicianContact extends Contact {
  physicianId?: string;
}

export interface PhysicianAddress extends Address {
  physicianId?: string;
}

export interface PhysicianPracticeArea extends BaseModel {
  id?: string;
  physicianId?: string;
  practiceCodeId?: string;
}

export interface PhysicianSearchResult {
 id?: string;
 companyId?: string;
 name?: string;
 address?: string;
 phone?: string;
 npi?: string;
 linkedPatients?: number;
 dateCreated?: Date;
}

