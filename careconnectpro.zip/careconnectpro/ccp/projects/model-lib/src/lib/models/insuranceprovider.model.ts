import { Address, Contact, Identification } from './peopleplace.model';
import { BaseModel } from './base.model';

export interface MedicalInsuranceProvider extends BaseModel {
    id?: string;
    normalizedId?: number;
    companyId?: string;
    longName?: string;
    name?: string;
    identifications?: InsuranceProviderIdentification[];
    addresses?: InsuranceProviderAddress[];
    contacts?: InsuranceProviderContact[];
  }

  export interface InsuranceProviderAddress extends Address {
    insProviderId?: string;
  }

  export interface InsuranceProviderIdentification extends Identification {
    medInsuranceId?: string;
  }
  
  export interface InsuranceProviderContact extends Contact {
    medInsuranceId?: string;
  }

  export interface MedicalInsuranceProviderSearchResult {
    id?: string;
    companyId?: string;
    name?: string;
    address?: string;
    phone?: string;
    fax?: string;
    email?: string;
    website?: string;
    linkedPatients?: number;
    dateCreated?: Date;
   }