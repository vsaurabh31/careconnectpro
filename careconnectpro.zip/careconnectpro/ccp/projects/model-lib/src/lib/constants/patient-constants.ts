export class PatientConstants {
public static ConditionHistory: string = "ConditionHistory";
public static SocialHistory: string = "SocialHistory";
public static FamilyHistory: string = "FamilyHistory";
public static MedicareInsuranceType: string = "Medicare";
public static MedicaidInsuranceType: string = "Medicaid";
}