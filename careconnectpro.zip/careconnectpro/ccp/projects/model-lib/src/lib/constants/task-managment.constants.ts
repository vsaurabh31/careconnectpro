import { DocumentSection } from "../models/task-management.model";

export class DocumentTypeConstants
{
    public static SKILLED_NURSE_VISIT_NOTE: string = "SNVisitNote";
    public static OASIS_DEATH_AT_HOME: string = "DAH";
    public static EPISODE_ASSESSMENT: string = "Assessment";
    public static EPISODE_PLAN_OF_CARE: string = "POC";
    public static OASIS_TRANSFER: string = "TRF";
    public static OASIS_DISCHARGED_FROM_AGENCY: string = "DC";
    public static OASIS_RECERTIFICATION_FOLLOWUP: string = "FC";
    public static OASIS_START_OF_CARE: string = "SOC";
    public static OASIS_RESUMPTION_OF_CARE: string = "ROC";
    public static HOME_HEALTH_AIDE_VISIT_NOTE: string = "HHAVisitNote";
    public static MEDICAL_SOCIAL_WORKER_VISIT_NOTE: string = "MSWVisitNote";
    public static PHYSICAL_THERAPY_VISIT_NOTE: string = "PTVisitNote";
    public static SPEECH_THERAPY_VISIT_NOTE: string = "STVisitNote";
    public static OCCUPATIONAL_THERAPY_VISIT_NOTE: string = "OTVisitNote";
    public static STANDARD_PATIENT_VISIT_NOTE: string = "SPVisitNote";
}
export class TaskType
{
    public static AGENCY: string = "Agency";
    public static EPISODE: string = "Episode";
    public static EPISODE_VISIT: string = "EpisodeVisit";
    public static PATIENT: string = "Patient";
}

export class CmsHHAServices
{
    public static MEDICAL_SOCIAL_WORKER: string = "Medical Social Worker";
    public static PHYSICAL_THERAPY: string = "Physical Therapy";
    public static SKILLED_NURSING: string = "Skilled Nursing";
    public static SPEECH_THERAPY: string = "Speech Therapy";
    public static OCCUPATIONAL_THERAPY: string = "Occupational Therapy";
    public static HOME_HEALTH_AIDE: string = "Home Health Aide";
}

export class TaskDocumentSections {
    public static SKILLED_NURSE_VISITATION_NOTE: DocumentSection[] = [
        {id: "section1", name: "HOMEBOUND REASON" },
        {id: "section2", name: "GASTROINTESTINAL" },
        {id: "section3", name: "PAIN" },
        {id: "section4", name: "SKILLED INTERVENTION" },
        {id: "section5", name: "QUALITY CONTROL" },
        {id: "section6", name: "SIGNATURE" }
    ];
    public static PLAN_OF_CARE: DocumentSection[] = [
        {id: "section1", name: "PATIENT INFORMATION" },
        {id: "section2", name: "ICD & MEDICATIONS" },
        {id: "section3", name: "FUNCTIONAL LIMITATIONS" },
        {id: "section4", name: "SIGNATURE" }
    ];
    public static OASIS_START_OF_CARE: DocumentSection[] = [
        {id: "M0010-M0030", name: "M0010-M0030" },
        {id: "M0040-M0150", name: "M0040-M0150" },
        {id: "M1000-M1036", name: "M1000-M1036" },
        {id: "M1060-M1306", name: "M1060-M1306" },
        {id: "M1311", name: "M1311" },
        {id: "M1320-M1410", name: "M1320-M1410" },
        {id: "M1600-M2003", name: "M1600-M2003" },
        {id: "M2010", name: "M2010" },
        {id: "M2020-M2250", name: "M2020-M2250" }
    ];
    public static OASIS_RESUMPTION_OF_CARE: DocumentSection[] = [
        {id: "M0032", name: "M0032" },
        {id: "M0080-M0110", name: "M0080-M0110" },
        {id: "M1000-M1036", name: "M1000-M1036" },
        {id: "M1060-M1306", name: "M1060-M1306" },
        {id: "M1311", name: "M1311" },
        {id: "M1320-M1410", name: "M1320-M1410" },
        {id: "M1600-M2003", name: "M1600-M2003" },
        {id: "M2010", name: "M2010" },
        {id: "M2020-M2250", name: "M2020-M2250" }
        ];
    public static OASIS_FOLLOW_UP: DocumentSection[] = [
        {id: "M0080-M0100", name: "M0080-M0100" },
        {id: "M0110", name: "M0110" },
        {id: "M1011", name: "M1011" },
        {id: "M1021-M1023", name: "M1021-M1023" },
        {id: "M1030", name: "M1030" },
        {id: "M1200", name: "M1200" },
        {id: "M1242", name: "M1242" },
        {id: "M1306", name: "M1306" },
        {id: "M1311", name: "M1311" },
        {id: "M1322-M1342", name: "M1322-M1342" },
        {id: "M1400", name: "M1400" },
        {id: "M1610", name: "M1610" },
        {id: "M1620", name: "M1620" },
        {id: "M1630", name: "M1630" },
        {id: "M1810-M1840", name: "M1810-M1840" },
        {id: "M1850", name: "M1850" },
        {id: "M1860", name: "M1860" },
        {id: "M2030", name: "M2030" },
        {id: "M2200", name: "M2200" }
     ];
     public static OASIS_TRANSFER: DocumentSection[] = [
        {id: "M0080-M0100", name: "M0080-M0100" },
        {id: "M1041-M1056", name: "M1041-M1056" },
        {id: "M1501", name: "M1501" },
        {id: "M1511", name: "M1511" },
        {id: "M2005", name: "M2005" },
        {id: "M2016", name: "M2016" },
        {id: "M2301-M2410", name: "M2301-M2410" },
        {id: "M2430", name: "M2430" },
        {id: "M0903", name: "M0903" },
        {id: "M0906", name: "M0906" }
     ];
     public static OASIS_DISCHARGE: DocumentSection[] = [
        {id: "M0080-M0100", name: "M0080-M0100" },
        {id: "M2005", name: "M2005" },
        {id: "M0903", name: "M0903" },
        {id: "M0906", name: "M0906" },
        {id: "M0080-M0100", name: "M0080-M0100" },
        {id: "M1041-M1056", name: "M1041-M1056" },
        {id: "M1230", name: "M1230" },
        {id: "M1242", name: "M1242" },
        {id: "M1306-M1342", name: "M1306-M1342" },
        {id: "M1400", name: "M1400" },
        {id: "M1501-M1620", name: "M1501-M1620" },
        {id: "M1700-M1720", name: "M1700-M1720" },
        {id: "M1740", name: "M1740" },
        {id: "M1745", name: "M1745" },        
        {id: "M1800-M1890", name: "M1800-M1890" },
        {id: "M2005", name: "M2005" },
        {id: "M2016-M2030", name: "M2016-M2030" },
        {id: "M2102", name: "M2102" },
        {id: "M2301-M2420", name: "M2301-M2420" },
        {id: "M0903", name: "M0903" },
        {id: "M0906", name: "M0906" },
     ];
}

