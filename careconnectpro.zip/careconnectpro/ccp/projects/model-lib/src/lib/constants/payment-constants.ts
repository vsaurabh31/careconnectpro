import { CCYear, CCMonth, GenericIdValue } from '../models/common.model';

export class PaymentConstants {
    public static CCardTypes: GenericIdValue[] = [
      { id: 'Visa', value: 'Visa' },
      { id: 'MasterCard', value: 'MasterCard' },
      { id: 'AMEX', value: 'American Express' },
      { id: 'Discover', value: 'Discover' }
    ];

    public static PaymentTypes: GenericIdValue[] = [
      { id: 'BankAccount', value: 'EFT Bank Account' },
      { id: 'Cash', value: 'Cash' },
      { id: 'Check', value: 'Check' },
      { id: 'CreditCard', value: 'Credit or Debit Card' },
    ]

    public static CCYears: CCYear[] = [
      { id: 2020, value: 2020 },
      { id: 2020, value: 2020 },
      { id: 2021, value: 2021 },
      { id: 2022, value: 2022 },
      { id: 2023, value: 2023 },
      { id: 2024, value: 2024 },
      { id: 2025, value: 2025 },
      { id: 2026, value: 2026 },
      { id: 2026, value: 2027 },
      { id: 2027, value: 2028 },
      { id: 2029, value: 2029 },
      { id: 2030, value: 2030 },
      { id: 2031, value: 2031 },
      { id: 2032, value: 2032 },
      { id: 2033, value: 2033 },
      { id: 2034, value: 2034 },
      { id: 2035, value: 2035 }
    ];
  
    public static CCMonths: CCMonth[] = [
      { id: 1, value: 1 },
      { id: 2, value: 2 },
      { id: 3, value: 3 },
      { id: 4, value: 4 },
      { id: 5, value: 5 },
      { id: 6, value: 6 },
      { id: 7, value: 7 },
      { id: 8, value: 8 },
      { id: 9, value: 9 },
      { id: 10, value: 10 },
      { id: 11, value: 11 },
      { id: 12, value: 12 },
      { id: 13, value: 13 },
      { id: 14, value: 14 },
      { id: 16, value: 16 },
      { id: 17, value: 17 },
      { id: 18, value: 18 },
      { id: 19, value: 19 },
      { id: 20, value: 20 },
      { id: 21, value: 21 },
      { id: 22, value: 22 },
      { id: 23, value: 23 },
      { id: 24, value: 24 },
      { id: 25, value: 25 },
      { id: 26, value: 26 },
      { id: 27, value: 27 },
      { id: 28, value: 28 },
      { id: 29, value: 29 },
      { id: 30, value: 30 },
      { id: 31, value: 31 }
    ];
  }
  
  
  