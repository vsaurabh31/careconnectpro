import { GenericIdValue } from '../models';

export class IdTypeConstants {
    public static DriversLicense: string = "DriversLicense";
    public static Ssn: string = "Ssn";
    public static Hrn: string = "Hrn";
    public static Mrn: string = "Mrn";
    public static EvvId: string = "EvvId";
    public static MedicalLicenseId: string = "MedicalLicenseId";
    public static Npi: string = "Npi";
    public static FedTaxId: string = "FedTaxId";
    public static Hicn: string = "Hicn";
    public static MedicareId: string = "MedicareId";
    public static MedicaidId: string = "MedicaidId";
    public static SandataAccountId: string = "SandataAccountId";
    public static StateAssignedId: string = "StateAccountId";
 }

 export class PeoplePlacesCodes { 
    public static MaritalStatusCodes: GenericIdValue[] = [
        { value: 'Divorced', id: 'Divorced' },
        { value: 'Married', id: 'Married' },
        { value: 'Single', id: 'Single' },
        { value: 'Separated', id: 'Separated' },
        { value: 'Widowed', id: 'Widowed' }
    ]

    public static MaritalStatusApiMapping: string[] = [
        PeoplePlacesCodes.MaritalStatusCodes.find(item => item.id == 'Married').value,
        PeoplePlacesCodes.MaritalStatusCodes.find(item => item.id == 'Widowed').value,
        PeoplePlacesCodes.MaritalStatusCodes.find(item => item.id == 'Separated').value,
        PeoplePlacesCodes.MaritalStatusCodes.find(item => item.id == 'Divorced').value,
        PeoplePlacesCodes.MaritalStatusCodes.find(item => item.id == 'Single').value
    ]
    
    public static GenderCodes: GenericIdValue[] = [
        { value: 'Male', id: 'Male' },
        { value: 'Female', id: 'Female' },
        { value: 'Other', id: 'Other' },
    ]

    public static ContactTypes: GenericIdValue[] = [
        {value: 'Home Phone', id: 'HomePhone'},
        {value: 'Work Phone', id: 'WorkPhone'},
        {value: 'Cell Phone', id: 'CellPhone'},
        {value: 'Email', id: 'Email'},
        {value: 'Website URL', id: 'Url'},
        {value: 'Fax', id: 'Fax'}
    ]

    public static AgencyIdentificationTypes: GenericIdValue[] = [
        {value: 'Medical License Id', id: IdTypeConstants.MedicalLicenseId},
        {value: 'National Provider Id', id: IdTypeConstants.Npi},
        {value: 'Federal Tax Id', id: IdTypeConstants.FedTaxId},
        {value: 'Medicare Provider Number', id: IdTypeConstants.MedicareId},
        {value: 'Medicaid Provider Number', id: IdTypeConstants.MedicaidId},
        {value: 'Sandata Account Number', id: IdTypeConstants.SandataAccountId},
        {value: 'State Assigned Id', id: IdTypeConstants.StateAssignedId}
    ]

    public static EmployeeIdentificationTypes: GenericIdValue[] = [
        {value: 'Social Security Number', id: IdTypeConstants.Ssn},
        {value: 'Drivers License Number', id: IdTypeConstants.DriversLicense},
        {value: 'Electronic Visit Verification Number', id: IdTypeConstants.EvvId}
    ]

    public static PatientIdentificationTypes: GenericIdValue[] = [
        {value: 'Social Security Number', id: IdTypeConstants.Ssn},
        {value: 'Drivers License Number', id: IdTypeConstants.DriversLicense},
        {value: 'Medical Record Number', id: IdTypeConstants.Mrn},
        {value: 'Health Insurance Claim Number', id: IdTypeConstants.Hicn}
    ]

    public static ContactHomePhone: string = "HomePhone";
    public static ContactWorkPhone: string = "WorkPhone";
    public static ContactFax: string = "Fax";
    public static ContactEmail: string = "Email";
    public static Url: string = "Url";    

 }


 
