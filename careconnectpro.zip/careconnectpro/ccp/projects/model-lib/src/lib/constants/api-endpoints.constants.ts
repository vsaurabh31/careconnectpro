export class ApiEndPoints {
    //public static ApiUrl: string = "http://localhost:54345/";
    public static ApiUrl: string = "https://dev-careconnect-api.azurewebsites.net/";
  
    public static MediaApiUrl: string = "https://dev-careconnect-mediapi.azurewebsites.net/";
    //public static MediaApiUrl: string = "http://localhost:59714/";
  
    public static CdnApiUrl: string = "https://dev-careconnect-cdn.azurewebsites.net";
    //public static MediaApiUrl: string = "http://localhost:53024/";
  
    public static BaseUrl: string = document.getElementsByTagName('base')[0].href;
  }