


export class AppConstants {
  public static DefaultTaxRate: number = 0.06;
  public static DefaultCompanyLogo: string = "assets/images/defaultcompanylogo.png";
  public static ValidImageFiles: string[] = ["tiff", "gif","bmp","png","jpg","jpeg","tif"];
  public static MaxImageFileSize: number = 2000000;  
}

export class ApiResponse {
  public static MESSAGE_TYPE_ERROR: string = "Error";
  public static MESSAGE_TYPE_INFO: string = "Info";
  public static MESSAGE_TYPE_WARNING: string = "Warning";
}

export class MedicalHistoryConstants {
  public static FAMILY_HISTORY: string = "FamilyHistory";
  public static SOCIAL_HISTORY: string = "SocialHistory";
  public static CONDITION_HISTORY: string = "ConditionHistory";
}

export const colors: any = {
  red: {
    primary: '#ad2121',
    secondary: '#FAE3E3',
  },
  blue: {
    primary: '#1e90ff',
    secondary: '#D1E8FF',
  },
  yellow: {
    primary: '#e3bc08',
    secondary: '#FDF1BA',
  },
  chocolate: {
    primary: '#d2691e',
    secondary: '#fedd46',
  },
  brown: {
    primary: '#a52a2a',
    secondary: '#f6cf1e',
  },
  blueviolet: {
    primary: '#8a2be2',
    secondary: '#f6f3e6',
  }
};
export class Status {
  public static ACTIVE: string = "Active";
  public static INACTIVE: string = "InActive";
  public static ONHOLD: string = "OnHold";
  public static OPEN: string = "Open";
  public static COMPLETED: string = "Completed";
  public static IN_PROGRESS: string = "In Progress";
  public static CANCELED: string = "Canceled";
}
export class OasisWorkflowDocumentType {
  public static DISCHARGE_FROM_AGENCY = "OASIS: Discharge from Agency";
  public static DISCHARGE_FROM_AGENCY_DEATH = "OASIS: Discharge from Agency - Death at Home";
  public static TRANSFER_IN_PATIENT_FACILITY = "OASIS: Transfer to Inpatient Facility";
  public static RECERTIFICATION_FOLLOWUP = "OASIS: Recertification/Follow-up";
  public static RESUMPTION_OF_CARE = "OASIS: Resumption of Care";
  public static START_OF_CARE = "OASIS: Start of Care";
}

export class GenericWorkflowDocumentType {
  public static EPISODE_PLAN_OF_CARE = "Plan of Care";
  public static VISITATION_NOTE_SKILLED_NURSE = "Skilled Nurse Visitation Note";
}
