import { TestBed } from '@angular/core/testing';

import { ModelLibService } from './model-lib.service';

describe('ModelLibService', () => {
  let service: ModelLibService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ModelLibService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
