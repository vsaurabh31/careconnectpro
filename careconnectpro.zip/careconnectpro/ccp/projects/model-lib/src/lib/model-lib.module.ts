import { NgModule } from '@angular/core';
import { ModelLibComponent } from './model-lib.component';

@NgModule({
  declarations: [ModelLibComponent],
  imports: [],
  exports: [ModelLibComponent]
})
export class ModelLibModule {}
